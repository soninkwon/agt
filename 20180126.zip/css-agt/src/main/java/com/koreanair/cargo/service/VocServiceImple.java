package com.koreanair.cargo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.koreanair.cargo.domain.VocReqDomain;
import com.koreanair.cargo.persistence.CommonMapper;
import com.koreanair.cargo.persistence.VocMapper;
import com.koreanair.cargo.persistence2.VocRealMapper;
import com.koreanair.cargo.service.ComUtilService;

@Service
public class VocServiceImple implements VocService {
	private static final Logger logger = LoggerFactory.getLogger(VocServiceImple.class);
	
	@Autowired
	VocMapper vocMapper;
	
	@Autowired
	VocRealMapper vocRealMapper;
	
	@Autowired
	ComUtilService comUtil;
	
	@Override
	public String getVocCheckInput(VocReqDomain vocReqDomain) {
		
		logger.info("vocReqDomain.getSubject : " + vocReqDomain.getMailSubject());
		
		logger.info("vocReqDomain.getFileName1 : " + vocReqDomain.getFile_name1().getOriginalFilename());
		logger.info("vocReqDomain.getFileName2 : " + vocReqDomain.getFile_name2().getOriginalFilename());
		logger.info("vocReqDomain.getFileName3 : " + vocReqDomain.getFile_name3().getOriginalFilename());
		
		logger.info("vocReqDomain.getFile_size1 : " + vocReqDomain.getFile_name1().getSize());
		logger.info("vocReqDomain.getFile_size2 : " + vocReqDomain.getFile_name2().getSize());
		logger.info("vocReqDomain.getFile_size3 : " + vocReqDomain.getFile_name3().getSize());
		
		int pos = vocReqDomain.getFile_name1().getOriginalFilename().lastIndexOf( "." );
        String extName1 = vocReqDomain.getFile_name1().getOriginalFilename().substring( pos + 1 );
        
        pos = vocReqDomain.getFile_name2().getOriginalFilename().lastIndexOf( "." );
        String extName2 = vocReqDomain.getFile_name2().getOriginalFilename().substring( pos + 1 );
        
        pos = vocReqDomain.getFile_name3().getOriginalFilename().lastIndexOf( "." );
        String extName3 = vocReqDomain.getFile_name3().getOriginalFilename().substring( pos + 1 );
        
		logger.info("vocReqDomain.getFile_ext1 : " + extName1);
		logger.info("vocReqDomain.getFile_ext2 : " + extName2);
		logger.info("vocReqDomain.getFile_ext3 : " + extName3);
		
		vocReqDomain.setFile_orgn1(vocReqDomain.getFile_name1().getOriginalFilename());
		vocReqDomain.setFile_orgn2(vocReqDomain.getFile_name2().getOriginalFilename());
		vocReqDomain.setFile_orgn3(vocReqDomain.getFile_name3().getOriginalFilename());
		
		vocReqDomain.setFile_size1(vocReqDomain.getFile_name1().getSize()+"");
		vocReqDomain.setFile_size2(vocReqDomain.getFile_name2().getSize()+"");
		vocReqDomain.setFile_size3(vocReqDomain.getFile_name3().getSize()+"");
		
		vocReqDomain.setFile_ext1(extName1);
		vocReqDomain.setFile_ext2(extName2);
		vocReqDomain.setFile_ext3(extName3);
		
		vocReqDomain.setVocEmail(comUtil.VocEncryptEml(vocReqDomain.getMailFrom()));
		vocReqDomain.setVocTel(comUtil.VocEncryptTel(vocReqDomain.getMailTel()));
		
		//입력항목이 모두 들어 왔는지 체크한 후 아래 진행함
		
		//대리점 로그 쌓는다 
		vocMapper.vocInput(vocReqDomain);
		
		//실제 VOC DB INSERT 
		vocRealMapper.vocRealInput(vocReqDomain);
		
		
		
		return "";
	}
	
}
