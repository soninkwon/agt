package com.koreanair.cargo.persistence;

import java.util.List;

import com.koreanair.cargo.domain.VocReqDomain;
import com.koreanair.cargo.domain.VocCityDomain;

public interface ComMapper {
	
	List<VocCityDomain> comCityList(VocReqDomain vocReqDomain);
	
	int vocInsert(VocReqDomain vocReqDomain);
}
