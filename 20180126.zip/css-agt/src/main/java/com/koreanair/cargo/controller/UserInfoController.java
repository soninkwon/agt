package com.koreanair.cargo.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;

/**
 * Handles requests for the application home page.
 */
@Controller
public class UserInfoController {
	
	private static final Logger logger = LoggerFactory.getLogger(UserInfoController.class);
	
	@RequestMapping(value = "login.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String agtLogin(Locale locale, Model model, ModelMap modelMap, HttpSession session) {
		
		
		logger.info("@@@@@@@ login : "+session.getAttribute("menuSession"));
		 
		return "common/login";
		 //return "common/agt_left_menu_session";
	}
	
}
