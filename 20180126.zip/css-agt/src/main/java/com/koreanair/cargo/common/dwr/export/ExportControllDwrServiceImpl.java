package com.koreanair.cargo.common.dwr.export;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.directwebremoting.annotations.RemoteMethod;
import org.directwebremoting.annotations.RemoteProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;

import com.koreanair.cargo.domain.ExportDomain;
import com.koreanair.cargo.domain.ExportReqDomain;
import com.koreanair.cargo.domain.VocReqDomain;
import com.koreanair.cargo.persistence.ExportMapper;

@RemoteProxy(name="exportDwr")
public class ExportControllDwrServiceImpl implements ExportControllDwrService {
	
	@Autowired
	ExportMapper exportMapper;
	private static final Logger logger = LoggerFactory.getLogger(ExportControllDwrServiceImpl.class);
	
	@RemoteMethod
	public Map<String, Object> getExportMawbList(ExportReqDomain exportReqDomain) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		logger.info("0000000000000");
		System.out.println("0000000000000");
		List<ExportDomain> exportMawbList = exportMapper.exportMawbList(exportReqDomain);
		
		logger.info("exportList.size : "+Integer.toString(exportMawbList.size()));
		rtnMap.put("exportMawbList", exportMawbList);
		ModelMap modelMap = new ModelMap();
		modelMap.put("exportMawbList", exportMawbList);
		
		return rtnMap;
	}
	
	@RemoteMethod
	public Map<String, Object> getExportMawbHawbList(ExportReqDomain exportReqDomain) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		logger.info("0000000000000");
		System.out.println("0000000000000");
		List<ExportDomain> exportMawbList = exportMapper.exportMawbHawbList(exportReqDomain);
		
		logger.info("exportList.size : "+Integer.toString(exportMawbList.size()));
		rtnMap.put("exportMawbList", exportMawbList);
		ModelMap modelMap = new ModelMap();
		modelMap.put("exportMawbList", exportMawbList);
		
		return rtnMap;
	}
	
	@RemoteMethod
	public Map<String, Object> getExportMawbInfo(ExportReqDomain exportReqDomain) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		logger.info("-----------------------------------------------------------------");
		logger.info("exportReqDomain : " + exportReqDomain.getMawb_no());
		logger.info("exportReqDomain : " + exportReqDomain.getFlt_d());
		logger.info("exportReqDomain : " + exportReqDomain.getCarr_c());
		logger.info("exportReqDomain : " + exportReqDomain.getFlt_no());
		logger.info("-----------------------------------------------------------------");
		
		ExportDomain exportMawbInfo = new ExportDomain();
		try {
			exportMawbInfo = exportMapper.exportMawbInfo(exportReqDomain);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		ModelMap modelMap = new ModelMap();
		modelMap.put("exportMawbInfo", exportMawbInfo);
		
		rtnMap.put("exportMawbInfo", exportMawbInfo);
		   
		return rtnMap;
	}

	@Override
	public Map<String, Object> getVocCityList(VocReqDomain vocReqDomain) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
