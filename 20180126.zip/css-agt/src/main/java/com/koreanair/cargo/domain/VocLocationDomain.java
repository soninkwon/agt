package com.koreanair.cargo.domain;

import java.io.IOException;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;
import org.springframework.web.multipart.MultipartFile;

@DataTransferObject(type="bean", javascript="vocTypeDomain")

public class VocLocationDomain {
	
	private String voc_loc_cd       = "";
	private String voc_loc_desc       = "";
	private String voc_loc_lang      = "";
	
	public String getVoc_loc_cd() {
		return voc_loc_cd;
	}
	public void setVoc_loc_cd(String voc_loc_cd) {
		this.voc_loc_cd = voc_loc_cd;
	}
	public String getVoc_loc_desc() {
		return voc_loc_desc;
	}
	public void setVoc_loc_desc(String voc_loc_desc) {
		this.voc_loc_desc = voc_loc_desc;
	}
	public String getVoc_loc_lang() {
		return voc_loc_lang;
	}
	public void setVoc_loc_lang(String voc_loc_lang) {
		this.voc_loc_lang = voc_loc_lang;
	}
	
		
	
}
