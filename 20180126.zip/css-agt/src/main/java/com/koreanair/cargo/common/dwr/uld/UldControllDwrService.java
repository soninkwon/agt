package com.koreanair.cargo.common.dwr.uld;

import java.util.List;
import java.util.Map;

import com.koreanair.cargo.domain.uld.UldReqDomain;

public interface UldControllDwrService {
	public Map<String,Object> getUldCityList2 (UldReqDomain uldReqDomain);
}
