package com.koreanair.cargo.persistence;

import java.util.List;

import com.koreanair.cargo.domain.UserInfoDomain;
import com.koreanair.cargo.domain.UserInfoReqDomain;

public interface UserInfoMapper {
	UserInfoDomain getUserList(UserInfoReqDomain reqDomain);
	
}
