package com.koreanair.cargo.persistence;

import java.util.List;

import com.koreanair.cargo.domain.AwbInfoDomain;
import com.koreanair.cargo.domain.EawbReqDomain;
import com.koreanair.cargo.domain.ExportReqDomain;
import com.koreanair.cargo.domain.ExportDomain;
import com.koreanair.cargo.domain.ExportEpnDomain;

public interface ExportMapper {
	List<AwbInfoDomain> waitAwbList(EawbReqDomain reqDomain);
	
	List<ExportDomain> exportMawbList(ExportReqDomain reqDomain);
	
	ExportDomain exportMawbInfo(ExportReqDomain reqDomain);
	
	List<ExportEpnDomain> exportMawbEpnList(ExportReqDomain reqDomain);
	
	List<ExportEpnDomain> exportHawbList(ExportReqDomain reqDomain);
	
	List<ExportDomain> exportMawbHawbList(ExportReqDomain reqDomain);
	
}
