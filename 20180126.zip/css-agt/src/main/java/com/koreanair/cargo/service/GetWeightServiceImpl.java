package com.koreanair.cargo.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.rmi.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


@Service
public class GetWeightServiceImpl implements GetWeightService {
	
	private static final Logger logger = LoggerFactory.getLogger(GetWeightServiceImpl.class);
	
	Socket ssocket = null;
	
	BufferedWriter out;
	BufferedReader in;
	Thread thr;
	String ss = "";
	@Override
	public String getWeighing(String Url) {
		try {
			logger.debug("ssocket  :  ");
			ssocket = new Socket(Url,2011);
			out = new BufferedWriter(new OutputStreamWriter(ssocket.getOutputStream()));
			in = new BufferedReader(new InputStreamReader(ssocket.getInputStream()));
		} catch (UnknownHostException e) {
			e.printStackTrace();
			logger.debug("UnknownHostException  :  "+e.toString());
			try {
				in.close();
				ssocket.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.debug("IOException :"+e.toString());
			try {
				in.close();
				ssocket.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}catch (Exception xx ) 
		{
			xx.printStackTrace();
			
			logger.debug("Exception :"+xx.toString());
			try {
				in.close();
				ssocket.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		}
		try{
			boolean isFauls = true;
			int i = 0;
			StringBuffer buffer = new StringBuffer();
			buffer.append("<msg><get type='weight_loose'/></msg>");	
			buffer.append("\n");
			logger.debug(buffer.toString());
			
			out.flush();
			
			while(isFauls){
				logger.debug("isFauls :"+isFauls);
			//out = new BufferedWriter(new OutputStreamWriter(ssocket.getOutputStream()));				
			
			ss =in.readLine();
			logger.debug("out :");
			logger.debug(ss);
			i++;
			if(i>20 || (ss != null && !ss.equals("") && ss.split(",")[0].equals("ST") ))
				isFauls = false;
			}
			in.close();
			//out.close();
			ssocket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.debug("IOException :"+e.toString());
			try {
				in.close();
				ssocket.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return setMsg(ss);
		
		
	}
	public String setMsg(String msg) {
		String rtnMsg = "";
		System.out.println("setMsg ===== "+msg);
		System.out.println("setMsg ===== "+msg.split("kg").length);
		System.out.println("setMsg ===== "+msg.split("kg")[0].length());
		System.out.println("setMsg ===== "+"22222211113333".length());
		System.out.println("setMsg ===== "+msg.split("kg")[0].substring(msg.split("kg")[0].length()-9,msg.split("kg")[0].length()));
		//System.out.println("setMsg ===== "+msg.split("?")[1].split("kg").length);
		//System.out.println("setMsg ===== "+msg.split("?")[1].split("kg"));
		rtnMsg = msg.split("kg")[0].substring(msg.split("kg")[0].length()-9,msg.split("kg")[0].length()).trim();
		return rtnMsg;
	}
}
