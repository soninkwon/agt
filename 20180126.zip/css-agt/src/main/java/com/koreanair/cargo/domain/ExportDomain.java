package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="exportDomain")
public class ExportDomain {
	
	
	private String mawb_no;
	private String hawb_no;
	private String flt_d;
	private String carr_c;
	private String flt_no;
	private String pc_q;
	private String wt_m;
	
	
	private String mrn_n        = "";
	private String msn_n        = "";
	private String dt_flt        = "";
	private String transportmeansreferenceid = "";
	private String result_sts      = "";
	private String err_msg         = "";
	private String awb_typ_c       = "";
	private String cgo_load_c      = "";
	private String cgo_typ_c       = "";
	private String dep_c           = "";
	private String arr_c           = "";
	private String org_c           = "";
	private String dst_c           = "";
	private String ttl_pc          = "";
	private String wtu_c           = "";
	private String ttl_wt          = "";
	private String spcl_cmod_c1    = "";
	private String spcl_cmod_c2    = "";
	private String spcl_cmod_c3    = "";
	private String cmod_n    = "";
	private String ucr_id          = "";
	private String wh_loc_c        = "";
	private String fwdr_c          = "";
	private String fwdr_n          = "";
	private String shpr_c          = "";
	private String shpr_n          = "";
	private String shpr_a          = "";
	private String shpr_cou_c      = "";
	private String shpr_zip        = "";
	private String shpr_tel        = "";
	private String shpr_fax        = "";
	private String cnee_c          = "";
	private String cnee_n          = "";
	private String cnee_a          = "";
	private String cnee_cou_c      = "";
	private String cnee_zip        = "";
	private String cnee_tel        = "";
	private String cnee_fax        = "";
	private String cd_agt        = "";
	
	@RemoteProperty
	public String getMawb_no() {
		return mawb_no;
	}
	public void setMawb_no(String mawb_no) {
		this.mawb_no = mawb_no;
	}
	
	@RemoteProperty
	public String getHawb_no() {
		return hawb_no;
	}
	public void setHawb_no(String hawb_no) {
		this.hawb_no = hawb_no;
	}
	
	@RemoteProperty
	public String getFlt_d() {
		return flt_d;
	}
	public void setFlt_d(String flt_d) {
		this.flt_d = flt_d;
	}
	
	@RemoteProperty
	public String getCarr_c() {
		return carr_c;
	}
	public void setCarr_c(String carr_c) {
		this.carr_c = carr_c;
	}
	
	@RemoteProperty
	public String getFlt_no() {
		return flt_no;
	}
	public void setFlt_no(String flt_no) {
		this.flt_no = flt_no;
	}
	
	@RemoteProperty
	public String getPc_q() {
		return pc_q;
	}
	public void setPc_q(String pc_q) {
		this.pc_q = pc_q;
	}
	
	@RemoteProperty
	public String getWt_m() {
		return wt_m;
	}
	public void setWt_m(String wt_m) {
		this.wt_m = wt_m;
	}
	@RemoteProperty
	public String getMrn_n() {
		return mrn_n;
	}
	public void setMrn_n(String mrn_n) {
		this.mrn_n = mrn_n;
	}
	@RemoteProperty
	public String getMsn_n() {
		return msn_n;
	}
	public void setMsn_n(String msn_n) {
		this.msn_n = msn_n;
	}
	@RemoteProperty
	public String getDt_flt() {
		return dt_flt;
	}
	public void setDt_flt(String dt_flt) {
		this.dt_flt = dt_flt;
	}
	@RemoteProperty
	public String getTransportmeansreferenceid() {
		return transportmeansreferenceid;
	}
	public void setTransportmeansreferenceid(String transportmeansreferenceid) {
		this.transportmeansreferenceid = transportmeansreferenceid;
	}
	@RemoteProperty
	public String getResult_sts() {
		return result_sts;
	}
	public void setResult_sts(String result_sts) {
		this.result_sts = result_sts;
	}
	@RemoteProperty
	public String getErr_msg() {
		return err_msg;
	}
	public void setErr_msg(String err_msg) {
		this.err_msg = err_msg;
	}
	@RemoteProperty
	public String getAwb_typ_c() {
		return awb_typ_c;
	}
	public void setAwb_typ_c(String awb_typ_c) {
		this.awb_typ_c = awb_typ_c;
	}
	@RemoteProperty
	public String getCgo_load_c() {
		return cgo_load_c;
	}
	public void setCgo_load_c(String cgo_load_c) {
		this.cgo_load_c = cgo_load_c;
	}
	@RemoteProperty
	public String getCgo_typ_c() {
		return cgo_typ_c;
	}
	public void setCgo_typ_c(String cgo_typ_c) {
		this.cgo_typ_c = cgo_typ_c;
	}
	@RemoteProperty
	public String getDep_c() {
		return dep_c;
	}
	public void setDep_c(String dep_c) {
		this.dep_c = dep_c;
	}
	@RemoteProperty
	public String getArr_c() {
		return arr_c;
	}
	public void setArr_c(String arr_c) {
		this.arr_c = arr_c;
	}
	@RemoteProperty
	public String getOrg_c() {
		return org_c;
	}
	public void setOrg_c(String org_c) {
		this.org_c = org_c;
	}
	@RemoteProperty
	public String getDst_c() {
		return dst_c;
	}
	public void setDst_c(String dst_c) {
		this.dst_c = dst_c;
	}
	@RemoteProperty
	public String getTtl_pc() {
		return ttl_pc;
	}
	public void setTtl_pc(String ttl_pc) {
		this.ttl_pc = ttl_pc;
	}
	@RemoteProperty
	public String getWtu_c() {
		return wtu_c;
	}
	public void setWtu_c(String wtu_c) {
		this.wtu_c = wtu_c;
	}
	@RemoteProperty
	public String getTtl_wt() {
		return ttl_wt;
	}
	public void setTtl_wt(String ttl_wt) {
		this.ttl_wt = ttl_wt;
	}
	@RemoteProperty
	public String getSpcl_cmod_c1() {
		return spcl_cmod_c1;
	}
	public void setSpcl_cmod_c1(String spcl_cmod_c1) {
		this.spcl_cmod_c1 = spcl_cmod_c1;
	}
	@RemoteProperty
	public String getSpcl_cmod_c2() {
		return spcl_cmod_c2;
	}
	public void setSpcl_cmod_c2(String spcl_cmod_c2) {
		this.spcl_cmod_c2 = spcl_cmod_c2;
	}
	@RemoteProperty
	public String getSpcl_cmod_c3() {
		return spcl_cmod_c3;
	}
	public void setSpcl_cmod_c3(String spcl_cmod_c3) {
		this.spcl_cmod_c3 = spcl_cmod_c3;
	}
	@RemoteProperty
	public String getCmod_n() {
		return cmod_n;
	}
	public void setCmod_n(String cmod_n) {
		this.cmod_n = cmod_n;
	}
	@RemoteProperty
	public String getUcr_id() {
		return ucr_id;
	}
	public void setUcr_id(String ucr_id) {
		this.ucr_id = ucr_id;
	}
	@RemoteProperty
	public String getWh_loc_c() {
		return wh_loc_c;
	}
	public void setWh_loc_c(String wh_loc_c) {
		this.wh_loc_c = wh_loc_c;
	}
	@RemoteProperty
	public String getFwdr_c() {
		return fwdr_c;
	}
	public void setFwdr_c(String fwdr_c) {
		this.fwdr_c = fwdr_c;
	}
	@RemoteProperty
	public String getFwdr_n() {
		return fwdr_n;
	}
	public void setFwdr_n(String fwdr_n) {
		this.fwdr_n = fwdr_n;
	}
	@RemoteProperty
	public String getShpr_c() {
		return shpr_c;
	}
	public void setShpr_c(String shpr_c) {
		this.shpr_c = shpr_c;
	}
	@RemoteProperty
	public String getShpr_n() {
		return shpr_n;
	}
	public void setShpr_n(String shpr_n) {
		this.shpr_n = shpr_n;
	}
	@RemoteProperty
	public String getShpr_a() {
		return shpr_a;
	}
	public void setShpr_a(String shpr_a) {
		this.shpr_a = shpr_a;
	}
	@RemoteProperty
	public String getShpr_cou_c() {
		return shpr_cou_c;
	}
	public void setShpr_cou_c(String shpr_cou_c) {
		this.shpr_cou_c = shpr_cou_c;
	}
	@RemoteProperty
	public String getShpr_zip() {
		return shpr_zip;
	}
	public void setShpr_zip(String shpr_zip) {
		this.shpr_zip = shpr_zip;
	}
	@RemoteProperty
	public String getShpr_tel() {
		return shpr_tel;
	}
	public void setShpr_tel(String shpr_tel) {
		this.shpr_tel = shpr_tel;
	}
	@RemoteProperty
	public String getShpr_fax() {
		return shpr_fax;
	}
	public void setShpr_fax(String shpr_fax) {
		this.shpr_fax = shpr_fax;
	}
	@RemoteProperty
	public String getCnee_c() {
		return cnee_c;
	}
	
	public void setCnee_c(String cnee_c) {
		this.cnee_c = cnee_c;
	}
	@RemoteProperty
	public String getCnee_n() {
		return cnee_n;
	}
	public void setCnee_n(String cnee_n) {
		this.cnee_n = cnee_n;
	}
	@RemoteProperty
	public String getCnee_a() {
		return cnee_a;
	}
	public void setCnee_a(String cnee_a) {
		this.cnee_a = cnee_a;
	}
	@RemoteProperty
	public String getCnee_cou_c() {
		return cnee_cou_c;
	}
	public void setCnee_cou_c(String cnee_cou_c) {
		this.cnee_cou_c = cnee_cou_c;
	}
	@RemoteProperty
	public String getCnee_zip() {
		return cnee_zip;
	}
	public void setCnee_zip(String cnee_zip) {
		this.cnee_zip = cnee_zip;
	}
	@RemoteProperty
	public String getCnee_tel() {
		return cnee_tel;
	}
	public void setCnee_tel(String cnee_tel) {
		this.cnee_tel = cnee_tel;
	}
	@RemoteProperty
	public String getCnee_fax() {
		return cnee_fax;
	}
	public void setCnee_fax(String cnee_fax) {
		this.cnee_fax = cnee_fax;
	}
	@RemoteProperty
	public String getCd_agt() {
		return cd_agt;
	}
	public void setCd_agt(String cd_agt) {
		this.cd_agt = cd_agt;
	}

	
	
	
	
}