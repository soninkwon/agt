package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="userInfoReqDomain")
public class UserInfoReqDomain {
	
	
	private String fwdrCd1 = "";
	private String fwdrCd2 = "";
	private String fwdrGbn = "";
	
	@RemoteProperty
	public String getFwdrCd1() {
		return fwdrCd1;
	}
	public void setFwdrCd1(String fwdrCd1) {
		this.fwdrCd1 = fwdrCd1;
	}
	
	@RemoteProperty
	public String getFwdrCd2() {
		return fwdrCd2;
	}
	public void setFwdrCd2(String fwdrCd2) {
		this.fwdrCd2 = fwdrCd2;
	}
	
	@RemoteProperty
	public String getFwdrGbn() {
		return fwdrGbn;
	}
	public void setFwdrGbn(String fwdrGbn) {
		this.fwdrGbn = fwdrGbn;
	}
	
	
			
	
}