package com.koreanair.cargo.service;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.koreanair.cargo.domain.EawbReqDomain;
import com.koreanair.cargo.domain.VolumnWebDomain;
import com.koreanair.cargo.persistence.CommonMapper;

@Service
public class CommonServiceImple implements CommonService {
	private static final Logger logger = LoggerFactory.getLogger(CommonServiceImple.class);
	@Autowired
	CommonMapper commonMapper;
	@Override
	public List<Map<String, Object>> getTrmlList() {
		return commonMapper.getTrmlList();
	}
	@Override
	public List<Map<String, Object>> selectWeighingIpList(EawbReqDomain reqDomain) {
		return commonMapper.selectWeighingIpList(reqDomain);
	}
	@Override
	public Map<String,Object> volChkWebSvc (VolumnWebDomain volWebDomain) throws JsonProcessingException {
		
		Map<String,Object> rtnDomain = null;
		// TODO Auto-generated method stub
		/*TrustManager easyTrustManager = new X509TrustManager(){
			public void checkClientTrusted1(X509Certificate[] chain,
					String authType) throws CertificateException {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
				// TODO Auto-generated method stub
				
			}
			@Override
			public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {
				// TODO Auto-generated method stub
				
			}
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				// TODO Auto-generated method stub
				return null;
			}
		};
		SSLContext ctx = SSLContext.getInstance("TLS");
		ctx.init(new KeyManager[0], new TrustManager[] {easyTrustManager}, new SecureRandom());
		SSLContext.setDefault(ctx);*/
		
		ObjectMapper mapper = new ObjectMapper();
		//String json = mapper.writeValueAsString(volWebDomain);
		String json ="CARR_C=KE&FLT_D=20170801&STN_C=ICN&VOL_LOC=VOL01&FLT_NO=401&MAWB_NO=180111111";
		try { 
		 
		  URL url = new URL("http://10.111.16.166:8080/api/volCheck");

        //HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
        
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        //connection.setRequestMethod("GET");
        connection.setRequestMethod("POST");

        connection.setRequestProperty("Application", "*/*; charset=UTF-8");
        
        connection.setDoOutput(true); // GET인 경우 필요 없음

        connection.setDoInput(true);
        
       
        
        connection.setRequestProperty("Content-Length",String.valueOf(json.getBytes().length));
        
       /* connection.setHostnameVerifier(new HostnameVerifier(){

			@Override
			public boolean verify(String arg0, SSLSession arg1) {
				// TODO Auto-generated method stub
				return false;
			}
        	
        });*/
        
        

        // {

        // "name": "홍길동",

        // "age": 30,

        // "phone": "01012345678"

        // }
        OutputStream outputStream = connection.getOutputStream();

        DataOutputStream output = new DataOutputStream(outputStream); // 이 때
                                                                                                                  // 커넥션이
                                                                                                                  // 연결되고
                                                                                                                  // 전송하기
                                                                                                                  // 위한
                                                                                                                  // output
                                                                                                                  // stream을
                                                                                                                  // 가져옴
        logger.info(json);
        output.write(json.getBytes("UTF-8")); // 전문 전송

        output.flush(); // 전문이 끝남을 알림

        output.close(); // 스트림 닫아줌
        
        try{
        	InputStream in = null;
        	int resCode = connection.getResponseCode();
        
        	logger.info("resCode :  "+resCode);
        	if(resCode != HttpsURLConnection.HTTP_OK)
        		logger.info("1 :  ");
        	else
        		in = connection.getInputStream();
        	InputStreamReader inputstreamreader = new InputStreamReader(in,"UTF-8");

                                                                                                                        // stream을
                                                                                                                         // 가져옴

        	BufferedReader br = new BufferedReader(inputstreamreader); // 버퍼
                                                                                                                         // 리더로
                                                                                                                         // input
                                                                                                                         // stream의
                                                                                                                         // 데이터를
	        StringBuffer response = new StringBuffer();                                                                                                                 // 읽어옴
	
	        String inputLine = null;
	        while((inputLine = br.readLine()) != null) { // 한 줄 씩 읽어서 그 값이
	            response.append(inputLine);
	        }
	        logger.info(response.toString());
	        rtnDomain = mapper.readValue(response.toString(), Map.class);
	      
        }catch(Exception e){
        	e.printStackTrace();
        }
		}catch(Exception e) {
			e.printStackTrace();
		}
        return rtnDomain;
        
		
	}
}
