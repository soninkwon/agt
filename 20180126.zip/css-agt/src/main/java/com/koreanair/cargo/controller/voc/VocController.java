package com.koreanair.cargo.controller.voc;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.MultipartRequest;

import com.koreanair.cargo.persistence.VocMapper;
import com.koreanair.cargo.service.ComUtil;
import com.koreanair.cargo.service.CommonService;
import com.koreanair.cargo.service.VocService;
import com.koreanair.cargo.domain.VocReqDomain;

import com.safenet.datasecure.*;
import com.safenet.datasecure.crypto.exceptions.CryptoException;

/**
 * Handles requests for the application Voc page.
 * @author v.dkkang
 * @date 2017.11.03
 */

@Controller
@RequestMapping(value = "voc")
public class VocController {
	@Autowired
	CommonService commonService;
	
	@Autowired
	VocService vocService;
	
	@Autowired
	VocMapper vocMapper;
	
	private static final Logger logger = LoggerFactory.getLogger(VocController.class);
	private static String UPLOADED_FOLDER = "d:\\css-agt1\\file\\";
	
	@RequestMapping(value = "/vocInsertForm.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String vocInsertFormControll(HttpServletRequest req, HttpSession session, ModelMap modelMap, VocReqDomain vocReqDomain) {
		
		
		//vocReqDomain.setCdRgn("MMM");
		modelMap.put("vocReqDomain", vocReqDomain);
		//modelMap.put("vocCityList", vocMapper.vocList(vocReqDomain));
		
		logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++11111");
		logger.info("000000000000000000 : " + req.getParameter("cdRgn"));

		
		return "/voc/vocInsertForm";
	}
	
	@RequestMapping(value = "/vocInsert.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String vocInsert(HttpServletRequest req, HttpSession session, ModelMap modelMap, VocReqDomain vocReqDomain) {
		
		
		modelMap.put("vocReqDomain", vocReqDomain);
		
		req.setAttribute("modelMap", vocReqDomain);
		
		modelMap.put("vocCityList", vocMapper.vocInsert(vocReqDomain));
		
		logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++11111");
		logger.info("000000000000000000 : " + req.getParameter("cdRgn"));
	
		
		return "/voc/vocInsertForm";
	}
	
	
	@RequestMapping(value = "/vocForm.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String vocForm(HttpServletRequest req, HttpSession session, ModelMap modelMap, VocReqDomain vocReqDomain) {
		
		
		if (ComUtil.null2str(req.getParameter("lang")).toUpperCase().equals("KO_KR")) {
			vocReqDomain.setLang("kr");
		}else {
			vocReqDomain.setLang(req.getParameter("lang"));
		}
		
		String ip1 = ComUtil.null2str(req.getHeader("X-FORWARDED-FOR"));
		String ip2 = ComUtil.null2str(req.getRemoteAddr());//ip 가져오기
		String ip3 = ComUtil.null2str(req.getHeader("Proxy-Client-IP"));
		String ip_addr = "";
		
		logger.info("########ip1##########" + ip1);
		logger.info("########ip2##########" + ip2);
		logger.info("########ip3##########" + ip3);
		
		if (!"".equals(ip1)) {
			ip_addr = ip1;
		}else if (!"".equals(ip2)) {
			ip_addr = ip2;
		}else if (!"".equals(ip3)) {
			ip_addr = ip3;
		}
		
		if ("".equals(ip_addr)) {
			ip_addr = " ";
		}
		
		logger.info("########ip_addr##########" + ip_addr);
		
		vocReqDomain.setIp_addr(ip_addr);
		
		modelMap.put("vocReqDomain", vocReqDomain);
		
		modelMap.put("vocTypeList", vocMapper.vocTypeList(vocReqDomain));
		modelMap.put("vocCateList", vocMapper.vocCateList(vocReqDomain));
		modelMap.put("vocCateList2", vocMapper.vocCateList2(vocReqDomain));
		modelMap.put("vocLocationList", vocMapper.vocLocationList(vocReqDomain));
		
		return "/voc/vocForm";
	}
	
	
	@RequestMapping(value = "/vocInput.do",consumes = {"multipart/form-data"}, method = {RequestMethod.POST})
	public String vocInput(MultipartHttpServletRequest request, HttpServletResponse response, @RequestPart(value = "filedata", required = false) MultipartFile filedata, HttpServletRequest req, HttpSession session, ModelMap modelMap, VocReqDomain vocReqDomain) {
		
		if (ComUtil.null2str(request.getParameter("lang")).toUpperCase().equals("KO_KR")) {
			vocReqDomain.setLang("kr");
		}else {
			vocReqDomain.setLang(request.getParameter("lang"));
		}
		
		modelMap.put("vocTypeList", vocMapper.vocTypeList(vocReqDomain));
		modelMap.put("vocCateList", vocMapper.vocCateList(vocReqDomain));
		modelMap.put("vocCateList2", vocMapper.vocCateList2(vocReqDomain));
		modelMap.put("vocLocationList", vocMapper.vocLocationList(vocReqDomain));
		
		String result_txt = vocService.getVocCheckInput(vocReqDomain);
		
		vocReqDomain.setResult_txt(result_txt);
		
		logger.info("########################################");
		logger.info("result_txt : " + result_txt);
		
		modelMap.put("vocReqDomain", vocReqDomain);
		modelMap.put("vocInput", result_txt);
		
		//새로고침해서 계속 INPUT 되는것을 막기 위해 redirect 로 했음 
		return "redirect:/voc/vocForm.do?lang="+vocReqDomain.getLang();
	}
	
	
	@RequestMapping(value = "/vocFileUploadInput.do",consumes = {"multipart/form-data"}, method = {RequestMethod.POST})
	public String vocFileUploadInput(MultipartHttpServletRequest request, HttpServletResponse response, @RequestPart(value = "filedata", required = false) MultipartFile filedata, HttpServletRequest req, HttpSession session, ModelMap modelMap, VocReqDomain vocReqDomain, @RequestParam("file_name1") MultipartFile[] uploadfiles) {
		
		
		modelMap.put("vocReqDomain", vocReqDomain);
		
		req.setAttribute("modelMap", vocReqDomain);
		
		logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++11111");
		logger.info("getMailFrom : " + vocReqDomain.getMailFrom());
		logger.info("getMailFromName : " + vocReqDomain.getMailFromName());
		logger.info("getMailFromName1 : " + vocReqDomain.getMailFromName1());
		logger.info("getMailFromName2 : " + vocReqDomain.getMailFromName2());
		
		String uploadedFileName = Arrays.stream(uploadfiles).map(x -> x.getOriginalFilename())
                .filter(x -> !StringUtils.isEmpty(x)).collect(Collectors.joining(" , "));
        
        try {
			//saveUploadedFiles(Arrays.asList(uploadfiles), vocReqDomain);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		modelMap.put("vocInput", vocMapper.vocInput(vocReqDomain));
		
		return "/voc/vocForm";
	}
	
	//save file
		private void saveUploadedFiles(List<MultipartFile> files, VocReqDomain vocReqDomain) throws IOException{
			for(MultipartFile file : files) {
				if(file.isEmpty()) {
					continue;
				}
				byte[] bytes = file.getBytes();
				//vocReqDomain.setFile_name1(bytes);
				//Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
				Path path = Paths.get(UPLOADED_FOLDER + "1212");
				Files.write(path, bytes);
			}
		}
	
	

}
