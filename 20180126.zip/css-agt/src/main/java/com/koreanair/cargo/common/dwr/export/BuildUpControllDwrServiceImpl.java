package com.koreanair.cargo.common.dwr.export;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.directwebremoting.annotations.RemoteMethod;
import org.directwebremoting.annotations.RemoteProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.koreanair.cargo.domain.AwbInfoDomain;
import com.koreanair.cargo.domain.EawbReqDomain;
import com.koreanair.cargo.persistence.ExportMapper;

@RemoteProxy(name="buildup")
public class BuildUpControllDwrServiceImpl implements BuildUpControllDwrService {
	
	@Autowired
	ExportMapper exportMapper;
	private static final Logger logger = LoggerFactory.getLogger(BuildUpControllDwrServiceImpl.class);
	
	@RemoteMethod
	public Map<String, Object> getBuildUpInfo(EawbReqDomain reqDomain) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		logger.info("0000000000000");
		System.out.println("0000000000000");
		List<AwbInfoDomain> waitAwbList = exportMapper.waitAwbList(reqDomain);
		logger.info("11111111111");
		logger.info("222222222222222"+Integer.toString(waitAwbList.size()));
		rtnMap.put("waitAwbList", waitAwbList);
		
		return rtnMap;
	}

}
