package com.koreanair.cargo.persistence;

import java.util.List;
import java.util.Map;

import com.koreanair.cargo.domain.EawbReqDomain;


public interface CommonMapper {
	List<Map<String, Object>> getTrmlList(); 
	
	List<Map<String, Object>> selectWeighingIpList(EawbReqDomain domain); 
}
