package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="vocReqDomain")

public class VocCityDomain {
	
	private String apo_cd;
	private String city_cd;
	private String city_nm;
	
	public String getApo_cd() {
		return apo_cd;
	}
	public void setApo_cd(String apo_cd) {
		this.apo_cd = apo_cd;
	}
	public String getCity_cd() {
		return city_cd;
	}
	public void setCity_cd(String city_cd) {
		this.city_cd = city_cd;
	}
	public String getCity_nm() {
		return city_nm;
	}
	public void setCity_nm(String city_nm) {
		this.city_nm = city_nm;
	}
	

		
	
	
}
