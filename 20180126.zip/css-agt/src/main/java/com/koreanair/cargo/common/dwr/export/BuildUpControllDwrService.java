package com.koreanair.cargo.common.dwr.export;

import java.util.List;
import java.util.Map;

import com.koreanair.cargo.domain.EawbReqDomain;

public interface BuildUpControllDwrService {
	public Map<String,Object> getBuildUpInfo (EawbReqDomain reqDomain);
}
