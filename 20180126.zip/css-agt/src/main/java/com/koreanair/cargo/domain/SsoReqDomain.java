package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="ssoReqDomain")

public class SsoReqDomain {
	
	private String userIdentifier         = "";
	private String originIdentification   = "";
	private String inHouseIdentification1 = "";
	private String originatorTypeCode     = "";
	private String originator             = "";
	private String dutyCode               = "";
	private String referenceDetails       = "";
	private String value                  = "";
	private String systemDetails          = "";
	private String deliveringSystem       = "";
	private String companyId              = "";
	private String passwordInformation    = "";
	private String passwordDetails        = "";
	private String encryptionDetails      = "";
	private String algorithmType          = "";
	private String timestamp              = "";
	private String encryptionToken        = "";
	private String passwordType           = "";
	private String password               = "";
	private String dataLength             = "";
	private String dataType               = "";
	private String binaryData             = "";
	private String applicationId          = "";
	private String applicationDetails     = "";
	private String versionNumber          = "";
	private String label                  = "";
	
	public String getUserIdentifier() {
		return userIdentifier;
	}
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}
	public String getOriginIdentification() {
		return originIdentification;
	}
	public void setOriginIdentification(String originIdentification) {
		this.originIdentification = originIdentification;
	}
	public String getInHouseIdentification1() {
		return inHouseIdentification1;
	}
	public void setInHouseIdentification1(String inHouseIdentification1) {
		this.inHouseIdentification1 = inHouseIdentification1;
	}
	public String getOriginatorTypeCode() {
		return originatorTypeCode;
	}
	public void setOriginatorTypeCode(String originatorTypeCode) {
		this.originatorTypeCode = originatorTypeCode;
	}
	public String getOriginator() {
		return originator;
	}
	public void setOriginator(String originator) {
		this.originator = originator;
	}
	public String getDutyCode() {
		return dutyCode;
	}
	public void setDutyCode(String dutyCode) {
		this.dutyCode = dutyCode;
	}
	public String getReferenceDetails() {
		return referenceDetails;
	}
	public void setReferenceDetails(String referenceDetails) {
		this.referenceDetails = referenceDetails;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getSystemDetails() {
		return systemDetails;
	}
	public void setSystemDetails(String systemDetails) {
		this.systemDetails = systemDetails;
	}
	public String getDeliveringSystem() {
		return deliveringSystem;
	}
	public void setDeliveringSystem(String deliveringSystem) {
		this.deliveringSystem = deliveringSystem;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getPasswordInformation() {
		return passwordInformation;
	}
	public void setPasswordInformation(String passwordInformation) {
		this.passwordInformation = passwordInformation;
	}
	public String getPasswordDetails() {
		return passwordDetails;
	}
	public void setPasswordDetails(String passwordDetails) {
		this.passwordDetails = passwordDetails;
	}
	public String getEncryptionDetails() {
		return encryptionDetails;
	}
	public void setEncryptionDetails(String encryptionDetails) {
		this.encryptionDetails = encryptionDetails;
	}
	public String getAlgorithmType() {
		return algorithmType;
	}
	public void setAlgorithmType(String algorithmType) {
		this.algorithmType = algorithmType;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getEncryptionToken() {
		return encryptionToken;
	}
	public void setEncryptionToken(String encryptionToken) {
		this.encryptionToken = encryptionToken;
	}
	public String getPasswordType() {
		return passwordType;
	}
	public void setPasswordType(String passwordType) {
		this.passwordType = passwordType;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getDataLength() {
		return dataLength;
	}
	public void setDataLength(String dataLength) {
		this.dataLength = dataLength;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getBinaryData() {
		return binaryData;
	}
	public void setBinaryData(String binaryData) {
		this.binaryData = binaryData;
	}
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public String getApplicationDetails() {
		return applicationDetails;
	}
	public void setApplicationDetails(String applicationDetails) {
		this.applicationDetails = applicationDetails;
	}
	public String getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(String versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	
	
	
	
	
	
	
}
