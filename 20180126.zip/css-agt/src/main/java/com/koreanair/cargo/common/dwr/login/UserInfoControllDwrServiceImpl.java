package com.koreanair.cargo.common.dwr.login;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.directwebremoting.annotations.RemoteMethod;
import org.directwebremoting.annotations.RemoteProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;

import com.koreanair.cargo.domain.UserInfoDomain;
import com.koreanair.cargo.domain.UserInfoReqDomain;
import com.koreanair.cargo.persistence.UserInfoMapper;

@RemoteProxy(name="userInfoDwr")
public class UserInfoControllDwrServiceImpl implements UserInfoControllDwrService {
	
	@Autowired
	UserInfoMapper userInfoMapper;
	private static final Logger logger = LoggerFactory.getLogger(UserInfoControllDwrServiceImpl.class);
	
	@RemoteMethod
	public Map<String, Object> getUserList(UserInfoReqDomain userInfoReqDomain, HttpSession session) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		logger.info("0000000000000");
		
		
		try {
			logger.info("userInfoReqDomain1 : " + userInfoReqDomain.getFwdrCd1());
			logger.info("userInfoReqDomain2 : " + userInfoReqDomain.getFwdrCd2());
			UserInfoDomain userList = userInfoMapper.getUserList(userInfoReqDomain);
			
			logger.info("userList.size : "+ userList.getReg_dtm());
			rtnMap.put("userList", userList);
			
			//세션값 초기화 해준다음 세션값 다시 넣는다. 
			session.setAttribute("session_reg_dtm", userList.getReg_dtm());
			
			//session 값 만들어주는 service 호출한다. 
			ModelMap modelMap = new ModelMap();
			modelMap.put("userList", userList);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return rtnMap;
	}

}
