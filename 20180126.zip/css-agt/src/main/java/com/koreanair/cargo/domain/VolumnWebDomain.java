package com.koreanair.cargo.domain;

public class VolumnWebDomain {
	
	private String STN_C;
	private String VOL_LOC;
	private String CARR_C;
	private String FLT_NO;
	private String FLT_D;
	private String MAWB_NO;
	public String getSTN_C() {
		return STN_C;
	}
	public void setSTN_C(String sTN_C) {
		STN_C = sTN_C;
	}
	public String getVOL_LOC() {
		return VOL_LOC;
	}
	public void setVOL_LOC(String vOL_LOC) {
		VOL_LOC = vOL_LOC;
	}	
	public String getCARR_C() {
		return CARR_C;
	}
	public void setCARR_C(String cARR_C) {
		CARR_C = cARR_C;
	}
	public String getFLT_NO() {
		return FLT_NO;
	}
	public void setFLT_NO(String fLT_NO) {
		FLT_NO = fLT_NO;
	}
	public String getFLT_D() {
		return FLT_D;
	}
	public void setFLT_D(String fLT_D) {
		FLT_D = fLT_D;
	}
	public String getMAWB_NO() {
		return MAWB_NO;
	}
	public void setMAWB_NO(String mAWB_NO) {
		MAWB_NO = mAWB_NO;
	}

}
