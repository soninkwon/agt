package com.koreanair.cargo.persistence;

import java.util.List;

import com.koreanair.cargo.domain.VocReqDomain;
import com.koreanair.cargo.domain.VocTypeDomain;
import com.koreanair.cargo.domain.VocCateDomain;
import com.koreanair.cargo.domain.VocCateDomain2;
import com.koreanair.cargo.domain.VocCityDomain;
import com.koreanair.cargo.domain.VocLocationDomain;

public interface VocMapper {
	List<VocCityDomain> vocList(VocReqDomain vocReqDomain);
	
	int vocInsert(VocReqDomain vocReqDomain);
	
	int vocInput(VocReqDomain vocReqDomain);
	
	List<VocTypeDomain> vocTypeList(VocReqDomain vocReqDomain);
	
	List<VocCateDomain> vocCateList(VocReqDomain vocReqDomain);
	
	List<VocCateDomain2> vocCateList2(VocReqDomain vocReqDomain);
	
	List<VocLocationDomain> vocLocationList(VocReqDomain vocReqDomain);
	
}
