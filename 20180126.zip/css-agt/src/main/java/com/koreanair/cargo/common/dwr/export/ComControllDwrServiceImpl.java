package com.koreanair.cargo.common.dwr.export;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.directwebremoting.annotations.RemoteMethod;
import org.directwebremoting.annotations.RemoteProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.koreanair.cargo.domain.VocCityDomain;
import com.koreanair.cargo.domain.VocReqDomain;
import com.koreanair.cargo.persistence.ComMapper;

@RemoteProxy(name="comDwr")
public class ComControllDwrServiceImpl implements ComControllDwrService {
	
	@Autowired
	ComMapper comMapper;
	private static final Logger logger = LoggerFactory.getLogger(VocControllDwrServiceImpl.class);
	
	@RemoteMethod
	public Map<String, Object> getComCityList(VocReqDomain vocReqDomain) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		logger.info("0000000000000");
		System.out.println("0000000000000");
		List<VocCityDomain> vocCityList = comMapper.comCityList(vocReqDomain);
		logger.info("vocCityList.size : "+Integer.toString(vocCityList.size()));
		rtnMap.put("vocCityList", vocCityList);
		
		return rtnMap;
	}
	
	@RemoteMethod
	public Map<String, Object> getComCityList2(VocReqDomain vocReqDomain) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		logger.info("0000000000000");
		System.out.println("0000000000000");
		List<VocCityDomain> vocCityList = comMapper.comCityList(vocReqDomain);
		logger.info("11111111111");
		logger.info("222222222222222"+Integer.toString(vocCityList.size()));
		rtnMap.put("vocCityList", vocCityList);
		
		return rtnMap;
	}

}
