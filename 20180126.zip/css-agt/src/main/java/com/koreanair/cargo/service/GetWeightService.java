package com.koreanair.cargo.service;

public interface GetWeightService {
	public String getWeighing(String Url);
}
