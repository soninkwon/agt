package com.koreanair.cargo.controller.export;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.koreanair.cargo.domain.AwbInfoDomain;
import com.koreanair.cargo.persistence.ExportMapper;
import com.koreanair.cargo.service.CommonService;
import com.koreanair.cargo.domain.EawbReqDomain;
import com.koreanair.cargo.domain.ExportDomain;
import com.koreanair.cargo.domain.ExportEpnDomain;
import com.koreanair.cargo.domain.ExportReqDomain;

/**
 * Handles requests for the application Export page.
 * @author v.dkkang
 * @date 2017.11.03
 */

@Controller
@RequestMapping(value = "export")
public class ExportController {
	@Autowired
	CommonService commonService;
	@Autowired
	ExportMapper exportMapper;
	
	private static final Logger logger = LoggerFactory.getLogger(ExportController.class);
	
	
	@RequestMapping(value = "/popWeight.do", method = RequestMethod.POST)
	public String popWeight(HttpServletRequest req, HttpSession session, ModelMap modelMap) {
		
		EawbReqDomain reqDomain = new EawbReqDomain();
		reqDomain.setCdTrml("ICN");
				
		modelMap.put("weighingList", commonService.selectWeighingIpList(reqDomain));
		return "/export/popWeight";
	}
	@RequestMapping(value = "/buildUpControll.do", method = RequestMethod.GET)
	public String buildUpControll(HttpServletRequest req, HttpSession session, ModelMap modelMap) {
		
		EawbReqDomain reqDomain = new EawbReqDomain();
		
		reqDomain.setCdTrml("ICN");
		reqDomain.setFlightDate("20171113");
		reqDomain.setFlightNbr("KE1017");
		modelMap.put("reqDomain", reqDomain);
		modelMap.put("waitAwbList", exportMapper.waitAwbList(reqDomain));
		
		logger.info("111111111111111111", req.getParameter("flightDate"));
		logger.info("222222222222222222", req.getParameter("flightNbr"));
		
		return "/export/buildUpControll";
	}
	
	
	@RequestMapping(value = "/expHawbList.do", method = {RequestMethod.GET, RequestMethod.POST} )
	public String expHawbList(HttpServletRequest req, HttpSession session, ModelMap modelMap) {
		
		logger.info("session.getAttribute('session_reg_dtm') : " + session.getAttribute("session_reg_dtm") );
		
		return "/export/expHawbList";
	}
	
	@RequestMapping(value = "/expMawbInfo.do", method = {RequestMethod.GET, RequestMethod.POST} )
	public String expMawbList(HttpServletRequest req, HttpSession session, ModelMap modelMap, ExportReqDomain exportReqDomain) {
		
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		logger.info("-----------------------------------------------------------------");
		logger.info("exportReqDomain : " + exportReqDomain.getMawb_no());
		logger.info("exportReqDomain : " + exportReqDomain.getFlt_d());
		logger.info("exportReqDomain : " + exportReqDomain.getCarr_c());
		logger.info("exportReqDomain : " + exportReqDomain.getFlt_no());
		logger.info("-----------------------------------------------------------------");
		
		ExportDomain exportMawbInfo = new ExportDomain();
		try {
			exportMawbInfo = exportMapper.exportMawbInfo(exportReqDomain);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		modelMap.put("reqModel", exportReqDomain);
		modelMap.put("exportMawbInfo", exportMawbInfo);
		modelMap.put("exportMawbEpnList", exportMapper.exportMawbEpnList(exportReqDomain));
		modelMap.put("exportHawbList", exportMapper.exportHawbList(exportReqDomain));
		
		return "/export/expHawbList";
	}
	
	
	@RequestMapping(value = "/expHawbInfo.do", method = {RequestMethod.GET, RequestMethod.POST} )
	public String expHawbInfo(HttpServletRequest req, HttpSession session, ModelMap modelMap, ExportReqDomain exportReqDomain) {
		
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		
		logger.info("-----------------------------------------------------------------");
		logger.info("exportReqDomain : " + exportReqDomain.getMawb_no());
		logger.info("exportReqDomain : " + exportReqDomain.getFlt_d());
		logger.info("exportReqDomain : " + exportReqDomain.getCarr_c());
		logger.info("exportReqDomain : " + exportReqDomain.getFlt_no());
		logger.info("-----------------------------------------------------------------");
		
		ExportDomain exportMawbInfo = new ExportDomain();
		try {
			//exportMawbInfo = exportMapper.exportMawbInfo(exportReqDomain);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		modelMap.put("reqModel", exportReqDomain);
		//modelMap.put("exportMawbInfo", exportMawbInfo);
		//modelMap.put("exportMawbEpnList", exportMapper.exportMawbEpnList(exportReqDomain));
		//modelMap.put("exportHawbList", exportMapper.exportHawbList(exportReqDomain));
		
		return "/export/expHawbInfo";
	}
	

	@RequestMapping(value = "/index.do", method = RequestMethod.GET)
	public String indexJsp(HttpServletRequest req, HttpSession session, ModelMap modelMap) {
		
		return "/export/index";
	}

}
