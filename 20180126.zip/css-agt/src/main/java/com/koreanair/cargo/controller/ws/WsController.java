package com.koreanair.cargo.controller.ws;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;


import java.security.cert.X509Certificate; 
import javax.net.ssl.HttpsURLConnection; 
import javax.net.ssl.SSLContext; 
import javax.net.ssl.TrustManager; 
import javax.net.ssl.X509TrustManager;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;

//import java.util.Base64; 
//import com.sun.org.apache.xml.internal.security.utils.Base64;
import org.apache.commons.codec.binary.Base64;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.w3c.dom.NodeList;

import com.koreanair.cargo.domain.VocReqDomain;
import com.koreanair.cargo.domain.WsMenuDomain;
import com.koreanair.cargo.persistence.VocMapper;
import com.koreanair.cargo.persistence.WsMenuMapper;
import com.koreanair.cargo.service.CommonService;
import com.koreanair.cargo.domain.SsoReqDomain;

/**
 * Handles requests for the application Voc page.
 * @author v.dkkang
 * @date 2017.11.03
 */

@Controller
@RequestMapping(value = "ws")
public class WsController {
	@Autowired
	CommonService commonService;
	
	@Autowired
	WsMenuMapper wsMenuMapper;
	
	HttpSession session;
	
	private static final Logger logger = LoggerFactory.getLogger(WsController.class);
	
	@RequestMapping(value = "/wsClient5.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String wsClient5(HttpServletRequest req, HttpSession session, ModelMap modelMap) {
		
		StringBuffer returnMessage = new StringBuffer();
		
		try{
		StringBuffer xml =new StringBuffer();
		xml.append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"> ");
			xml.append("  <soapenv:Header></soapenv:Header>");
			xml.append("  <soapenv:Body>");
			xml.append("    <Security_AuthenticateFromAmadeus xmlns=\"http://xml.amadeus.com/Security_AuthenticateFromAmadeus_12_1_1A\">");
			xml.append("      <userIdentifier>");
			xml.append("        <originatorTypeCode>L</originatorTypeCode>");
			xml.append("        <originator>GQKP000009</originator>");
			xml.append("      </userIdentifier>");
			xml.append("      <systemDetails>");
			xml.append("        <deliveringSystem>");
			xml.append("          <companyId>KE</companyId>");
			xml.append("        </deliveringSystem>");
			xml.append("      </systemDetails>");
			xml.append("      <passwordInformation>");
			xml.append("        <passwordDetails>");
			xml.append("          <encryptionDetails>");
			xml.append("            <algorithmType>BASE64</algorithmType>");
			xml.append("          </encryptionDetails>");
			xml.append("          <passwordType>CUR</passwordType>");
			xml.append("        </passwordDetails>");
			xml.append("        <password>");
			xml.append("          <dataLength>16</dataLength>");
			xml.append("          <dataType>B</dataType>");
			xml.append("          <binaryData>MXEydzNlNHI1dA==</binaryData>");
			xml.append("        </password>");
			xml.append("      </passwordInformation>");
			xml.append("      <applicationId>");
			xml.append("        <applicationDetails>");
			xml.append("          <versionNumber>2.0</versionNumber>");
			xml.append("          <label>KALis</label>");
			xml.append("        </applicationDetails>");
			xml.append("      </applicationId>");
			xml.append("    </Security_AuthenticateFromAmadeus>");
			xml.append("  </soapenv:Body>");
			xml.append("</soapenv:Envelope>");

			
		
			//String endPoint ="https://ssoint.koreanair.com:4443/SSOWS/SecurityAuthenticateWebServiceSoapHttpPort";
			String endPoint ="http://pcodevap1.koreanair.com:8090/ppo/SecurityAutehticateWebService";
			URL url = null;
			HttpURLConnection connection = null;
			PrintWriter requestWriter = null;
			BufferedReader requestReader = null;
			returnMessage = new StringBuffer();
			
				 url = new URL(endPoint);
				
	            connection = (HttpURLConnection)url.openConnection();
	            connection.setRequestMethod("POST");
		        connection.setRequestProperty("Content-type", "text/xml; charset=utf-8");
	            connection.setRequestProperty("SOAPAction", "process");
	            connection.setDoOutput(true);
	            connection.setDoInput(true);
	            connection.setUseCaches(false);
	            connection.connect();
	           
	            requestWriter = new PrintWriter(connection.getOutputStream());
	            requestWriter.println(xml.toString());
	            requestWriter.flush();
	            requestWriter.close();
	           
			   requestReader = new BufferedReader(new InputStreamReader(connection.getInputStream(),"utf-8"));
	            String Line = requestReader.readLine();
	            while (Line != null) {
	            	returnMessage.append(Line);
	            	Line = requestReader.readLine();
	            }
	            requestReader.close();
		} catch (Exception e) {
				 //out.println( "error : "+ e);
			e.printStackTrace();
		}  
		
		logger.info("+++++++returnMessage : " + returnMessage.toString());
		
		return "/ws/wsClient4";
		
		
	}
	
	
	
	@RequestMapping(value = "/wsClient6.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String wsClientMenu(HttpServletRequest req, HttpSession session, ModelMap modelMap) {
		
		StringBuffer returnMessage = new StringBuffer();
		
		try{
		StringBuffer xml =new StringBuffer();
		xml.append(" <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:pip=\"http://PIP_Service_Library/PIP_Processing\" xmlns:pip1=\"http://PIP_Service_Library/PIP_Session\" xmlns:aut=\"http://PPO_Service_Library/Authority\"> ");
			xml.append("    <soapenv:Body>");
			xml.append("       <aut:Authority>");
			xml.append("          <aut:identification>");
			xml.append("             <aut:SsoLoginId>GQFX000006</aut:SsoLoginId>");
			xml.append("             <aut:SystemId>CUS</aut:SystemId>");
			//xml.append("             <aut:SystemId>PNS</aut:SystemId>");
			//xml.append("             <aut:SystemId>ACPS</aut:SystemId>");
			//xml.append("             <aut:SystemId>MHS</aut:SystemId>");
			//xml.append("             <aut:SystemId>GPS</aut:SystemId>");
			xml.append("          </aut:identification>");
			xml.append("       </aut:Authority>");
			xml.append("    </soapenv:Body>");
			xml.append(" </soapenv:Envelope>");


			
		
			String endPoint ="http://pcodevap1.koreanair.com:8090/ppo/PPO.SRV.WS01";
			//String endPoint ="https://pss.koreanair.com/ppo/PPO.SRV.WS01"; 
			URL url = null;
			HttpURLConnection connection = null;
			PrintWriter requestWriter = null;
			BufferedReader requestReader = null;
			returnMessage = new StringBuffer();
			
			url = new URL(endPoint);
			
            connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
	        connection.setRequestProperty("Content-type", "text/xml; charset=utf-8");
            connection.setRequestProperty("SOAPAction", "process");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setUseCaches(false);
            connection.connect();
           
            requestWriter = new PrintWriter(connection.getOutputStream());
            requestWriter.println(xml.toString());
            requestWriter.flush();
            requestWriter.close();
           
		   requestReader = new BufferedReader(new InputStreamReader(connection.getInputStream(),"utf-8"));
            String Line = requestReader.readLine();
            while (Line != null) {
            	returnMessage.append(Line);
            	Line = requestReader.readLine();
            }
            requestReader.close();
            
            session.setAttribute("menuSession", parseXmlSession(returnMessage.toString()));
            
            Enumeration se = session.getAttributeNames(); 
	   		 while(se.hasMoreElements()){ 
	   		 String getse = se.nextElement()+""; 
	   		 logger.info("@@@@@@@ session : "+getse+" : "+session.getAttribute(getse)); 
	   		}
	   		 
	   		 logger.info("@@@@@@@ session : "+session.getAttribute("menuSession"));
            
	        //parseXml(returnMessage.toString());
            
	 		


		} catch(UnknownHostException ex) {
			logger.info("++++++++++++UnknownHostExceptionUnknownHostExceptionUnknownHostExceptionUnknownHostException+++++++++++++++++++++++++11111 : ");
		} catch(Exception e) {
		
			e.printStackTrace();
		}  
		
		logger.info("+++++++returnMessage : " + returnMessage.toString());
		
		return "/ws/wsClient4";
		
		
	}
	
	public void parseXml(String xml) throws Exception {
		try {
		     DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();   
		     DocumentBuilder parser = f.newDocumentBuilder();
		     
		     
		     InputStream is = new ByteArrayInputStream(xml.getBytes("utf-8"));
		     Document xmlDoc = parser.parse(new InputSource(is));
		     
		     Element root = xmlDoc.getDocumentElement();
		     insertXml(xmlDoc, root);

	    } catch (Exception e) {
	     e.printStackTrace();
	    }
	}
	
	
	    
	public void insertXml(Document xmlDoc, Node n){
    	
    	//user info
    	String ssoLoginId       = ""; 
    	String empNo            = ""; 
    	String empEngLnm        = ""; 
    	String empEngFnm        = ""; 
    	String empLocalLangLnm  = ""; 
    	String empLocalLangFnm  = ""; 
    	String orgCd            = ""; 
    	String email            = ""; 
    	String ofcPhone         = ""; 
    	String empTypNm         = ""; 
    	String icbSttsNm        = ""; 
    	String defaultOfcId     = ""; 
    	
    	//menu list 
    	String menuId      = "";
    	String menuNm      = "";
    	String highMenuId  = "";
    	String outputSeq   = "";
    	String menuGrd     = "";
    	String url         = "";
    	String readPosbYn  = "";
    	String wrtPosbYn   = "";
    	String delPosbYn   = "";
    	String prtPosbYn   = "";
    	
	    
    	ArrayList     list    = new ArrayList();
    	ArrayList     menuList    = new ArrayList();
    	Document      doc       = null;
	    
	    try{

	        doc            = xmlDoc; // 문자셋에 유의, XML 에 기술된 문자셋으로 세팅
	        NodeList menu  = doc.getElementsByTagName("menu"); // menu 는 반복되는 태그 이름
	        NodeList user  = doc.getElementsByTagName("user"); // menu 는 반복되는 태그 이름
	        
	        for(int i=0; i<user.getLength(); i++) {
	          NodeList  userNL = user.item(i).getChildNodes(); // xmlContent.user.day 태그 하위에 존재하는 태그들 목록
	          ssoLoginId       =  userNL.item(0).getFirstChild().getNodeValue();
	          empNo            =  userNL.item(1).getFirstChild().getNodeValue();
	          empEngLnm        =  userNL.item(2).getFirstChild().getNodeValue();
	          empEngFnm        =  userNL.item(3).getFirstChild().getNodeValue();
	          empLocalLangLnm  =  userNL.item(4).getFirstChild().getNodeValue();
	          empLocalLangFnm  =  userNL.item(5).getFirstChild().getNodeValue();
	          orgCd            =  userNL.item(6).getFirstChild().getNodeValue();
	          email            =  userNL.item(7).getFirstChild().getNodeValue();
	          ofcPhone         =  userNL.item(8).getFirstChild().getNodeValue();
	          empTypNm         =  userNL.item(9).getFirstChild().getNodeValue();
	          icbSttsNm        =  userNL.item(10).getFirstChild().getNodeValue();
	          defaultOfcId     =  userNL.item(11).getFirstChild().getNodeValue();
	          
	        }
	        
	        WsMenuDomain menuDomain = new WsMenuDomain();
	        
	        for(int i=0; i<menu.getLength(); i++) {
		          NodeList  menuNL = menu.item(i).getChildNodes(); // xmlContent.menu.day 태그 하위에 존재하는 태그들 목록
		          menuId     = menuNL.item(0).getFirstChild().getNodeValue();
		          menuNm     = menuNL.item(1).getFirstChild().getNodeValue();
		          highMenuId = menuNL.item(2).getFirstChild().getNodeValue();
		          menuGrd  	 = menuNL.item(3).getFirstChild().getNodeValue();
		          outputSeq  = menuNL.item(4).getFirstChild().getNodeValue();
		          url        = menuNL.item(5).getFirstChild().getNodeValue();
		          readPosbYn = menuNL.item(6).getFirstChild().getNodeValue();
		          wrtPosbYn  = menuNL.item(7).getFirstChild().getNodeValue();
		          delPosbYn  = menuNL.item(8).getFirstChild().getNodeValue();
		          prtPosbYn  = menuNL.item(9).getFirstChild().getNodeValue();

		          menuDomain.setSsoLoginId      (ssoLoginId     );
		          menuDomain.setEmpNo           (empNo          );
		          menuDomain.setEmpEngLnm       (empEngLnm      );
		          menuDomain.setEmpEngFnm       (empEngFnm      );
		          menuDomain.setEmpLocalLangLnm (empLocalLangLnm);
		          menuDomain.setOrgCd           (orgCd          );
		          menuDomain.setEmail           (email          );
		          menuDomain.setOfcPhone        (ofcPhone       );
		          menuDomain.setEmpTypNm        (empTypNm       );
		          menuDomain.setIcbSttsNm       (icbSttsNm      );
		          menuDomain.setDefaultOfcId    (defaultOfcId   );
		          menuDomain.setMenuId          (menuId         );
		          menuDomain.setMenuNm          (menuNm         );
		          menuDomain.setHighMenuId      (highMenuId     );
		          menuDomain.setOutputSeq       (outputSeq      );
		          menuDomain.setMenuGrd         (menuGrd        );
		          menuDomain.setUrl             (url            );
		          menuDomain.setReadPosbYn      (readPosbYn     );
		          menuDomain.setWrtPosbYn       (wrtPosbYn      );
		          menuDomain.setDelPosbYn       (delPosbYn      );
		          menuDomain.setPrtPosbYn       (prtPosbYn      );
		          menuDomain.setLoopCnt         ((i+1)+""      );
		          
		          
		          logger.info("=========menuDomain=====================:" + menuDomain.getPrtPosbYn());
		          
		          menuList.add(menuDomain);
		           
		          wsMenuMapper.wsMenuProc(menuDomain);
		          
		          //session.setAttribute("menuList", menuDomain);
		        }

	        logger.info("==menuList===================== : " + menuList.size());
	        

	    }catch (Exception e) {
	    	e.printStackTrace();
	    }
	    
    }
	
	
	
	public List parseXmlSession(String xml) throws Exception {
		try {
		     DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();   
		     DocumentBuilder parser = f.newDocumentBuilder();
		     
		     
		     InputStream is = new ByteArrayInputStream(xml.getBytes("utf-8"));
		     Document xmlDoc = parser.parse(new InputSource(is));
		     
		     Element root = xmlDoc.getDocumentElement();
		     
		     return insertXmlSession(xmlDoc, root);

	    } catch (Exception e) {
	    	e.printStackTrace();
	    	return null;
	    }
	}
	
	
	    
	public List insertXmlSession(Document xmlDoc, Node n){
    	
    	//user info
    	String ssoLoginId       = ""; 
    	String empNo            = ""; 
    	String empEngLnm        = ""; 
    	String empEngFnm        = ""; 
    	String empLocalLangLnm  = ""; 
    	String empLocalLangFnm  = ""; 
    	String orgCd            = ""; 
    	String email            = ""; 
    	String ofcPhone         = ""; 
    	String empTypNm         = ""; 
    	String icbSttsNm        = ""; 
    	String defaultOfcId     = ""; 
    	
    	//menu list 
    	String menuId      = "";
    	String menuNm      = "";
    	String highMenuId  = "";
    	String outputSeq   = "";
    	String menuGrd     = "";
    	String url         = "";
    	String readPosbYn  = "";
    	String wrtPosbYn   = "";
    	String delPosbYn   = "";
    	String prtPosbYn   = "";
    	
	    
    	ArrayList     list    = new ArrayList();
    	ArrayList     menuList    = new ArrayList();
    	ArrayList     menuList1    = new ArrayList();
    	ArrayList     menuList2    = new ArrayList();
    	ArrayList     menuList3    = new ArrayList();
    	
    	Document      doc       = null;
	    
	    try{

	        doc            = xmlDoc; // 문자셋에 유의, XML 에 기술된 문자셋으로 세팅
	        NodeList menu  = doc.getElementsByTagName("menu"); // menu 는 반복되는 태그 이름
	        NodeList user  = doc.getElementsByTagName("user"); // menu 는 반복되는 태그 이름
	        
	        for(int i=0; i<user.getLength(); i++) {
	          NodeList  userNL = user.item(i).getChildNodes(); // xmlContent.user.day 태그 하위에 존재하는 태그들 목록
	          ssoLoginId       =  userNL.item(0).getFirstChild().getNodeValue();
	          empNo            =  userNL.item(1).getFirstChild().getNodeValue();
	          empEngLnm        =  userNL.item(2).getFirstChild().getNodeValue();
	          empEngFnm        =  userNL.item(3).getFirstChild().getNodeValue();
	          empLocalLangLnm  =  userNL.item(4).getFirstChild().getNodeValue();
	          empLocalLangFnm  =  userNL.item(5).getFirstChild().getNodeValue();
	          orgCd            =  userNL.item(6).getFirstChild().getNodeValue();
	          email            =  userNL.item(7).getFirstChild().getNodeValue();
	          ofcPhone         =  userNL.item(8).getFirstChild().getNodeValue();
	          empTypNm         =  userNL.item(9).getFirstChild().getNodeValue();
	          icbSttsNm        =  userNL.item(10).getFirstChild().getNodeValue();
	          defaultOfcId     =  userNL.item(11).getFirstChild().getNodeValue();
	          
	        }
	        
	        WsMenuDomain menuDomain = new WsMenuDomain();
	        
	        for(int i=0; i<menu.getLength(); i++) {
	          menuDomain = new WsMenuDomain();
	          
	          NodeList  menuNL = menu.item(i).getChildNodes(); // xmlContent.menu.day 태그 하위에 존재하는 태그들 목록
	          menuId     = menuNL.item(0).getFirstChild().getNodeValue();
	          menuNm     = menuNL.item(1).getFirstChild().getNodeValue();
	          highMenuId = menuNL.item(2).getFirstChild().getNodeValue();
	          menuGrd  	 = menuNL.item(3).getFirstChild().getNodeValue();
	          outputSeq  = menuNL.item(4).getFirstChild().getNodeValue();
	          url        = menuNL.item(5).getFirstChild().getNodeValue();
	          readPosbYn = menuNL.item(6).getFirstChild().getNodeValue();
	          wrtPosbYn  = menuNL.item(7).getFirstChild().getNodeValue();
	          delPosbYn  = menuNL.item(8).getFirstChild().getNodeValue();
	          prtPosbYn  = menuNL.item(9).getFirstChild().getNodeValue();
	          
	          if (!menuGrd.equals("1")) {continue;}

	          menuDomain.setSsoLoginId      (ssoLoginId     );
	          menuDomain.setEmpNo           (empNo          );
	          menuDomain.setEmpEngLnm       (empEngLnm      );
	          menuDomain.setEmpEngFnm       (empEngFnm      );
	          menuDomain.setEmpLocalLangLnm (empLocalLangLnm);
	          menuDomain.setOrgCd           (orgCd          );
	          menuDomain.setEmail           (email          );
	          menuDomain.setOfcPhone        (ofcPhone       );
	          menuDomain.setEmpTypNm        (empTypNm       );
	          menuDomain.setIcbSttsNm       (icbSttsNm      );
	          menuDomain.setDefaultOfcId    (defaultOfcId   );
	          menuDomain.setMenuId          (menuId         );
	          menuDomain.setMenuNm          (menuNm         );
	          menuDomain.setHighMenuId      (highMenuId     );
	          menuDomain.setOutputSeq       (outputSeq      );
	          menuDomain.setMenuGrd         (menuGrd        );
	          menuDomain.setUrl             (url            );
	          menuDomain.setReadPosbYn      (readPosbYn     );
	          menuDomain.setWrtPosbYn       (wrtPosbYn      );
	          menuDomain.setDelPosbYn       (delPosbYn      );
	          menuDomain.setPrtPosbYn       (prtPosbYn      );
	          menuDomain.setLoopCnt         ((i+1)+""      );
	          
	          menuList1.add(menuDomain);
	          
	        }
	        
	        
	        //Loop 돌면서 중메뉴만 담는다 .
	        for(int i=0; i<menu.getLength(); i++) {
		          menuDomain = new WsMenuDomain();
		          
		          NodeList  menuNL = menu.item(i).getChildNodes(); // xmlContent.menu.day 태그 하위에 존재하는 태그들 목록
		          menuId     = menuNL.item(0).getFirstChild().getNodeValue();
		          menuNm     = menuNL.item(1).getFirstChild().getNodeValue();
		          highMenuId = menuNL.item(2).getFirstChild().getNodeValue();
		          menuGrd  	 = menuNL.item(3).getFirstChild().getNodeValue();
		          outputSeq  = menuNL.item(4).getFirstChild().getNodeValue();
		          url        = menuNL.item(5).getFirstChild().getNodeValue();
		          readPosbYn = menuNL.item(6).getFirstChild().getNodeValue();
		          wrtPosbYn  = menuNL.item(7).getFirstChild().getNodeValue();
		          delPosbYn  = menuNL.item(8).getFirstChild().getNodeValue();
		          prtPosbYn  = menuNL.item(9).getFirstChild().getNodeValue();
		          
		          if (!menuGrd.equals("2")) {continue;}

		          menuDomain.setSsoLoginId      (ssoLoginId     );
		          menuDomain.setEmpNo           (empNo          );
		          menuDomain.setEmpEngLnm       (empEngLnm      );
		          menuDomain.setEmpEngFnm       (empEngFnm      );
		          menuDomain.setEmpLocalLangLnm (empLocalLangLnm);
		          menuDomain.setOrgCd           (orgCd          );
		          menuDomain.setEmail           (email          );
		          menuDomain.setOfcPhone        (ofcPhone       );
		          menuDomain.setEmpTypNm        (empTypNm       );
		          menuDomain.setIcbSttsNm       (icbSttsNm      );
		          menuDomain.setDefaultOfcId    (defaultOfcId   );
		          menuDomain.setMenuId          (menuId         );
		          menuDomain.setMenuNm          (menuNm         );
		          menuDomain.setHighMenuId      (highMenuId     );
		          menuDomain.setOutputSeq       (outputSeq      );
		          menuDomain.setMenuGrd         (menuGrd        );
		          menuDomain.setUrl             (url            );
		          menuDomain.setReadPosbYn      (readPosbYn     );
		          menuDomain.setWrtPosbYn       (wrtPosbYn      );
		          menuDomain.setDelPosbYn       (delPosbYn      );
		          menuDomain.setPrtPosbYn       (prtPosbYn      );
		          menuDomain.setLoopCnt         ((i+1)+""      );
		          
		          
		          menuList2.add(menuDomain);
		          
		        }
	        
	        
	        //Loop 돌면서 소메뉴만 담는다. 
	        for(int i=0; i<menu.getLength(); i++) {
		          menuDomain = new WsMenuDomain();
		          
		          NodeList  menuNL = menu.item(i).getChildNodes(); // xmlContent.menu.day 태그 하위에 존재하는 태그들 목록
		          menuId     = menuNL.item(0).getFirstChild().getNodeValue();
		          menuNm     = menuNL.item(1).getFirstChild().getNodeValue();
		          highMenuId = menuNL.item(2).getFirstChild().getNodeValue();
		          menuGrd  	 = menuNL.item(3).getFirstChild().getNodeValue();
		          outputSeq  = menuNL.item(4).getFirstChild().getNodeValue();
		          url        = menuNL.item(5).getFirstChild().getNodeValue();
		          readPosbYn = menuNL.item(6).getFirstChild().getNodeValue();
		          wrtPosbYn  = menuNL.item(7).getFirstChild().getNodeValue();
		          delPosbYn  = menuNL.item(8).getFirstChild().getNodeValue();
		          prtPosbYn  = menuNL.item(9).getFirstChild().getNodeValue();
		          
		          if (!menuGrd.equals("3")) {continue;}

		          menuDomain.setSsoLoginId      (ssoLoginId     );
		          menuDomain.setEmpNo           (empNo          );
		          menuDomain.setEmpEngLnm       (empEngLnm      );
		          menuDomain.setEmpEngFnm       (empEngFnm      );
		          menuDomain.setEmpLocalLangLnm (empLocalLangLnm);
		          menuDomain.setOrgCd           (orgCd          );
		          menuDomain.setEmail           (email          );
		          menuDomain.setOfcPhone        (ofcPhone       );
		          menuDomain.setEmpTypNm        (empTypNm       );
		          menuDomain.setIcbSttsNm       (icbSttsNm      );
		          menuDomain.setDefaultOfcId    (defaultOfcId   );
		          menuDomain.setMenuId          (menuId         );
		          menuDomain.setMenuNm          (menuNm         );
		          menuDomain.setHighMenuId      (highMenuId     );
		          menuDomain.setOutputSeq       (outputSeq      );
		          menuDomain.setMenuGrd         (menuGrd        );
		          menuDomain.setUrl             (url            );
		          menuDomain.setReadPosbYn      (readPosbYn     );
		          menuDomain.setWrtPosbYn       (wrtPosbYn      );
		          menuDomain.setDelPosbYn       (delPosbYn      );
		          menuDomain.setPrtPosbYn       (prtPosbYn      );
		          menuDomain.setLoopCnt         ((i+1)+""      );
		          
		          menuList3.add(menuDomain);
		        }
	        
	        //위에서 담은 menu1,2,3 값을 하나의 배열로 넘긴후 세션을 생성한다. 
	        menuList.add(menuList1);
	        menuList.add(menuList2);
	        menuList.add(menuList3);
	        
	        return menuList;

	        
	    }catch (Exception e) {
	    	e.printStackTrace();
	    	return null;
	    }
	    
    }
	


}
