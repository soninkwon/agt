package com.koreanair.cargo.service;


import com.koreanair.cargo.domain.VocReqDomain;

public interface VocService {
	
	public String getVocCheckInput(VocReqDomain vocReqDomain);
	
}
