package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;

@DataTransferObject(type="bean", javascript="exportEpnDomain")
public class ExportHawbListDomain {
	
	private String mawb_no            = "";
	private String hawb_no            = "";
	private String epn_no             = "";
	private String pc_q               = "";
	private String wt_m               = "";
	private String wtu_c              = "";
	private String sametimepack_c     = "";
	private String sametimepack_cnt_q = "";
	private String ptl_c              = "";
	private String ptl_cnt_n1         = "";
	private String express_yn         = "";
	private String err_msg            = "";
	private String result_sts         = "";
	private String wh_loc_c         = "";
	private String fwdr_c         = "";
	private String cmod_n         = "";
	private String hsn_no         = "";
	
	private String shpr_n       = "";
	private String shpr_addr_n  = "";
	private String shpr_tel_n   = "";
	private String shpr_busi_id   = "";
	private String cnee_n       = "";
	private String cnee_addr_n  = "";
	private String cnee_tel_n   = "";
	private String cnee_busi_id   = "";
	private String ntfy_n       = "";
	private String ntfy_addr_n  = "";
	private String ntfy_tel_n   = "";
	private String ntfy_busi_id   = "";
	
	private String flt_no   = "";
	private String flt_d   = "";
	private String carr_c   = "";
	
	private String hawb_del_yn   = "";
	private String hawb_mod_yn   = "";
	
	private String org_c   = "";
	private String dst_c   = "";
	private String fwdr_n   = "";
	
	private String epn_pc   = "";
	private String epn_wt   = "";
	public String getMawb_no() {
		return mawb_no;
	}
	public void setMawb_no(String mawb_no) {
		this.mawb_no = mawb_no;
	}
	public String getHawb_no() {
		return hawb_no;
	}
	public void setHawb_no(String hawb_no) {
		this.hawb_no = hawb_no;
	}
	public String getEpn_no() {
		return epn_no;
	}
	public void setEpn_no(String epn_no) {
		this.epn_no = epn_no;
	}
	public String getPc_q() {
		return pc_q;
	}
	public void setPc_q(String pc_q) {
		this.pc_q = pc_q;
	}
	public String getWt_m() {
		return wt_m;
	}
	public void setWt_m(String wt_m) {
		this.wt_m = wt_m;
	}
	public String getWtu_c() {
		return wtu_c;
	}
	public void setWtu_c(String wtu_c) {
		this.wtu_c = wtu_c;
	}
	public String getSametimepack_c() {
		return sametimepack_c;
	}
	public void setSametimepack_c(String sametimepack_c) {
		this.sametimepack_c = sametimepack_c;
	}
	public String getSametimepack_cnt_q() {
		return sametimepack_cnt_q;
	}
	public void setSametimepack_cnt_q(String sametimepack_cnt_q) {
		this.sametimepack_cnt_q = sametimepack_cnt_q;
	}
	public String getPtl_c() {
		return ptl_c;
	}
	public void setPtl_c(String ptl_c) {
		this.ptl_c = ptl_c;
	}
	public String getPtl_cnt_n1() {
		return ptl_cnt_n1;
	}
	public void setPtl_cnt_n1(String ptl_cnt_n1) {
		this.ptl_cnt_n1 = ptl_cnt_n1;
	}
	public String getExpress_yn() {
		return express_yn;
	}
	public void setExpress_yn(String express_yn) {
		this.express_yn = express_yn;
	}
	public String getErr_msg() {
		return err_msg;
	}
	public void setErr_msg(String err_msg) {
		this.err_msg = err_msg;
	}
	public String getResult_sts() {
		return result_sts;
	}
	public void setResult_sts(String result_sts) {
		this.result_sts = result_sts;
	}
	public String getWh_loc_c() {
		return wh_loc_c;
	}
	public void setWh_loc_c(String wh_loc_c) {
		this.wh_loc_c = wh_loc_c;
	}
	public String getFwdr_c() {
		return fwdr_c;
	}
	public void setFwdr_c(String fwdr_c) {
		this.fwdr_c = fwdr_c;
	}
	public String getCmod_n() {
		return cmod_n;
	}
	public void setCmod_n(String cmod_n) {
		this.cmod_n = cmod_n;
	}
	public String getHsn_no() {
		return hsn_no;
	}
	public void setHsn_no(String hsn_no) {
		this.hsn_no = hsn_no;
	}
	public String getShpr_n() {
		return shpr_n;
	}
	public void setShpr_n(String shpr_n) {
		this.shpr_n = shpr_n;
	}
	public String getShpr_addr_n() {
		return shpr_addr_n;
	}
	public void setShpr_addr_n(String shpr_addr_n) {
		this.shpr_addr_n = shpr_addr_n;
	}
	public String getShpr_tel_n() {
		return shpr_tel_n;
	}
	public void setShpr_tel_n(String shpr_tel_n) {
		this.shpr_tel_n = shpr_tel_n;
	}
	public String getShpr_busi_id() {
		return shpr_busi_id;
	}
	public void setShpr_busi_id(String shpr_busi_id) {
		this.shpr_busi_id = shpr_busi_id;
	}
	public String getCnee_n() {
		return cnee_n;
	}
	public void setCnee_n(String cnee_n) {
		this.cnee_n = cnee_n;
	}
	public String getCnee_addr_n() {
		return cnee_addr_n;
	}
	public void setCnee_addr_n(String cnee_addr_n) {
		this.cnee_addr_n = cnee_addr_n;
	}
	public String getCnee_tel_n() {
		return cnee_tel_n;
	}
	public void setCnee_tel_n(String cnee_tel_n) {
		this.cnee_tel_n = cnee_tel_n;
	}
	public String getCnee_busi_id() {
		return cnee_busi_id;
	}
	public void setCnee_busi_id(String cnee_busi_id) {
		this.cnee_busi_id = cnee_busi_id;
	}
	public String getNtfy_n() {
		return ntfy_n;
	}
	public void setNtfy_n(String ntfy_n) {
		this.ntfy_n = ntfy_n;
	}
	public String getNtfy_addr_n() {
		return ntfy_addr_n;
	}
	public void setNtfy_addr_n(String ntfy_addr_n) {
		this.ntfy_addr_n = ntfy_addr_n;
	}
	public String getNtfy_tel_n() {
		return ntfy_tel_n;
	}
	public void setNtfy_tel_n(String ntfy_tel_n) {
		this.ntfy_tel_n = ntfy_tel_n;
	}
	public String getNtfy_busi_id() {
		return ntfy_busi_id;
	}
	public void setNtfy_busi_id(String ntfy_busi_id) {
		this.ntfy_busi_id = ntfy_busi_id;
	}
	public String getFlt_no() {
		return flt_no;
	}
	public void setFlt_no(String flt_no) {
		this.flt_no = flt_no;
	}
	public String getFlt_d() {
		return flt_d;
	}
	public void setFlt_d(String flt_d) {
		this.flt_d = flt_d;
	}
	public String getCarr_c() {
		return carr_c;
	}
	public void setCarr_c(String carr_c) {
		this.carr_c = carr_c;
	}
	public String getHawb_del_yn() {
		return hawb_del_yn;
	}
	public void setHawb_del_yn(String hawb_del_yn) {
		this.hawb_del_yn = hawb_del_yn;
	}
	public String getHawb_mod_yn() {
		return hawb_mod_yn;
	}
	public void setHawb_mod_yn(String hawb_mod_yn) {
		this.hawb_mod_yn = hawb_mod_yn;
	}
	public String getOrg_c() {
		return org_c;
	}
	public void setOrg_c(String org_c) {
		this.org_c = org_c;
	}
	public String getDst_c() {
		return dst_c;
	}
	public void setDst_c(String dst_c) {
		this.dst_c = dst_c;
	}
	public String getFwdr_n() {
		return fwdr_n;
	}
	public void setFwdr_n(String fwdr_n) {
		this.fwdr_n = fwdr_n;
	}
	public String getEpn_pc() {
		return epn_pc;
	}
	public void setEpn_pc(String epn_pc) {
		this.epn_pc = epn_pc;
	}
	public String getEpn_wt() {
		return epn_wt;
	}
	public void setEpn_wt(String epn_wt) {
		this.epn_wt = epn_wt;
	}
	
	
	
}