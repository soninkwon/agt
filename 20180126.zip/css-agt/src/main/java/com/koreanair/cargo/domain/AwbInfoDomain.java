package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;

@DataTransferObject(type="bean", javascript="AwbInfoDomain")
public class AwbInfoDomain {
	private String awbNbr;
	private String awbIssue;
	private String awbStatus;
	private String destination;
	private String agentCode;
	private String cneeCode;
	private String cneeName;
	private String cneeTel;
	private String cneeFax;
	private String shprCode;
	private String shprName;
	private String shprFax;
	private String hagtCode;
	private String hagtName;
	private String hagtTel;
	private String hagtFax;
	private String tPieces;
	private String tWeight;
	private String dgCode;
	private String wt;
	private String leng;
	private String ht;
	private String vWt;
	private String issueId;
	private String remarks;
	
	
	public String getAwbNbr() {
		return awbNbr;
	}
	public void setAwbNbr(String awbNbr) {
		this.awbNbr = awbNbr;
	}
	public String getAwbIssue() {
		return awbIssue;
	}
	public void setAwbIssue(String awbIssue) {
		this.awbIssue = awbIssue;
	}
	public String getAwbStatus() {
		return awbStatus;
	}
	public void setAwbStatus(String awbStatus) {
		this.awbStatus = awbStatus;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getCneeCode() {
		return cneeCode;
	}
	public void setCneeCode(String cneeCode) {
		this.cneeCode = cneeCode;
	}
	public String getCneeName() {
		return cneeName;
	}
	public void setCneeName(String cneeName) {
		this.cneeName = cneeName;
	}
	public String getCneeTel() {
		return cneeTel;
	}
	public void setCneeTel(String cneeTel) {
		this.cneeTel = cneeTel;
	}
	public String getCneeFax() {
		return cneeFax;
	}
	public void setCneeFax(String cneeFax) {
		this.cneeFax = cneeFax;
	}
	public String getShprCode() {
		return shprCode;
	}
	public void setShprCode(String shprCode) {
		this.shprCode = shprCode;
	}
	public String getShprName() {
		return shprName;
	}
	public void setShprName(String shprName) {
		this.shprName = shprName;
	}
	public String getShprFax() {
		return shprFax;
	}
	public void setShprFax(String shprFax) {
		this.shprFax = shprFax;
	}
	public String getHagtCode() {
		return hagtCode;
	}
	public void setHagtCode(String hagtCode) {
		this.hagtCode = hagtCode;
	}
	public String getHagtName() {
		return hagtName;
	}
	public void setHagtName(String hagtName) {
		this.hagtName = hagtName;
	}
	public String getHagtTel() {
		return hagtTel;
	}
	public void setHagtTel(String hagtTel) {
		this.hagtTel = hagtTel;
	}
	public String getHagtFax() {
		return hagtFax;
	}
	public void setHagtFax(String hagtFax) {
		this.hagtFax = hagtFax;
	}
	public String gettPieces() {
		return tPieces;
	}
	public void settPieces(String tPieces) {
		this.tPieces = tPieces;
	}
	public String gettWeight() {
		return tWeight;
	}
	public void settWeight(String tWeight) {
		this.tWeight = tWeight;
	}
	public String getDgCode() {
		return dgCode;
	}
	public void setDgCode(String dgCode) {
		this.dgCode = dgCode;
	}
	public String getWt() {
		return wt;
	}
	public void setWt(String wt) {
		this.wt = wt;
	}
	public String getLeng() {
		return leng;
	}
	public void setLeng(String leng) {
		this.leng = leng;
	}
	public String getHt() {
		return ht;
	}
	public void setHt(String ht) {
		this.ht = ht;
	}
	public String getvWt() {
		return vWt;
	}
	public void setvWt(String vWt) {
		this.vWt = vWt;
	}
	public String getIssueId() {
		return issueId;
	}
	public void setIssueId(String issueId) {
		this.issueId = issueId;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
