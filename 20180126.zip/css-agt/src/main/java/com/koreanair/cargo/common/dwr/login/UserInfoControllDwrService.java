package com.koreanair.cargo.common.dwr.login;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import com.koreanair.cargo.domain.UserInfoReqDomain;

public interface UserInfoControllDwrService {
	public Map<String,Object> getUserList(UserInfoReqDomain userInfoReqDomain, HttpSession session);
	
}
