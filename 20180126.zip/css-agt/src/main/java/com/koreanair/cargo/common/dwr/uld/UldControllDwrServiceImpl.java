package com.koreanair.cargo.common.dwr.uld;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.directwebremoting.annotations.RemoteMethod;
import org.directwebremoting.annotations.RemoteProxy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.koreanair.cargo.domain.uld.UldCityDomain;
import com.koreanair.cargo.domain.uld.UldReqDomain;
import com.koreanair.cargo.persistence2.UldMapper;;

@Repository
@RemoteProxy(name="uldDwr")
public class UldControllDwrServiceImpl implements UldControllDwrService {
	
	@Autowired
	@Qualifier("sqlSessionTemplate2")

	private SqlSession sqlSession;

	@Autowired
	UldMapper uldMapper;
	private static final Logger logger = LoggerFactory.getLogger(UldControllDwrServiceImpl.class);
	
	
	@RemoteMethod
	public Map<String, Object> getUldCityList2(UldReqDomain uldReqDomain) {
		Map<String, Object> rtnMap = new HashMap<String, Object>();
		logger.info("0000000000000");
		List<UldCityDomain> uldCityList = null;
		try {
			logger.info("0000000000000 + " + uldReqDomain);
			logger.info("0000000000000 + " + uldReqDomain.getCdRgn());
			
			//uldCityList = uldMapper.getUldCityList2(uldReqDomain);
			rtnMap.put("uldCityList", uldMapper.getUldCityList2(uldReqDomain) );
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		logger.info("11111111111 : " + uldReqDomain.getCdRgn());
		
		
		return rtnMap;
	}
	

}
