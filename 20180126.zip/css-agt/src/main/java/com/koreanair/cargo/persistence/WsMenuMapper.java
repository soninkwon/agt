package com.koreanair.cargo.persistence;

import java.util.List;

import com.koreanair.cargo.domain.WsMenuReqDomain;
import com.koreanair.cargo.domain.WsMenuDomain;

public interface WsMenuMapper {
	
	List<WsMenuDomain> wsMenuList(WsMenuReqDomain reqDomain);
	
	int wsMenuInsert(WsMenuDomain menuDomain);
	
	int wsMenuDelete(WsMenuDomain menuDomain);
	
	int wsMenuProc(WsMenuDomain menuDomain);
	
	List<WsMenuDomain> scAgent(WsMenuReqDomain reqDomain);
}
