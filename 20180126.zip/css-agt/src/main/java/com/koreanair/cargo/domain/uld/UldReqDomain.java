package com.koreanair.cargo.domain.uld;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="uldReqDomain")

public class UldReqDomain {
	
	private String cdRgn;
	private String cdMenu1;
	private String cdMenu2;

	@RemoteProperty
	public String getCdRgn() {
		return cdRgn;
	}

	public void setCdRgn(String cdRgn) {
		this.cdRgn = cdRgn;
	}

	public String getCdMenu1() {
		return cdMenu1;
	}

	public void setCdMenu1(String cdMenu1) {
		this.cdMenu1 = cdMenu1;
	}

	public String getCdMenu2() {
		return cdMenu2;
	}

	public void setCdMenu2(String cdMenu2) {
		this.cdMenu2 = cdMenu2;
	}
	
	
	
	
	
}
