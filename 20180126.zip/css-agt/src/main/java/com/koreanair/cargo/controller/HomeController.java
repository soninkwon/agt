package com.koreanair.cargo.controller;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.support.SessionStatus;

import com.koreanair.cargo.domain.ExportDomain;
import com.koreanair.cargo.domain.ExportReqDomain;
import com.koreanair.cargo.domain.WsMenuDomain;
import com.koreanair.cargo.domain.WsMenuReqDomain;
import com.koreanair.cargo.persistence.WsMenuMapper;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	WsMenuMapper wsMenuMapper;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	
	@RequestMapping(value = "fileUpload.do", method = RequestMethod.GET)
	public String fileUpload(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "TestFileUpload";
	}
	
	
	@RequestMapping(value = "agt_header.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String agtHeader(Locale locale, Model model) {
		return "common/agt_header";
	}
	
	@RequestMapping(value = "agt_top_menu.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String agtTopMenu(Locale locale, Model model) {
		return "common/agt_top_menu";
	}
	
	@RequestMapping(value = "agt_left_menu.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String agtLeftMenu(Locale locale, Model model, ModelMap modelMap, WsMenuReqDomain wsMenuReqDomain, HttpSession session) {
		
		List menu1;
		List menu2;
		List menu3;
		
		//세션값이 없을때는 DB 에서 불러와 메뉴구성, 세션값 생성하여 다른 페이지 호출시 세션값 이용하여 메뉴 구성
		if (session.getAttribute("menu1") == null) {
			wsMenuReqDomain.setSsoLoginId("AGTMENU"); //고객용 홈페이지 메뉴 
			
			wsMenuReqDomain.setMenuGrd("1");
			menu1 = wsMenuMapper.wsMenuList(wsMenuReqDomain);
			modelMap.put("menu1", menu1);
			session.setAttribute("menu1", menu1);
			
			wsMenuReqDomain.setMenuGrd("2");
			menu2 = wsMenuMapper.wsMenuList(wsMenuReqDomain);
			modelMap.put("menu3", menu2);
			session.setAttribute("menu2", menu2);
			
			wsMenuReqDomain.setMenuGrd("3");
			menu3 = wsMenuMapper.wsMenuList(wsMenuReqDomain);
			modelMap.put("menu3", menu3);
			session.setAttribute("menu3", menu3);
		}else {
			modelMap.put("menu1", session.getAttribute("menu1"));
			modelMap.put("menu2", session.getAttribute("menu2"));
			modelMap.put("menu3", session.getAttribute("menu3"));
		}
		
		
		
		return "common/agt_left_menu";
	}
	
	@RequestMapping(value = "agt_left_ws_menu.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String agtLeftWsMenu(Locale locale, Model model, ModelMap modelMap, WsMenuReqDomain wsMenuReqDomain, HttpSession session) {
		
		
		 logger.info("@@@@@@@ session : "+session.getAttribute("menuSession"));
		 
		 List sessionList;
		 
		 //메뉴 웹서비스 호출 하는곳에서 세션을 맺어 놓은후 이용한다. 
		 //메뉴 웹서비스 호출시 대중소 메뉴 3개를 배열로 묶어 넘겨준다. 
		 sessionList = (List) session.getAttribute("menuSession");
		 
		 modelMap.put("menu1", sessionList.get(0));
		 modelMap.put("menu2", sessionList.get(1));
		 modelMap.put("menu3", sessionList.get(2));
		 
		return "common/agt_left_menu";
		 //return "common/agt_left_menu_session";
	}
	
	
}
