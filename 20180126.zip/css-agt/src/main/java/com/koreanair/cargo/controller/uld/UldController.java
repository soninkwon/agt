package com.koreanair.cargo.controller.uld;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.koreanair.cargo.persistence2.UldMapper;
import com.koreanair.cargo.service.CommonService;
import com.koreanair.cargo.service.uld.UldService;
import com.koreanair.cargo.domain.WsMenuReqDomain;
import com.koreanair.cargo.domain.uld.UldReqDomain;
import com.koreanair.cargo.persistence.WsMenuMapper;

/**
 * Handles requests for the application uld page.
 * @author v.dkkang
 * @date 2017.11.03
 */

@Controller
@RequestMapping(value = "uld")
public class UldController {
	@Autowired
	CommonService commonService;
	UldService uldService;
	@Autowired
	UldMapper uldMapper;
	
	@Autowired
	WsMenuMapper wsMenuMapper;
	
	
	private static final Logger logger = LoggerFactory.getLogger(UldController.class);
	
	
	@RequestMapping(value = "/uldInsertForm.do", method = {RequestMethod.GET, RequestMethod.POST})
	public String uldInsertFormControll(HttpServletRequest req, HttpSession session, ModelMap modelMap, UldReqDomain uldReqDomain, WsMenuReqDomain wsMenuReqDomain) {
		
		
		UldService service = null;
		try {
			
			uldReqDomain.setCdRgn("KOR");
			modelMap.put("uldReqDomain", uldReqDomain);
			modelMap.put("uldCityList", uldMapper.getUldCityList2(uldReqDomain));
			modelMap.put("menu1", wsMenuMapper.scAgent(wsMenuReqDomain));
			
			
			logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++11111");
			logger.info("000000000000000000 : " + req.getParameter("cdRgn"));
			logger.info("111111111111111111 : " + uldReqDomain.getCdRgn());
			
		
		}catch (Exception e) {
			logger.info("++++++++++++>>>>>>>>>>>>>>>>>>>>>>>>>");
			e.printStackTrace();
			logger.info("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<");
		}
		
		//modelMap.put("uldCityList", uldService.uldCityList(uldReqDomain));
		
		return "/uld/uldInsertForm";
	}
	
	
	

}
