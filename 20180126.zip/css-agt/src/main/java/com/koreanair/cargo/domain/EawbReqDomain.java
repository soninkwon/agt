package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="eawbReqDomain")

public class EawbReqDomain {
	private String cdTrml;
	private String idScale;
	private String ipScale;
	private String locPc;
	private String skidPc;
	private String flightNbr;
	private String flightDate;
	private String portArrival;
	private String uldNbr;
	private String cdCont;
	private boolean ynOvhg;
	private double grossWt;
	
	public double getGrossWt() {
		return grossWt;
	}
	public void setGrossWt(double grossWt) {
		this.grossWt = grossWt;
	}

	public String getUldNbr() {
		return uldNbr;
	}

	public void setUldNbr(String uldNbr) {
		this.uldNbr = uldNbr;
	}

	public String getCdCont() {
		return cdCont;
	}

	public void setCdCont(String cdCont) {
		this.cdCont = cdCont;
	}

	public boolean getYnOvhg() {
		return ynOvhg;
	}

	public void setYnOvhg(boolean ynOvhg) {
		this.ynOvhg = ynOvhg;
	}

	public String getPortArrival() {
		return portArrival;
	}

	public void setPortArrival(String portArrival) {
		this.portArrival = portArrival;
	}

	@RemoteProperty
	public String getFlightNbr() {
		return flightNbr;
	}

	public void setFlightNbr(String flightNbr) {
		this.flightNbr = flightNbr;
	}
	@RemoteProperty
	public String getFlightDate() {
		return flightDate;
	}

	public void setFlightDate(String flightDate) {
		this.flightDate = flightDate;
	}

	@RemoteProperty
	public String getIdScale() {
		return idScale;
	}

	public void setIdScale(String idScale) {
		this.idScale = idScale;
	}
	@RemoteProperty
	public String getIpScale() {
		return ipScale;
	}

	public void setIpScale(String ipScale) {
		this.ipScale = ipScale;
	}
	@RemoteProperty
	public String getLocPc() {
		return locPc;
	}

	public void setLocPc(String locPc) {
		this.locPc = locPc;
	}
	@RemoteProperty
	public String getSkidPc() {
		return skidPc;
	}

	public void setSkidPc(String skidPc) {
		this.skidPc = skidPc;
	}
	@RemoteProperty
	public String getCdTrml() {
		return cdTrml;
	}

	public void setCdTrml(String cdTrml) {
		this.cdTrml = cdTrml;
	}
	
}
