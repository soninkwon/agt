package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;

@DataTransferObject(type="bean", javascript="exportEpnDomain")
public class ExportEpnDomain {
	
	
	private String flt_d                = "";
	private String carr_c               = "";
	private String flt_no                = "";
	private String mawb_no               = "";
	private String hawb_no               = "";
	private String epn_no                = "";
	private String cstm_cod_c           = "";
	private String pc_q                 = "";
	private String wt_m                 = "";
	private String sametimepack_c       = "";
	private String sametimepack_cnt_q  = "";
	private String ptl_c                = "";
	private String ptl_cnt_n1           = "";
	private String inp_flag             = "";
	private String user_id              = "";
	private String cur_sts_n              = "";
	
	public String getFlt_d() {
		return flt_d;
	}
	public void setFlt_d(String flt_d) {
		this.flt_d = flt_d;
	}
	public String getCarr_c() {
		return carr_c;
	}
	public void setCarr_c(String carr_c) {
		this.carr_c = carr_c;
	}
	public String getFlt_no() {
		return flt_no;
	}
	public void setFlt_no(String flt_no) {
		this.flt_no = flt_no;
	}
	public String getMawb_no() {
		return mawb_no;
	}
	public void setMawb_no(String mawb_no) {
		this.mawb_no = mawb_no;
	}
	public String getHawb_no() {
		return hawb_no;
	}
	public void setHawb_no(String hawb_no) {
		this.hawb_no = hawb_no;
	}
	public String getEpn_no() {
		return epn_no;
	}
	public void setEpn_no(String epn_no) {
		this.epn_no = epn_no;
	}
	public String getCstm_cod_c() {
		return cstm_cod_c;
	}
	public void setCstm_cod_c(String cstm_cod_c) {
		this.cstm_cod_c = cstm_cod_c;
	}
	public String getPc_q() {
		return pc_q;
	}
	public void setPc_q(String pc_q) {
		this.pc_q = pc_q;
	}
	public String getWt_m() {
		return wt_m;
	}
	public void setWt_m(String wt_m) {
		this.wt_m = wt_m;
	}
	public String getSametimepack_c() {
		return sametimepack_c;
	}
	public void setSametimepack_c(String sametimepack_c) {
		this.sametimepack_c = sametimepack_c;
	}
	public String getSametimepack_cnt_q() {
		return sametimepack_cnt_q;
	}
	public void setSametimepack_cnt_q(String sametimepack_cnt_q) {
		this.sametimepack_cnt_q = sametimepack_cnt_q;
	}
	public String getPtl_c() {
		return ptl_c;
	}
	public void setPtl_c(String ptl_c) {
		this.ptl_c = ptl_c;
	}
	public String getPtl_cnt_n1() {
		return ptl_cnt_n1;
	}
	public void setPtl_cnt_n1(String ptl_cnt_n1) {
		this.ptl_cnt_n1 = ptl_cnt_n1;
	}
	public String getInp_flag() {
		return inp_flag;
	}
	public void setInp_flag(String inp_flag) {
		this.inp_flag = inp_flag;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getCur_sts_n() {
		return cur_sts_n;
	}
	public void setCur_sts_n(String cur_sts_n) {
		this.cur_sts_n = cur_sts_n;
	}
	
	
	
	
	
	
}