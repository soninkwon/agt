package com.koreanair.cargo.domain;

import java.io.IOException;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;
import org.springframework.web.multipart.MultipartFile;

@DataTransferObject(type="bean", javascript="vocReqDomain")

public class VocReqDomain {
	
	private String mailGbn       = "";
	private String mailSeq       = "";
	private String mailSeq2      = "";
	private String mailFromName1 = "";
	private String mailFromName  = "";
	private String mailFromName2 = "";
	private String mailLocation  = "";
	private String mailFrom      = "";
	private String version       = "";
	private String mailTel       = "";
	private String vocTel       = "";
	private String vocEmail       = "";
	private String awb_no        = "";
	private String mailSubject   = "";
	private String reply_is      = "";
	private String mailContent   = "";

	private String file_orgn1;
	private String file_orgn2;
	private String file_orgn3;
	
	private String file_ext1;
	private String file_ext2;
	private String file_ext3;
	
	private String file_size1;
	private String file_size2;
	private String file_size3;
	
	private MultipartFile file_name1;
	private MultipartFile file_name2;
	private MultipartFile file_name3;
	
	private String lang;
	
	private String result_txt;
	private String ip_addr;
	
	public String getMailGbn() {
		return mailGbn;
	}
	public void setMailGbn(String mailGbn) {
		this.mailGbn = mailGbn;
	}
	public String getMailSeq() {
		return mailSeq;
	}
	public void setMailSeq(String mailSeq) {
		this.mailSeq = mailSeq;
	}
	public String getMailSeq2() {
		return mailSeq2;
	}
	public void setMailSeq2(String mailSeq2) {
		this.mailSeq2 = mailSeq2;
	}
	public String getMailFromName1() {
		return mailFromName1;
	}
	public void setMailFromName1(String mailFromName1) {
		this.mailFromName1 = mailFromName1;
	}
	public String getMailFromName() {
		return mailFromName;
	}
	public void setMailFromName(String mailFromName) {
		this.mailFromName = mailFromName;
	}
	public String getMailFromName2() {
		return mailFromName2;
	}
	public void setMailFromName2(String mailFromName2) {
		this.mailFromName2 = mailFromName2;
	}
	public String getMailLocation() {
		return mailLocation;
	}
	public void setMailLocation(String mailLocation) {
		this.mailLocation = mailLocation;
	}
	public String getMailFrom() {
		return mailFrom;
	}
	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getMailTel() {
		return mailTel;
	}
	public void setMailTel(String mailTel) {
		this.mailTel = mailTel;
	}
	public String getAwb_no() {
		return awb_no;
	}
	public void setAwb_no(String awb_no) {
		this.awb_no = awb_no;
	}
	public String getMailSubject() {
		return mailSubject;
	}
	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}
	public String getReply_is() {
		return reply_is;
	}
	public void setReply_is(String reply_is) {
		this.reply_is = reply_is;
	}
	public String getMailContent() {
		return mailContent;
	}
	public void setMailContent(String mailContent) {
		this.mailContent = mailContent;
	}
	public MultipartFile getFile_name1() {
		return file_name1;
	}
	public void setFile_name1(MultipartFile file_name1) {
		this.file_name1 = file_name1;
	}
	public MultipartFile getFile_name2() {
		return file_name2;
	}
	public void setFile_name2(MultipartFile file_name2) {
		this.file_name2 = file_name2;
	}
	public MultipartFile getFile_name3() {
		return file_name3;
	}
	public void setFile_name3(MultipartFile file_name3) {
		this.file_name3 = file_name3;
	}
	

    public byte[] getUploadFileBytes1() throws IOException {
        return file_name1.getBytes();
    }
    
    public byte[] getUploadFileBytes2() throws IOException {
        return file_name2.getBytes();
    }
    
    public byte[] getUploadFileBytes3() throws IOException {
        return file_name3.getBytes();
    }
    
    public byte[] getNote_x() throws IOException {
        return mailContent.getBytes();
    }
    
	public String getFile_orgn1() {
		return file_orgn1;
	}
	public void setFile_orgn1(String file_orgn1) {
		this.file_orgn1 = file_orgn1;
	}
	public String getFile_orgn2() {
		return file_orgn2;
	}
	public void setFile_orgn2(String file_orgn2) {
		this.file_orgn2 = file_orgn2;
	}
	public String getFile_orgn3() {
		return file_orgn3;
	}
	public void setFile_orgn3(String file_orgn3) {
		this.file_orgn3 = file_orgn3;
	}
	public String getFile_ext1() {
		return file_ext1;
	}
	public void setFile_ext1(String file_ext1) {
		this.file_ext1 = file_ext1;
	}
	public String getFile_ext2() {
		return file_ext2;
	}
	public void setFile_ext2(String file_ext2) {
		this.file_ext2 = file_ext2;
	}
	public String getFile_ext3() {
		return file_ext3;
	}
	public void setFile_ext3(String file_ext3) {
		this.file_ext3 = file_ext3;
	}
	public String getFile_size1() {
		return file_size1;
	}
	public void setFile_size1(String file_size1) {
		this.file_size1 = file_size1;
	}
	public String getFile_size2() {
		return file_size2;
	}
	public void setFile_size2(String file_size2) {
		this.file_size2 = file_size2;
	}
	public String getFile_size3() {
		return file_size3;
	}
	public void setFile_size3(String file_size3) {
		this.file_size3 = file_size3;
	}
	public String getLang() {
		return lang;
	}
	public void setLang(String lang) {
		this.lang = lang;
	}
	
	public String getVocTel() {
		return vocTel;
	}
	public void setVocTel(String vocTel) {
		this.vocTel = vocTel;
	}
	public String getVocEmail() {
		return vocEmail;
	}
	public void setVocEmail(String vocEmail) {
		this.vocEmail = vocEmail;
	}
	public String getResult_txt() {
		return result_txt;
	}
	public void setResult_txt(String result_txt) {
		this.result_txt = result_txt;
	}
	public String getIp_addr() {
		return ip_addr;
	}
	public void setIp_addr(String ip_addr) {
		this.ip_addr = ip_addr;
	}

	
	
	
	
	
}
