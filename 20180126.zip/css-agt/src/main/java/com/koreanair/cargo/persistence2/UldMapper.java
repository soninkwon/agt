package com.koreanair.cargo.persistence2;

import java.util.List;

import javax.annotation.Resource;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;

import com.koreanair.cargo.domain.uld.UldReqDomain;
import com.koreanair.cargo.domain.uld.UldCityDomain;
import com.koreanair.cargo.common.dwr.*;

public interface UldMapper {
	
	List<UldCityDomain> getUldCityList2(UldReqDomain uldReqDomain);
	
}
