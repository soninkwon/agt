package com.koreanair.cargo.persistence2;

import com.koreanair.cargo.domain.VocReqDomain;


public interface VocRealMapper {
	
	int vocRealInput(VocReqDomain vocReqDomain);
	
}
