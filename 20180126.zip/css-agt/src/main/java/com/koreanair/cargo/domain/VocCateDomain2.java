package com.koreanair.cargo.domain;

import java.io.IOException;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;
import org.springframework.web.multipart.MultipartFile;

@DataTransferObject(type="bean", javascript="vocReqDomain")

public class VocCateDomain2 {
	
	private String voc_cate_cd       = "";
	private String voc_cate_desc       = "";
	private String voc_cate_lang      = "";
	
	public String getVoc_cate_cd() {
		return voc_cate_cd;
	}
	public void setVoc_cate_cd(String voc_cate_cd) {
		this.voc_cate_cd = voc_cate_cd;
	}
	public String getVoc_cate_desc() {
		return voc_cate_desc;
	}
	public void setVoc_cate_desc(String voc_cate_desc) {
		this.voc_cate_desc = voc_cate_desc;
	}
	public String getVoc_cate_lang() {
		return voc_cate_lang;
	}
	public void setVoc_cate_lang(String voc_cate_lang) {
		this.voc_cate_lang = voc_cate_lang;
	}

	
}
