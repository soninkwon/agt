package com.koreanair.cargo.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.koreanair.cargo.domain.UploadFileDomain;

@RestController
public class RestFullController {
	private static final Logger logger = LoggerFactory.getLogger(RestFullController.class);
	
	private static String UPLOADED_FOLDER = "d:\\css-1\\file\\";
	
	// Single file upload
	@PostMapping("/file/upload.do")
	public ResponseEntity<?> uploadFile(@RequestParam("file") MultipartFile uploadfile){
		
		logger.info("Single file upload!");
		if(uploadfile.isEmpty())
			return new ResponseEntity("please select a file!", HttpStatus.OK);
		try {
			saveUploadedFiles(Arrays.asList(uploadfile));
		}catch(IOException e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity("successfully uploaded - "+ uploadfile.getOriginalFilename(),new HttpHeaders(), HttpStatus.OK);
	}
	// Multiple file upload
	@PostMapping("/file/multi-upload.do")
	public ResponseEntity<?> uploadFileMulti(@RequestParam("extraField") String extraField, @RequestParam("files") MultipartFile[] uploadfiles){
		
		logger.info("Multiple file upload!");
		 // Get file name
        String uploadedFileName = Arrays.stream(uploadfiles).map(x -> x.getOriginalFilename())
                .filter(x -> !StringUtils.isEmpty(x)).collect(Collectors.joining(" , "));
        if(StringUtils.isEmpty(uploadedFileName))
			return new ResponseEntity("please select a file!", HttpStatus.OK);
        try {
			saveUploadedFiles(Arrays.asList(uploadfiles));
		}catch(IOException e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
        
		return new ResponseEntity("successfully uploaded - "+ uploadedFileName ,new HttpHeaders(), HttpStatus.OK);
	}
	// maps html form to a Model
	@PostMapping("/file/model/multi-upload.do")
	public ResponseEntity<?> multiUploadFileModel(@ModelAttribute UploadFileDomain model){
		
		logger.info("Multiple file upload! With uploadModel");
		try {
			saveUploadedFiles(Arrays.asList(model.getFiles()));
		}catch(IOException e) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity("Successfully uploaded!", HttpStatus.OK);
	}
	
	//save file
	private void saveUploadedFiles(List<MultipartFile> files) throws IOException{
		for(MultipartFile file : files) {
			if(file.isEmpty()) {
				continue;
			}
			byte[] bytes = file.getBytes();
			Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
			Files.write(path, bytes);
		}
	}
}
