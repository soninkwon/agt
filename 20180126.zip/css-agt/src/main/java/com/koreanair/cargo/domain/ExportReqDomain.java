package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="exportReqDomain")

public class ExportReqDomain {
	
	
	private String mawb_no1;
	private String mawb_no2;
	private String mawb_no;
	private String hawb_no;
	private String flt_d;
	private String carr_c;
	private String flt_no;
	
	@RemoteProperty
	
	public String getMawb_no() {
		return mawb_no;
	}
	public void setMawb_no(String mawb_no) {
		this.mawb_no = mawb_no;
	}
	
	@RemoteProperty
	public String getHawb_no() {
		return hawb_no;
	}
	public void setHawb_no(String hawb_no) {
		this.hawb_no = hawb_no;
	}
	
	@RemoteProperty
	public String getFlt_d() {
		return flt_d;
	}
	public void setFlt_d(String flt_d) {
		this.flt_d = flt_d;
	}
	
	@RemoteProperty
	public String getCarr_c() {
		return carr_c;
	}
	public void setCarr_c(String carr_c) {
		this.carr_c = carr_c;
	}
	
	@RemoteProperty
	public String getFlt_no() {
		return flt_no;
	}
	public void setFlt_no(String flt_no) {
		this.flt_no = flt_no;
	}
	
	@RemoteProperty
	public String getMawb_no1() {
		return mawb_no1;
	}
	public void setMawb_no1(String mawb_no1) {
		this.mawb_no1 = mawb_no1;
	}
	
	@RemoteProperty
	public String getMawb_no2() {
		return mawb_no2;
	}
	public void setMawb_no2(String mawb_no2) {
		this.mawb_no2 = mawb_no2;
	}

	
	
	
}