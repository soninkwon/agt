package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="wsMenuReqDomain")
public class WsMenuReqDomain {
	
	
	private String ssoLoginId      = "";
	private String grpId           = "";
	private String menuGrd           = "";
	private String menuId           = "";
		
	public String getSsoLoginId() {
		return ssoLoginId;
	}
	public void setSsoLoginId(String ssoLoginId) {
		this.ssoLoginId = ssoLoginId;
	}
	public String getGrpId() {
		return grpId;
	}
	public void setGrpId(String grpId) {
		this.grpId = grpId;
	}
	public String getMenuGrd() {
		return menuGrd;
	}
	public void setMenuGrd(String menuGrd) {
		this.menuGrd = menuGrd;
	}
	public String getMenuId() {
		return menuId;
	}
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}
	
	
	
		
	
}