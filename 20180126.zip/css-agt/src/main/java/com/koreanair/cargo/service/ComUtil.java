package  com.koreanair.cargo.service;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.text.*;

import java.sql.Timestamp;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.*;
import java.lang.reflect.Array;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.security.*;
import sun.misc.*;

import sun.misc.BASE64Encoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.safenet.datasecure.*;
 


/**
 ***********************************************
 * @sourceName  : ComUtil.java
 * ---------------------------------------------
 * DESCRIPTION  : eCustomer 공통 유틸
 ***********************************************
 * DATE         AUTHOR          HISTORY
 * ---------------------------------------------
 * 2004/06/18	JYJEON			Create
 * 2004/07/18	KHJ				parseUldInfo(String str),parseUldInfo(String str, int len) 추가
 * 2004/07/18	KHJ				parseUldCount(String str) 추가
 * 2004/07/09	JYJEON			replaceAddString(str1, int2, str3) 추가
 * 2005/03/30	KHJ				toDelZeroFltNo 추가
 * 2005/03/30	JJY				substringByteUTF 추가
 ***********************************************
 */
public final class ComUtil {

    private static final String CLASSNAME = ComUtil.class.getName();

	// -------------------------------------------------------------------------
	// 문자코드
	// -------------------------------------------------------------------------
	public static final String TAG_LANG_KOR     	= "ksc5601";
	public static final String TAG_LANG_UNICODE 	= "iso-8859-1";
	public static final String TAG_HTML_KOR     	= "euc-kr";

	// -------------------------------------------------------------------------
	// 데이터 Type
	// -------------------------------------------------------------------------
	public static final String TAG_DATE 			= "D"; // 날짜형
	public static final String TAG_NUM  			= "N"; // 숫자형
	public static final String TAG_INT  			= "I"; // 정수형
	public static final String TAG_CHR  			= "C"; // 문자형

	// -------------------------------------------------------------------------
	// 시간 형식
	// -------------------------------------------------------------------------
	public static final String CHR_DATE 		= "-";
	public static final String CHR_TIME 		= ":";
	public static final String FMT_YEAR 		= "yyyy";					// 년 (4자리) (2000년)
	public static final String FMT_YR 			= "yy";						// 년 (2자리) (00년)
	public static final String FMT_MON 			= "MM";						// 월
	public static final String FMT_DAY 			= "dd"; 					// 일
	public static final String FMT_WEEK			= "ww"; 					// 주
	public static final String FMT_HOUR			= "HH";						// 시(24시)
	public static final String FMT_HR 			= "hh";						// 시(12시)
	public static final String FMT_MIN 			= "mm";						// 분
	public static final String FMT_SEC 			= "ss";						// 초
	public static final String FMT_DATE			= "yyyy-MM-dd"; 			// 기본 일자 형식
	public static final String FMT_TIME			= "HH:mm:ss"; 				// 기본 시분초 형식
	public static final String FMT_DATE_TIME	= "yyyy-MM-dd HH:mm:ss";	// 기본 시각 형식

	// -------------------------------------------------------------------------
	// 요일
	// -------------------------------------------------------------------------
	public static final String TAG_MON 			= "월";
	public static final String TAG_TUE 			= "화";
	public static final String TAG_WED 			= "수";
	public static final String TAG_THU 			= "목";
	public static final String TAG_FRI 			= "금";
	public static final String TAG_SAT 			= "토";
	public static final String TAG_SUN 			= "일";

	// -------------------------------------------------------------------------
	// 요일의 숫자값
	// -------------------------------------------------------------------------
	public static final int FLG_MON 			= 1;
	public static final int FLG_TUE 			= 2;
	public static final int FLG_WED 			= 3;
	public static final int FLG_THU 			= 4;
	public static final int FLG_FRI 			= 5;
	public static final int FLG_SAT 			= 6;
	public static final int FLG_SUN 			= 7;

	// -------------------------------------------------------------------------
	// 숫자 형식
	// -------------------------------------------------------------------------
	public static final String FMT_INT  		= "#,###";				// 정수형
	public static final String FMT_NUM  		= "#,###.###";			// 소수형
	public static final String FMT_NUM1 		= "#,###.0";			// 소수형
	public static final String FMT_NUM2 		= "#,###.00";			// 소수형
	public static final String FMT_NUM3 		= "#,###.000";			// 소수형

	// -------------------------------------------------------------------------
	// 문자
	// -------------------------------------------------------------------------
	public static final String CHR_NULL			= "";
	public static final String CHR_AP 			= "'"; 					// Aphostrophe
	public static final String CHR_AMP 			= "&"; 					// Amphsand
	public static final String CHR_COMMA		= ",";
	public static final String CHR_ZERO 		= "0";
	public static final String CHR_EQUAL		= "="; 					// Equal
    public static final String CHR_ACUTE    	= "&acute;";

	// -------------------------------------------------------------------------
	// Escape 문자
	// -------------------------------------------------------------------------
	public static final String CHR_ESC 	  = "\\";
	public static final String CHR_NEWLINE = "\\n";

	// -------------------------------------------------------------------------
	// 통화 기호
	// -------------------------------------------------------------------------
	public static final String CHR_CURRENCY_KO = "\\";	// 원화
	public static final String CHR_CURRENCY_US = "$";	// 달러
	public static final String CHR_CURRENCY_JP = "￥";	// 엔화
	public static final String CHR_CURRENCY_CH = "?";	// 중국 원화

	// -------------------------------------------------------------------------
	// 데이터 처리 메세지
	// -------------------------------------------------------------------------
	public static final String MSG_SUCC_INSERT 		= " 등록되었습니다.";
	public static final String MSG_SUCC_UPDATE 		= " 수정되었습니다.";
	public static final String MSG_SUCC_DELETE 		= " 삭제되었습니다.";
	public static final String MSG_FAIL_INSERT 		= " 등록이 실패하였습니다!";
	public static final String MSG_FAIL_UPDATE 		= " 수정이 실패하였습니다!";
	public static final String MSG_FAIL_DELETE 		= " 삭제가 실패하였습니다!";
	public static final String MSG_ASK_INSERT  		= " 등록하시겠습니까?";
	public static final String MSG_ASK_UPDATE  		= " 수정하시겠습니까?";
	public static final String MSG_ASK_DELETE  		= " 삭제하시겠습니까?";
	public static final String MSG_PLZ_WAIT    		= " 잠시만 기다려 주십시오...";

	// -------------------------------------------------------------------------
	// Field 검사시 Error 메세지
	// -------------------------------------------------------------------------
	public static final String MSG_ERR_NULL_TYPE 	= " 값을 입력하십시오!";
	public static final String MSG_ERR_DATE_TYPE 	= " 날짜형 값을 입력하십시오! (예) 2000-01-01";
	public static final String MSG_ERR_NUM_TYPE  	= " 숫자형 값을 입력하십시오!";
	public static final String MSG_ERR_INT_TYPE  	= " 정수형 값을 입력하십시오!";
	public static final String MSG_ERR_LEN_LONG  	= " 값의 길이가 너무 깁니다!";
	public static final String MSG_ERR_LEN_SHORT 	= " 값의 길이가 너무 짧습니다!";
	public static final String MSG_ERR_LEN_EQUAL 	= " 값의 길이가 맞지 않습니다!";
	public static final String MSG_ERR_LEN_RANGE 	= " 값의 길이가 범위를 벗어 났습니다!";
	public static final String MSG_ERR_VAL_LARGE 	= " 값이 너무 큽니다!";
	public static final String MSG_ERR_VAL_SMALL 	= " 값이 너무 작습니다!";
	public static final String MSG_ERR_VAL_EQUAL 	= " 값이 맞지 않습니다!";
	public static final String MSG_ERR_VAL_RANGE 	= " 값이 범위를 벗어 났습니다!";
	public static final String MSG_DUP_DATA 		= " 데이터가 존재합니다.";
	public static final String MSG_NON_DATA 		= " 데이터가 존재하지 않습니다!";
	public static final String MSG_DUP_KEY 			= " 이미 데이터가 존재합니다!";
	public static final String MSG_NON_PK  			= " 등록되지 않은 데이터입니다!";
	public static final String MSG_NON_FK  			= " 등록되지 않은 데이터입니다!";
	public static final String MSG_DUP_CK  			= " 연결된 데이터가 존재합니다!";
	public static final String MSG_ERR_PARAM 		= " 파라미터 값 확인 바람!";
	public static final String MSG_ERR_TXNDB 		= " 데이터베이스 처리시 문제가 발생하였습니다.";
	public static final String MSG_EXCEPTION 		= " 요청하신 작업에 대한 처리시 문제가 발생하였습니다."
                                             		+ "<br>다시한번 요청하여 주시고 문제가 발생시 "
                                             		+ "<br>담당자에게 연락을 부탁드립니다.";

    public  String  msg     = "";
    private String  sCnt    = "";
    private int     cnt     =0;

    private static final String encoding = System.getProperty("file.encoding");

    protected PrintWriter out = null;

    public ComUtil() {
        super(); // instantiate GConstant
    }

    public void putMsg(String pMsg, String pAtt){
        msg = msg + repMsg(pMsg,pAtt);
    }

    public String repMsg(String pStr,String pAttach){
        if (pStr.equals("")) {
            return "";
        }

        cnt = cnt +1;

        if (pAttach!="") {
            return sCnt.valueOf(cnt) + ". " + pAttach + " ==> " + pStr + "\\n";
        }else{
            return pStr + "\\n";
        }
    }

    public String getMsg(){
        return msg;
    }

    public void initMsg(){
        msg = "";
        cnt = 0;
    }

    public boolean isMsg(){
        if ((msg == "")||(msg == null)){
             return false;
        }else{
            return true;
        }
    }

    //==================================================================================
    // 문자열 관련 함수
    //==================================================================================
	/**
     * 한글 substring(기본 설정)<br>
     * byte code 연산
	 * @param  str  String 연산 대상 문자열
	 * @param  from int substring 시작점
	 * @return      한글 byte code 연산에 의한 substring 문자열
	 * @see         String
     */
    public static String substringByte(String str, int from ) throws Exception
    {
        return substringByte(str, from, 0);
    }

	/**
     * 한글 substring<br>
     * byte code 연산<br>
	 * @param  str  String 연산 대상 문자열
	 * @param  from int substring 시작점
	 * @param  to   int substring 종결점
	 * @return      한글 byte code 연산에 의한 substring 문자열
	 * @see         String
     */
    public static String substringByte(String str, int from, int to) throws Exception
    {
        byte[] origin = null;
        byte[] sub  = null;
        int size    = 0 ;

        int posTo   = 0 ;
        int iSub    = 0 ;

        if( str == null) return "";

        try{
            origin = str.getBytes("KSC5601");

            size = origin.length;

            if( size < from) return  "";
            if( size < to || to == 0) to = size;

            sub = new byte[to - from];
            for( int iOrg = from ; iOrg < to ; iOrg++)
            {
                sub[iSub++] = origin[iOrg];
            }
        }
        catch(Exception e)
        {

        }
        return new String(sub, "KSC5601");

    }
	/**
     * 한글 substring(기본 설정)<br>
     * byte code 연산
	 * @param  str  String 연산 대상 문자열
	 * @param  from int substring 시작점
	 * @return      한글 byte code 연산에 의한 substring 문자열
	 * @see         String
     */
    public static String substringByteUTF(String str, int from ) throws Exception
    {
        return substringByteUTF(str, from, 0);
    }

	/**
     * 한글 substring<br>
     * byte code 연산<br>
	 * @param  str  String 연산 대상 문자열
	 * @param  from int substring 시작점
	 * @param  to   int substring 종결점
	 * @return      한글 byte code 연산에 의한 substring 문자열
	 * @see         String
     */
    public static String substringByteUTF(String str, int from, int to) throws Exception
    {
        StringBuffer result	= new StringBuffer();
        int size    = 0 ;

        if( str == null) return "";

        try{
            size = str.length();

            if( size < from) return  "";
            if( size < to || to == 0) to = size;

            for( int iOrg = from ; iOrg < to ; iOrg++)
            {
                //sub[iSub++] = origin[iOrg];
                result.append(str.substring(iOrg, iOrg+1));
            }
        }
        catch(Exception e)
        {

        }
        return result.toString();

    }

	/**
     * 유니코드 -> 한글 변환
	 * @param  koreanStr (String) 번환 대상 문자열
	 * @return      문자코드(iso-8859-1)에서 (ksc5601)로 변환된 String
	 * @see         String( koreanStr.getBytes(TAG_LANG_KOR), TAG_LANG_UNICODE)
     */
    public static String toUnicode( String koreanStr ) throws java.io.UnsupportedEncodingException
    {
        koreanStr = trim(koreanStr);

        if (isNull(koreanStr))
            return "";
        else
            return new String( koreanStr.getBytes(TAG_LANG_KOR), TAG_LANG_UNICODE);
    }

	/**
     * Null 제거, 우공백 제거
	 * @param	val (String) 변환 대상 문자열
	 * @return	Null->공백 변환 후 trim()처리한 문자열
	 * @see		String( koreanStr.getBytes(TAG_LANG_KOR), TAG_LANG_UNICODE)
     */
    public static String trim( String val ) {
        val = null2str(val);
        val = val.trim();

        return val;
    }

	/**
     * 널이면 빈문자열, 그렇지 않으면 원래 문자열로 변환
	 * @param	val (String) 변환 대상 문자열
	 * @return	Null->공백 변환
	 * @see		null2str(val, "")
     */
    public static String null2str( String val ) {
        return null2str(val, "");
    }

	/**
     * Null일 경우 특정 문자열로 치환한다.
	 * @param	val (String) 변환 대상 문자열
	 * @param	toVal (String) Null일 경우 치환할 문자열
	 * @return	Null->toVal 치환
	 * @see
     */
    public static String null2str( String val, String toVal ) {

        if (isNull(val))
            return toVal;
        else
            val = val.trim();
            return val;
    }

	/**
     * Null 체크
	 * @param	val (String) 변환 대상 문자열
	 * @return	Null or Empty String 일 경우 True<br> 아닐 경우 False
	 * @see
     */
    public static boolean isNull( String val ) {

        if(val == null) val = "";

        if (val.equals("")) {
            return true;
        }
        else {
            return false;
        }
    }

	/**
     * 대문자로 치환
	 * @param	val (String) 변환 대상 문자열
	 * @return	대상 문자열을 대문자로 치환한 문자열
	 * @see		val.toUpperCase()
     */
    public static String toUpperCase( String val ) {
        return val.toUpperCase();
    }

	/**
     * 소문자로 치환
	 * @param	val (String) 변환 대상 문자열
	 * @return	대상 문자열을 소문자로 치환한 문자열
	 * @see		val.toLowerCase()
     */
    public static String toLowerCase( String val ) {
        return val.toLowerCase();
    }

	/**
     * 한글 문자열 길이
	 * @param	val (String) 대상 문자열
	 * @return	유니코드로 변환한 문자열의 length
	 * @see		sVal.length()
     */
    public static int strLen( String val ) {
        String sVal;

        try{
            sVal = toUnicode(val);
        } catch (Exception e) {
            return -1;
        }

        return sVal.length();
    }

	/**
     * 둘 중 큰 값을 리턴
	 * @param	val1 (String) 비교 대상 문자열1
	 * @param	val2 (String) 비교 대상 문자열2
	 * @return	val1과 val2값을 비교하여 큰 문자열
	 * @see		val1.compareTo(val2)
     */
    public static String max( String val1, String val2 ) throws NullPointerException {
        if (val1.compareTo(val2) >= 0)
            return val1;
        else
            return val2;
    }

	/**
     * 둘 중 작은 값을 리턴
	 * @param	val1 (String) 비교 대상 문자열1
	 * @param	val2 (String) 비교 대상 문자열2
	 * @return	val1과 val2값을 비교하여 작은 문자열
	 * @see		val1.compareTo(val2)
     */
    public static String min( String val1, String val2 ) throws NullPointerException {
        if (val1.compareTo(val2) <= 0)
            return val1;
        else
            return val2;
    }


	/**
     * 문자열에 특정 포멧을 설정 한다.
	 * @param	val (String) 대상  문자열
	 * @param	thisFormat (String) 리턴시 포멧(예 ####-##-##)
	 * @return	특정 포멧으로 변경된 문자열
	 * @see		#String
     */
    public static String replaceFormat( String val, String thisFormat ) {
    	int replaceSize	= trim(val).length();
    	int roopSize	= trim(thisFormat).length();
        int count = 0;
        String tempFormat = "";
        String tempReplace = "";
        StringBuffer replaceString = new StringBuffer(10);
        int x = 0;

        try{
        	if(!trim(val).equals("null") && replaceSize > 0){
	            for(x=0; roopSize > x; x++){
	            	tempFormat	= thisFormat.substring(x,(roopSize - (roopSize - (x+1))));
	            	if(tempFormat.equals("#")){
	            		tempReplace = val.substring(count,(roopSize - (roopSize - (count+1))));
	            		replaceString.append(tempReplace);
	            		count++;
	            	}else{
	            		replaceString.append(tempFormat);
	            	}

	            	if(replaceSize == count) break;
	            }
			}

        } catch (Exception e) {

            return null;
        }

        return replaceString.toString();
    }

    /**
     * 원하는 문자 삭제<br>
     * 예) Strxxxxing, x ----> string<br>
	 * @param	String 대상  문자열
	 * @param	String 삭제 기준 문자
	 * @return	기준 문자가 제거된 문자열
	 * @see		#String
     */
    public static String removeChar(String str, String deli)
    {
        String result = "";
        if(!str.equals(""))
        {
            StringTokenizer st = new StringTokenizer(str, deli);
            StringBuffer buffer = new StringBuffer();
            for(; st.hasMoreTokens(); buffer.append(st.nextToken()));

            result = buffer.toString();
        }
        return result;
    }

    /**
     * comma제거<br>
     * 예) 123,456,789 ----> 123456789<br>
	 * @param	String 대상  문자열
	 * @return	String Comma가 제거된 문자열
	 * @see		#String
     */
    public static String  removeComma(String s)
    {
        if ( s == null ) return null;
            if ( s.indexOf(",") != -1 )
            {
                StringBuffer buf = new StringBuffer();
                for(int i=0;i<s.length();i++){
                    char c = s.charAt(i);
                    if ( c != ',') buf.append(c);
                }
                return buf.toString();
            }
        return s;
    }

    /**
     * 점이하 제거<br>
     * 예) 123456.789 ----> 123456<br>
	 * @param	String 대상  문자열
	 * @return	String Point가 제거된 문자열
	 * @see		#String
     */
    public static String removePoint(String str)
    {
            int pt_index=0;

            if (str==null || str=="" || str.length() < 1 )  return "";

            pt_index = str.indexOf('.');

            if (pt_index==-1)      return str;
            str=str.substring(0,pt_index);

            return str;

    }

    //==================================================================================
    // 숫자형 관련 함수
    //==================================================================================

	/**
     * 문자열을 INT형으로 형변환 한다.<br>
	 * @param	String	대상 문자열
	 * @return	int		Null,공백 제거후 공백-> 0 치환 후 int형 변형 값
	 * @see		#int
     */
    public static int str2int( String val ) {

        val = trim(val);
        val = null2str(val, "0");

        return (new Integer(val)).intValue();
    }

    /**
     * 문자열을 LONG형으로 형변환 한다.<br>
	 * @param	String	대상 문자열
	 * @return	long	Null,공백 제거후 공백-> 0 치환 후 long형 변형 값
	 * @see		#long
     */
    public static long str2long( String val ) {

        val = trim(val);
        val = null2str(val, "0");

        //return (new Long(val)).longValue();
        return (new Double(val)).longValue(); // 문자열에 소수가 포함되어 있는 경우를 감안
    }

	/**
     * 문자열을 FLOAT형으로 형변환 한다.<br>
	 * @param	String	대상 문자열
	 * @return	float	Null,공백 제거후 공백-> 0 치환 후 float형 변형 값
	 * @see		float
     */
    public static float str2float( String val ) {

        val = trim(val);
        val = null2str(val, "0");

        return (new Float(val)).floatValue();
    }

	/**
     * 숫자형 여부 검사<br>
	 * @param	String	대상 문자열
	 * @return	boolean	대상 문자열이 숫자형 변환이 가능하면 True
	 * @see		#boolean
     */
    public static boolean isNumber( String val ) {
        if (isNull(val)) return true; // 널에 대해서는 검사하지 않음.

        try{
            double nVal = (new Double(val)).doubleValue(); // 숫자형이면 에러가 발생하지 않는다.
        } catch(Exception e){ // NumberFormatException
            return false;
        }

        return true;
    }

	/**
     * 정수형 여부 검사<br>
	 * @param	String	대상 문자열
	 * @return	boolean	대상 문자열이 정수형 변환이 가능하면 True
	 * @see		#boolean
     */
    public static boolean isInteger( String val ) {

        if (isNull(val)) return true; // 널에 대해서는 검사하지 않음.

        try{
            int nVal = (new Integer(val)).intValue(); // 정수형이면 에러가 발생하지 않는다.
        } catch(Exception e){ // NumberFormatException
            return false;
        }

        return true;
    }

	/**
     * 숫자 문자열을 원하는 숫자 형식으로<br>
	 * @param	String	대상 문자열
	 * @param	String	숫자 형식
	 * @return	String	변경된 포멧의 문자열
	 * @see		#String
     */
    public static String formatNumber( String val, String toFormat ) {

        String sVal = "";

        val = trim(val);
        val = null2str(val, "0");

        try{
            DecimalFormat myFormat = new DecimalFormat(toFormat);
            sVal = myFormat.format(myFormat.parse(val));

        }
        catch (Exception e){
        }

        return sVal;
    }

	/**
     * 몫 구하기<br>
     * (예) 2401 / 500 = 4<br>
	 * @param	float
	 * @param	float
	 * @return	long	몫
	 * @see		#long
     */
    public static long divide2long( float val1, float val2 ) {
        return (long) (val1 / val2); // 2401 / 500 = 4
    }

	/**
     * 나머지 정수 구하기<br>
     * (예) 2401 - 500 * 4 = 401<br>
	 * @param	long
	 * @param	long
	 * @return	long	나머지 정수
	 * @see		#long
     */
    public static long remain2long( long val1, long val2 ) {
        return val1 - (val2 * divide2long((float)val1, (float)val2));   // 2401 - 500 * 4 = 401
    }

	/**
     * 나머지 실수 구하기<br>
     * (예) 2401.5 - 500 * 4 = 401.5<br>
	 * @param	float
	 * @param	float
	 * @return	float	나머지 실수
	 * @see		#float
     */
    public static float remain2float( float val1, float val2 ) {
        return val1 - (val2 * divide2long(val1, val2)); // 2401.5 - 500 * 4 = 401.5
    }

    /**
     * 반올림 실수
     * 1234.456, 2 --> 1234.5<br>
	 * @param	double	대상 숫자
	 * @param	int		반올림할 자릿수
	 * @return	String	반올림된 실수
	 * @see		#String
     */
    public  static String formatNum(double num, int underNum )
    {
        String formats = formatReturn(underNum);

        DecimalFormat df = new DecimalFormat(formats);
        return df.format(num);

	}

    /**
     * 반올림
     * 1234.456, 2 --> 1234.5<br>
	 * @param	double	대상 숫자
	 * @param	int		반올림할 자릿수
	 * @return	double	반올림된 실수
	 * @see		#double
     */
    public static String formatNum(int num, int underNum )
    {
        String formats = formatReturn(underNum);

        DecimalFormat df = new DecimalFormat(formats);
        return df.format(num);

    }

    /**
     * 반올림
	 * @param	long	대상 숫자
	 * @param	int		반올림할 자릿수
	 * @return	String	반올림된 숫자
	 * @see		#String
     */
    public static String formatNum(long num, int underNum)
    {
        String formats = formatReturn(underNum);
        DecimalFormat df = new DecimalFormat(formats);
        return df.format(num);

    }

    /**
     * 반올림
	 * @param	String	대상 숫자
	 * @param	int		반올림할 자릿수
	 * @return	String	반올림된 숫자
	 * @see		#String
     */
    public  static String formatNum(String num, int underNum)
    {
        double d = 0.0D;
        try
        {
            d = Double.valueOf(num).doubleValue();
        }
        catch(Exception _ex)
        {
            //d = 0.0D;
        	d = d;
        }
        return formatNum( d, underNum );
    }

    /**
     * format반환
     */
    public static String formatReturn(int underNum)
    {
        String formats = "";
        if( underNum ==0 ) formats = "###,###,###,##0";
        else               formats = "###,###,###,##0." + setChar( underNum ,"0") ;// 0의 갯수만큼 채운다 ,#:0을 한번만
        return formats;
    }

    /**
     * 소수 반올림<br>
     * double round = Math.pow(10,pntLen);<br>
     * newDoub = Math.floor(doub * round +.5)/round;<br>
     * 즉 소수 2째자리 반올림은<br>
     * y= Math.floor(x*100+.5)/100;<br>
     * 단, 일정자리수 넘어가면 4.7*E07식으로 나옴<br>
	 * @param	double	대상 숫자
	 * @param	int		반올림할 자릿수
	 * @return	double	반올림된 숫자
	 * @see		#double
     */
    public static double roundDouble(double num,int underNum)
    {
        double newDoub = 0.0d;

        try
        {
            String formats = formatReturn(underNum);
            DecimalFormat df = new DecimalFormat(formats);
            newDoub = Double.valueOf( df.format(num) ).doubleValue();

        }
        catch(Exception _ex)
        {
            newDoub = newDoub;
        }

        return newDoub;

    }

    /**
     * 소수 반올림<br>
     * double round = Math.pow(10,pntLen);<br>
     * newDoub = Math.floor(doub * round +.5)/round;<br>
     * 즉 소수 2째자리 반올림은<br>
     * y= Math.floor(x*100+.5)/100;<br>
     * 단, 일정자리수 넘어가면 4.7*E07식으로 나옴<br>
	 * @param	String	대상 숫자
	 * @param	int		반올림할 자릿수
	 * @return	double	반올림된 숫자
	 * @see		#double
     */
    public static double roundDouble(String doub,int pntLen)
    {

        double d = 0.0D;
        try
        {
            d = Double.valueOf(doub).doubleValue();
        }
        catch(Exception _ex)
        {
            d = d;
        }


        return roundDouble(d,pntLen);

    }

    //==================================================================================
    // 날짜형 관련 함수
    //==================================================================================

	/**
     * 날짜 형식 검사
	 * @param	String	검사 대상 문자열
	 * @param	String	날짜형 형식
	 * @return	boolean
	 * @see		#boolean
     */
    public static boolean isDate( String val,
                           String format
                           )
	{
        val = null2str(val);

        if (isNull(val)) return true; // 널에 대해서는 검사하지 않음.
        if (isNull(format)) format = FMT_DATE;

        SimpleDateFormat myFormat = new SimpleDateFormat (format);
        //ParsePosition pos = new ParsePosition(0);

        Date dDate = new Date();
        String sDate = "";

        try{
            dDate = myFormat.parse(val);
            sDate = myFormat.format(dDate);      // 2000-01-01 = 1999-13-01
        } catch (Exception e) { // java.text.ParseException
            return false;
        }

        if (val.equals(sDate))
            return true;
        else
            return false;
    }

	/**
     * Application Server 현재 시각 구하기
	 * @param	none
	 * @return	시스템 현재 시각
	 * @see		#sysdate(FMT_DATE)
     */
    public static String sysdate() {
        return sysdate(FMT_DATE);
    }

	/**
     * Application Server 현재 시각 구하기(포멧설정)
	 * @param	toFormat (String) 리턴 받을 현재 시각의 포멧
	 * @return	시스템 현재 시각
	 * @see		#String
     */
    public static String sysdate( String toFormat ) {
        String  sDate = "";
        Date        dDate = new Date();

        if (toFormat.equals("")) toFormat = FMT_DATE;

        try{
            SimpleDateFormat myFormat = new SimpleDateFormat (toFormat);

            sDate = myFormat.format(dDate);

        } catch (Exception e) {
            sDate = "";
        }

        return sDate;
    }

    /**
     * 일자 증감<br>
     * (예) sRet = myEms.addDate("2000-01-01",1);	// 2000-01-02 (1일 증가)<br>
     * (예) sRet = myEms.addDate("2000-01-01",-1);	// 1999-12-31 (1일 감소)
	 * @param	toFormat (String) 대상 날짜 문자열
	 * @param	toFormat (int) 증감 하고자 하는 일수
	 * @return	증감된 날짜의 문자열
	 * @see		addDate(val, addVal, FMT_DAY, FMT_DATE, FMT_DATE)
     */
    public static String addDate( String val, int addVal ) {
        return addDate(val, addVal, FMT_DAY, FMT_DATE, FMT_DATE);
    }

    /**
     * 특정 필드 시간 증감<br>
     * (예) sRet = myEms.addDate("2000-01-01",1, "ww"); // 2000-01-08 (1주 증가)
	 * @param	toFormat (String) 대상 날짜 문자열
	 * @param	toFormat (int) 증감 하고자 하는 범위
	 * @param	toFormat (String) 증감 하고자 하는 대상(년/월/일/주/...)
	 * @return	증감된 날짜의 문자열
	 * @see		addDate(val, addVal, addField, FMT_DATE, FMT_DATE)
     */
    public static String addDate( String val, int addVal, String addField ) {
        return addDate(val, addVal, addField, FMT_DATE, FMT_DATE);
    }

    /**
     * 형식을 감안한 일자 증감<br>
     * (예) sRet = myEms.addDate("2000/01/01",1, "dd", "yyyy/MM/dd");   // 2000/01/02 (1일 증가)<br>
     * (예) sRet = myEms.addDate("2000-01-01", 1,"MM",FMT_DATE);    // 2000-02-01 (1달 증가)<br>
     * (예) sRet = myEms.addDate("2000-01-01",1,"yy", FMT_DATE);    // 2001-01-01 (1년 증가)<br>
     * (예) sRet = myEms.addDate("2000-01-01 08:00:00",1,"ss","yyyy-MM-dd HH:mm:ss"); // 1초 증가
	 * @param	toFormat (String) 대상 날짜 문자열
	 * @param	toFormat (int) 증감 하고자 하는 범위
	 * @param	toFormat (String) 증감 하고자 하는 대상(년/월/일/주/...)
	 * @param	toFormat (String) 날짜 포멧
	 * @return	증감된 날짜의 문자열
	 * @see		addDate(val, addVal, addField, FMT_DATE, FMT_DATE)
     */
    public static String addDate( String val, int addVal, String addField, String thisFormat ) {
        return addDate(val, addVal, addField, thisFormat, thisFormat);
    }
    
    public static String addDate2( String val, int addVal, String addField, String thisFormat ) {
        return addDate2(val, addVal, addField, thisFormat, thisFormat);
    }

    /**
     * 일자 증감을 한 후 형식 변환<br>
     * (예) sRet = myEms.addDate("2000-01-01 08:00:00",1,"dd","yyyy-MM-dd HH:mm:ss","yyyy/MM/dd"); // 2000/01-02<br>
     * 달(MM) 증감시 답이 제대로 안나옴. ysj 2000-04-05
	 * @param	toFormat (String) 대상 날짜 문자열
	 * @param	toFormat (int) 증감 하고자 하는 범위
	 * @param	toFormat (String) 증감 하고자 하는 대상(년/월/일/주/...)
	 * @param	toFormat (String) 날짜 포멧(변경전)
	 * @param	toFormat (String) 날짜 포멧(변경후)
	 * @return	증감된 날짜의 문자열
	 * @see		String
     */
    public static String addDate( String val, int addVal, String addField, String thisFormat, String toFormat ) {

        String sDate;
        Date dDate = new Date();


        try{

            Calendar myCalendar = Calendar.getInstance();
            dDate = str2date(val, thisFormat);
            myCalendar.setTime(dDate);

            // 주 단위 증감 감안
            int iAddVal = addVal;

            String sAddField = addField;

            if (addField.equals(FMT_WEEK)) {
                iAddVal = iAddVal * 7;
                sAddField = FMT_DAY;
            }

            int iAddField = calendarField(sAddField);

            myCalendar.add(iAddField, iAddVal);
            dDate = myCalendar.getTime();
            sDate = date2str(dDate, toFormat);
        } catch (Exception e) {
            sDate = "";
        }

        return sDate;
    }
    
    public static String addDate2( String val, int addVal, String addField, String thisFormat, String toFormat ) {

        String sDate;
        Date dDate = new Date();


        try{

            Calendar myCalendar = Calendar.getInstance();
            dDate = str2date2(val, thisFormat);
            myCalendar.setTime(dDate);

            // 주 단위 증감 감안
            int iAddVal = addVal;

            String sAddField = addField;

            if (addField.equals(FMT_WEEK)) {
                iAddVal = iAddVal * 7;
                sAddField = FMT_DAY;
            }

            int iAddField = calendarField(sAddField);

            myCalendar.add(iAddField, iAddVal);
            dDate = myCalendar.getTime();
            sDate = date2str(dDate, toFormat);
        } catch (Exception e) {
            sDate = "";
        }

        return sDate;
    }

    
    public static String lastDateOfMon2() {
    	
    	String sFormat = addDate(sysdate(), 1, "MM",FMT_DATE);
        String sDate = sFormat.substring(0,7) + "-01";
        
        sDate = addDate(sDate, -1, "dd");

        return sDate;
        
    }
    
    
    /**
     * 달의 마지막 일자 구하기
     * 이번달 마지막 일자
	 * @return	String
	 * @see		#String
     */
    public static String lastDateOfMon() {
        return lastDateOfMon(sysdate(), FMT_DATE, FMT_DATE);
    }
    

	/**
     * 해당월 마지막 일자
	 * @param	String 날짜 정보
	 * @return	String
	 * @see		#String
     */
    public static String lastDateOfMon(String val) {
        return lastDateOfMon(val, FMT_DATE, FMT_DATE);
    }

	/**
     * 해당월 마지막 일자(포멧 설정)
	 * @param	String 날짜 정보
	 * @param	String 날짜 포멧 정보
	 * @return	String
	 * @see		#String
     */
    public static String lastDateOfMon(String val, String thisFormat) {
        return lastDateOfMon(val, thisFormat, thisFormat);
    }

	/**
     * 해당월 마지막 일자(포멧 변경)
	 * @param	String 날짜 정보
	 * @param	String 날짜 포멧 정보(변경전)
	 * @param	String 날짜 포멧 정보(변경후)
	 * @return	String
	 * @see		#String
     */
    public static String lastDateOfMon(String val, String thisFormat, String toFormat ) {
        String sFormat = FMT_YEAR + CHR_DATE + FMT_MON; // yyyy-MM
        String sDate = formatDate(val, sFormat, thisFormat); // 2000-01-20 -> 2000-01

        sDate = addDate(sDate, 1, FMT_MON, sFormat); // 2000-01 -> 2000-02
        sDate = addDate(sDate, -1, FMT_DAY, sFormat, toFormat); // 2000-02 -> 2000-01-31

        return sDate;
    }

	/**
     * 달의 마지막 첫째 일자 구하기
	 * @return	String 이번달 첫째 일자
	 * @see		#String
     */
    public static String firstDateOfMon() {
        return firstDateOfMon(sysdate(), FMT_DATE, FMT_DATE);
    }

	/**
     * 해당월 첫째 일자
	 * @param	String 날짜 정보
	 * @return	String 해당월 첫째 일자
	 * @see		#String
     */
    public static String firstDateOfMon(String val) {
        return firstDateOfMon(val, FMT_DATE, FMT_DATE);
    }

	/**
     * 해당월 첫째 일자(포멧 설정)
	 * @param	String 날짜 정보
	 * @param	String 날짜 포멧 정보
	 * @return	String 해당월 첫째 일자
	 * @see		#String
     */
    public static String firstDateOfMon(String val, String thisFormat) {
        return firstDateOfMon(val, thisFormat, thisFormat);
    }

	/**
     * 해당월 첫째 일자(포멧 변경)
	 * @param	String 날짜 정보
	 * @param	String 날짜 포멧 정보(변경전)
	 * @param	String 날짜 포멧 정보(변경후)
	 * @return	String 해당월 첫째 일자
	 * @see		#String
     */
    public static String firstDateOfMon(String val, String thisFormat, String toFormat ) {
        String sFormat = FMT_YEAR + CHR_DATE + FMT_MON; // yyyy-MM
        String sDate = formatDate(val, sFormat, thisFormat); // 2000-01-20 -> 2000-01

        sDate = sDate + CHR_DATE + "01"; // 2000-01 -> 2000-02-01
        sFormat = sFormat + CHR_DATE + FMT_DAY; // yyyy-MM -> yyyy-MM-dd
        sDate = formatDate(sDate, sFormat, toFormat); // 2000-01-01 -> 2000-01-01

        return sDate;
    }

	/**
     * 윤년 여부 검사(현 년도)
	 * @return	boolean
	 * @see		#boolean
     */
    public static boolean isLeapYear() {
        return isLeapYear(sysdate(FMT_DATE), FMT_DATE);
    }

    /**
     * 윤년 여부 검사(특정 년도)
	 * @param	String 날짜 정보
	 * @return	boolean
	 * @see		#boolean
     */
    public static boolean isLeapYear(String val) {
        return isLeapYear(val, FMT_DATE);
    }

    /**
     * 윤년 여부 검사(특정 년도 포멧 설정)<br>
     * 4 - 윤년, 100 - 평년, 400 - 윤년, 1900 - 평년, 2000 - 윤년, 2004 - 윤년
	 * @param	String 날짜 정보
	 * @param	String 날짜 포멧 정보
	 * @return	boolean
	 * @see		#boolean
     */
    public static boolean isLeapYear(String val, String thisFormat) {
        String sYear = formatDate(val, FMT_YEAR, thisFormat); // 2000-01-15 -> 2000
        long nYear = str2long(sYear);

        boolean bLeap = false;

        if (remain2long(nYear, 400) == 0)
            bLeap = true;
        else if (remain2long(nYear, 100) == 0)
            bLeap = false;
        else if (remain2long(nYear, 4) == 0)
            bLeap = true;
        else
            bLeap = false;

        return bLeap;
    }

	/**
     * 문자열을 날짜형으로 변환
	 * @param	val (String) 대상 날짜 문자열
	 * @return	변형된 Date형 날짜
	 * @see		str2date(val, FMT_DATE)
     */
    public static Date str2date( String val ) {
        return str2date(val, FMT_DATE);
    }

	/**
     * 문자열을 날짜형으로 변환(포멧 설정)(JJY)
	 * @param	val (String) 대상 날짜 문자열
	 * @param	thisFormat (String) 리턴시 날짜 포멧
	 * @return	변형된 Date형 날짜
	 * @see		Date
     */
    public static Date str2date( String val, String thisFormat ) {
        String sDate = "";
        Date dDate = new Date();
        String numberString = trim(val);
        String tempStr = "";
        StringBuffer dateString = new StringBuffer(10);
        int x = 0;

        try{
            SimpleDateFormat myFormat = new SimpleDateFormat(thisFormat);

            for(x=0; numberString.length() > x; x++){
            	tempStr = val.substring(x,(numberString.length() - (numberString.length() - (x+1))));
            	if(isNumber(tempStr))
            		dateString.append(tempStr);
            }

        	if(dateString.toString().length() < 8){
        		dDate = myFormat.parse("xxxx");
        	}else{
            	tempStr = replaceFormat(dateString.toString(),"####-##-##");
            	dDate = myFormat.parse(tempStr);
            }

        } catch (Exception e) {
            return null;
        }

        return dDate;
    }


	/**
     * 날짜형을 문자열로 변환
	 * @param	val (Date) 대상 날짜형
	 * @return	변형된 String형 날짜
	 * @see		date2str(val, FMT_DATE)
     */
    public static String date2str( Date val ) {
        return date2str(val, FMT_DATE);
    }

	/**
     * 날짜형을 문자열로 변환(포멧 설정)
	 * @param	val (Date) 대상 날짜형
	 * @param	toFormat (String) 리턴시 날짜 포멧
	 * @return	변형된 String형 날짜
	 * @see		String
     */
    public static String date2str( Date val, String toFormat ) {
        String sDate = "";

        try{
            SimpleDateFormat myFormat = new SimpleDateFormat (toFormat);
            sDate = myFormat.format(val);

        } catch (Exception e) {
            return null;
        }

        return sDate;
    }

	/**
     * 날짜 문자열을 원하는 날짜 형식으로
	 * @param	val (String) 대상 일자 문자열
	 * @return	날짜 포멧(Date기본 포멧) 변경 문자열
	 * @see		formatDate(val, toFormat, FMT_DATE)
     */
    public static String formatDate( String val) {
        return formatDate(val, FMT_DATE, FMT_DATE);
    }

	/**
     * 날짜 문자열을 원하는 날짜 형식으로
	 * @param	val (String) 대상 일자 문자열
	 * @param	toFormat (String) 변경하고자 하는 날짜 포멧
	 * @return	날짜 포멧 변경 문자열
	 * @see		formatDate(val, toFormat, FMT_DATE)
     */
    public static String formatDate( String val, String toFormat ) {
        return formatDate(val, toFormat, FMT_DATE);
    }

	/**
     * 날짜 문자열을 원하는 날짜 형식으로 치환
	 * @param	val (String) 대상 일자 문자열
	 * @param	toFormat (String) 변경하고자 하는 날짜 포멧
	 * @param	thisFormat (String) 변경전 날짜 포멧
	 * @return	날짜 포멧 변경 문자열
	 * @see		String
     */
    public static String formatDate( String val, String toFormat, String thisFormat ) {

        String sDate;
        Date    dDate;

        try{
            dDate = str2date(val, thisFormat);
            if(!dDate.equals(""))
            	sDate = date2str(dDate, toFormat);
            else
            	sDate = "";

        } catch (Exception e) {
            sDate = "";
        }

        return sDate;
    }

    /*
    String sDate1 = "2000-01-01 00:50";
    String sDate2 = "2000-01-01 01:51";
    long iRet;
    */

    /**
     *
     * 분차이
     * iRet = myEms.time_diff(sDate2, sDate1, FMT_MIN, "yyyy-MM-dd HH:mm", "yyyy-MM-dd HH:mm") ; // == 61
	 * 시차이
	 * iRet = myEms.time_diff(sDate2, sDate1, FMT_HOUR, "yyyy-MM-dd HH:mm", "yyyy-MM-dd HH:mm") ; // == 1
	 * 일차이
	 * iRet = myEms.time_diff(sDate2, sDate1, FMT_DAY, "yyyy-MM-dd HH:mm", "yyyy-MM-dd HH:mm") ; // == 0
     * 시간 차 계산<br>
     * 내부 diffTime( String val1, String val2, String field, String format1, String format2 ) 호출
     */
    public static long diffTime( String val1, String val2 ) {
        return diffTime(val1, val2, FMT_DAY, FMT_DATE, FMT_DATE);
    }

    /**
     * 시간 차 계산<br>
     * 내부 diffTime( String val1, String val2, String field, String format1, String format2 ) 호출
     */
    public static long diffTime( String val1, String val2, String field ) {
        return diffTime(val1, val2, field, FMT_DATE, FMT_DATE);
    }

    /**
     * 시간 차 계산<br>
     * [[분차이]]<br>
     * iRet = myEms.time_diff(sDate2, sDate1, FMT_MIN, "yyyy-MM-dd HH:mm", "yyyy-MM-dd HH:mm") ; // == 61<br>
     * [[시차이]]<br>
     * iRet = myEms.time_diff(sDate2, sDate1, FMT_HOUR, "yyyy-MM-dd HH:mm", "yyyy-MM-dd HH:mm") ; // == 1<br>
     * [[일차이]]<br>
     * iRet = myEms.time_diff(sDate2, sDate1, FMT_DAY, "yyyy-MM-dd HH:mm", "yyyy-MM-dd HH:mm") ; // == 0<br>
     * 내부 diffTime( Date val1, Date val2, String field ) 호출<br>
     */
    public static long diffTime( String val1, String val2, String field, String format1, String format2 ) {
        Date dDate1 = str2date(val1, format1);
        Date dDate2 = str2date(val2, format2);

        return diffTime(dDate1, dDate2, field);
    }

    /**
     * 시간 차 계산<br>
     */
    public static long diffTime( Date val1, Date val2, String field ) {

        int calField = calendarField(field);

        long nTime1         = val1.getTime();
        long nTime2         = val2.getTime();
        long nDiffTime  = nTime1 - nTime2; //milisecond 단위
        long nField         = 1;

        if (calField == Calendar.SECOND)
            nField = 1000;						// second = milisecond * 1000
        else if (calField == Calendar.MINUTE)
            nField = 1000 * 60;					// minute = milisecond * 1000 * 60
        else if (calField == Calendar.HOUR)
            nField = 1000 * 60 * 60;			// hour = milisecond * 1000 * 60 * 60
        else if (calField == Calendar.DATE)
            nField = 1000 * 60 * 60 * 24;		// hour = milisecond * 1000 * 60 * 60 * 24

        nDiffTime = nDiffTime / nField;

        return nDiffTime;
    }
    
    public static long diffTime2( String val1, String val2, String field, String format1, String format2 ) {
    	
        Date dDate1 = str2date2(val1, format1);
        Date dDate2 = str2date2(val2, format2);

        return diffTime2(dDate1, dDate2, field);
    }
    
    public static Date str2date2( String val, String thisFormat ) {
        String sDate = "";
        Date dDate = new Date();
        String numberString = trim(val);
        String tempStr = "";
        StringBuffer dateString = new StringBuffer(10);
        int x = 0;

        try{
            SimpleDateFormat myFormat = new SimpleDateFormat(thisFormat);

            for(x=0; numberString.length() > x; x++){
            	tempStr = val.substring(x,(numberString.length() - (numberString.length() - (x+1))));
            	if(isNumber(tempStr))
            		dateString.append(tempStr);
            }

        	if(dateString.toString().length() < 8){
        		dDate = myFormat.parse("xxxx");
        	}else{
            	tempStr = replaceFormat(dateString.toString(),"####-##-## ##:##:##");
            	dDate = myFormat.parse(tempStr);
            }

        } catch (Exception e) {
            return null;
        }

        return dDate;
    }


public static long diffTime2( Date val1, Date val2, String field ) {

        int calField = calendarField(field);


        long nTime1         = val1.getTime();
        long nTime2         = val2.getTime();
        long nDiffTime  = nTime1 - nTime2; //milisecond 단위
        long nField         = 1;

        if (calField == Calendar.SECOND)
            nField = 1000;						// second = milisecond * 1000
        else if (calField == Calendar.MINUTE)
            nField = 1000 * 60;					// minute = milisecond * 1000 * 60
        else if (calField == Calendar.HOUR)
            nField = 1000 * 60 * 60;			// hour = milisecond * 1000 * 60 * 60
        else if (calField == Calendar.DATE)
            nField = 1000 * 60 * 60 * 24;		// hour = milisecond * 1000 * 60 * 60 * 24

        nDiffTime = nDiffTime / nField;

        return nDiffTime;
    }

	/**
     * Calendar 클래스 상수<br>
     * Calendar 객체에서 해당 구분자에 해당하는<br>
     * 시간을 리턴 받는다.<br>
     * 년 : FMT_YEAR OR FMT_YR		월 : FMT_MON<br>
     * 일 : FMT_DAY					시 : FMT_HOUR<br>
     * 분 : FMT_MIN					초 : FMT_SEC<br>
     * 월 : TAG_MON OR 1				화 : TAG_TUE OR 2<br>
     * 수 : TAG_WED OR 3				목 : TAG_THU OR 4<br>
     * 금 : TAG_FRI OR 5				금 : TAG_SAT OR 6<br>
     * 일 : TAG_SUN OR 7	<br>
	 * @param	String	년월일분초 구분자
	 * @return	int
	 * @see		int
     */
    public static int calendarField( String field   // 년월일분초 구분자
                            )
    {
        int iField = Calendar.DATE;

        if (field.equals(FMT_YEAR) || field.equals(FMT_YR)) //년
            iField = Calendar.YEAR;
        else if (field.equals(FMT_MON)) //달
            iField = Calendar.MONTH;
        else if (field.equals(FMT_DAY)) //일
            iField = Calendar.DATE;
        else if (field.equals(FMT_HOUR)) //시
            iField = Calendar.HOUR;
        else if (field.equals(FMT_MIN)) //분
            iField = Calendar.MINUTE;
        else if (field.equals(FMT_SEC)) //초
            iField = Calendar.SECOND;

        else if (field.equals(TAG_MON) || field.equals("1")) // 월
            iField = FLG_MON; //1;
        else if (field.equals(TAG_TUE) || field.equals("2")) // 화
            iField = FLG_TUE; //2;
        else if (field.equals(TAG_WED) || field.equals("3")) // 수
            iField = FLG_WED; //3;
        else if (field.equals(TAG_THU) || field.equals("4")) // 목
            iField = FLG_THU; //4;
        else if (field.equals(TAG_FRI) || field.equals("5")) // 금
            iField = FLG_FRI; //5;
        else if (field.equals(TAG_SAT) || field.equals("6")) // 토
            iField = FLG_SAT; //6;
        else if (field.equals(TAG_SUN) || field.equals("7")) // 일
            iField = FLG_SUN; //7;

        return iField;
    }

    /**
     * 년월일입력해 월일에 가감하여 년월일 출력<br>
     * 예) 2004-03-03 + 1개월 5일 --> 2004-04-08
	 * @param	int	기준 년
	 * @param	int	기준 월
	 * @param	int	기준 일
	 * @param	int	증감 월
	 * @param	int	증감 일
	 * @return	String
	 * @see		String
     */
    public static String  getChangeBoth(int year, int month,int day ,int addmonth,int addday)
    {
        GregorianCalendar cal= new GregorianCalendar();
        cal.set(year,month-1+addmonth,day+addday);
        String stryear  = String.valueOf( cal.get(Calendar.YEAR) ).toString();
        String strmonth = toLen2( cal.get(Calendar.MONTH) + 1) ;
        String strday   = toLen2( cal.get(Calendar.DATE));

        return stryear+strmonth+strday;
    }

    /**
     * String 년월일 8자리or10자리 입력해 월일에 가감하여 년월일8자리 출력
     * 예) 20040303 + 1개월 5일 --> 20040408
	 * @param	String	기준 년월일
	 * @param	int	증감 월
	 * @param	int	증감 일
	 * @return	String
	 * @see		#String
     */
    public static String  getChangeFormat(String date)
    {
        GregorianCalendar cal= new GregorianCalendar();
        String year  = "";
        String month = "";
        String day   = "";


        if (date.length() != 8 ) return date;
    
        year  = date.substring(0,4);
        month = date.substring(4,6);
        day   = date.substring(6,8);
        
        return year+"-"+month+"-"+day;
    }
    
    
    /**
     * String 년월일 8자리or10자리 입력해 월일에 가감하여 년월일8자리 출력
     * 예) 20040303 + 1개월 5일 --> 20040408
	 * @param	String	기준 년월일
	 * @param	int	증감 월
	 * @param	int	증감 일
	 * @return	String
	 * @see		#String
     */
    public static String  getChangeBoth(String date ,int addmonth,int addday)
    {
        GregorianCalendar cal= new GregorianCalendar();
        int year  = 0;
        int month = 0;
        int day   = 0;


        if (date.length() < 8 ) return "";

        int  pointDash  = date.lastIndexOf( "-" );
        int  pointSlash = date.lastIndexOf( "/" );

        if( pointDash == -1 && pointSlash == -1)
        {//20001212입력
            // 년 ,월 ,일
            year  = Integer.valueOf(date.substring(0,4)).intValue();
            month = Integer.valueOf(date.substring(4,6)).intValue();
            day   = Integer.valueOf(date.substring(6,8)).intValue();
        }
        else
        {//2000-12-12,2000/12/12입력
            // 년 ,월 ,일
            year  = Integer.valueOf(date.substring(0,4)).intValue();
            month = Integer.valueOf(date.substring(5,7)).intValue();
            day   = Integer.valueOf(date.substring(8,10)).intValue();
        }
        cal.set(year,month-1+addmonth,day+addday);

        String stryear  = String.valueOf(cal.get(Calendar.YEAR)).toString();
        String strmonth = toLen2( cal.get(Calendar.MONTH) + 1);
        String strday   = toLen2( cal.get(Calendar.DATE));

        return stryear+strmonth+strday;
    }

    /**
     * 년월일입력해 일에 가감하여 년월일 출력
     */
    public static String  getChangeDay(int year,int month, int day ,int addday)
    {
        GregorianCalendar cal= new GregorianCalendar();
        cal.set(year,month-1,day+addday);
        String stryear  = String.valueOf( cal.get(Calendar.YEAR) ).toString();
        String strmonth = toLen2( cal.get(Calendar.MONTH) + 1) ;
        String strday   = toLen2( cal.get(Calendar.DATE));

        return stryear+strmonth+strday;
    }

    /**
     * String 년월일 8자리or10자리 입력해 일에 가감하여 년월일8자리 출력
     */
    public static String  getChangeDay(String date ,int addday)
    {

        GregorianCalendar cal= new GregorianCalendar();

        int year  = 0;
        int month = 0;
        int day   = 0;

        if (date.length() < 8 ) return "";

        int  pointDash  = date.lastIndexOf( "-" );
        int  pointSlash = date.lastIndexOf( "/" );

        if( pointDash == -1 && pointSlash == -1)
        {//20001212입력
            // 년 ,월 ,일
            year  = Integer.valueOf(date.substring(0,4)).intValue();
            month = Integer.valueOf(date.substring(4,6)).intValue();
            day   = Integer.valueOf(date.substring(6,8)).intValue();
        }
        else
        {//2000-12-12,2000/12/12입력
            // 년 ,월 ,일
            year  = Integer.valueOf(date.substring(0,4)).intValue();
            month = Integer.valueOf(date.substring(5,7)).intValue();
            day   = Integer.valueOf(date.substring(8,10)).intValue();
        }

        cal.set(year,month-1,day+addday);
        String stryear  = String.valueOf(cal.get(Calendar.YEAR)).toString();
        String strmonth = toLen2( cal.get(Calendar.MONTH) + 1);
        String strday   = toLen2( cal.get(Calendar.DATE));

        return stryear+strmonth+strday;
    }

    /**
     * 년월일입력해 월에 가감하여 년월일 출력<br>
     * 월만 변경을 시켜야 할 경우 아래의 내용은 명확한 차이가 있다<br>
     * 즉 현재 날짜가 2000년 12월 30일인 경우<br>
     * getChangeMonth(getCurrDate(),2)    -> 2001년 3월 2일<br>
     * getChangeMonth(getYYYYMM()+"01",2) -> 2001년 2월 1일<br>
     */
    public static String  getChangeMonth(int year, int month,int day ,int addmonth)
    {
        GregorianCalendar cal= new GregorianCalendar();
        cal.set(year,month-1+addmonth,day);
        String stryear  = String.valueOf( cal.get(Calendar.YEAR) ).toString();
        String strmonth = toLen2( cal.get(Calendar.MONTH) + 1) ;
        String strday   = toLen2( cal.get(Calendar.DATE));

        return stryear+strmonth+strday;
    }

    /**
     * String 년월일 8자리or10자리 입력해 월에 가감하여 년월일8자리 출력
     */
    public static String  getChangeMonth(String date ,int addmonth)
    {
        GregorianCalendar cal= new GregorianCalendar();

        int year  = 0;
        int month = 0;
        int day   = 0;

        if (date.length() < 8 ) return "";

        int  pointDash  = date.lastIndexOf( "-" );
        int  pointSlash = date.lastIndexOf( "/" );

        if( pointDash == -1 && pointSlash == -1)
        {//20001212입력
            // 년 ,월 ,일
            year  = Integer.valueOf(date.substring(0,4)).intValue();
            month = Integer.valueOf(date.substring(4,6)).intValue();
            day   = Integer.valueOf(date.substring(6,8)).intValue();

        }
        else
        {//2000-12-12,2000/12/12입력
            // 년 ,월 ,일
            year  = Integer.valueOf(date.substring(0,4)).intValue();
            month = Integer.valueOf(date.substring(5,7)).intValue();
            day   = Integer.valueOf(date.substring(8,10)).intValue();
        }

        cal.add(Calendar.MONTH,addmonth);

        String stryear  = String.valueOf(cal.get(Calendar.YEAR)).toString();
        String strmonth = toLen2( cal.get(Calendar.MONTH) + 1);
        String strday   = toLen2( cal.get(Calendar.DATE));

        return stryear+strmonth+strday;
    }

    /**
     * 현 일자
     * YYYYMMDD 20000427 반환
     */
    public static String getCurrDate()
    {
        GregorianCalendar cal = new GregorianCalendar();
        StringBuffer date = new StringBuffer();

        date.append(cal.get(1));
        if(cal.get(2) < 9) date.append('0');
        date.append(cal.get(2) + 1);
        if(cal.get(5) < 10) date.append('0');
        date.append(cal.get(5));

        return date.toString();
    }

    /**
     * 현 일자
     * YYYYMMDDHHmm 200004272109 반환
     */
    public static String getCurrDateTime()
    {
        GregorianCalendar cal = new GregorianCalendar();

        StringBuffer date = new StringBuffer();
        date.append(cal.get(1));
        if(cal.get(2) < 9) date.append('0');
        date.append(cal.get(2) + 1);
        if(cal.get(5) < 10) date.append('0');
        date.append(cal.get(5));
        if(cal.get(11) < 10) date.append('0');
        date.append(cal.get(11));
        if(cal.get(12) < 10) date.append('0');
        date.append(cal.get(12));

        return date.toString();
    }

    /**
     * 현재 일 반환
     */
    public static String getCurrDay() {
        GregorianCalendar cal = new GregorianCalendar();
        String day = String.valueOf(cal.get(Calendar.DATE)).toString();
        if ( day.length()==1) day="0"+day;

        return day;
    }

    /**
     * 오늘의 요일 가져오기
     */
    public static String getCurrDayOfWeek()
    {
        GregorianCalendar cal = new GregorianCalendar();
        int    day  = cal.get(Calendar.DAY_OF_WEEK);
        String days = "";

        if ( day==1)       days = "일";
        else if ( day==2)  days = "월";
        else if ( day==3)  days = "화";
        else if ( day==4)  days = "수";
        else if ( day==5)  days = "목";
        else if ( day==6)  days = "금";
        else if ( day==7)  days = "토";

        return days;
    }

    /**
     * 현재 월가져오기
     */
    public static String getCurrMonth()
    {
        GregorianCalendar cal = new GregorianCalendar();
        String month = String.valueOf(cal.get(Calendar.MONTH) + 1);
        if ( month.length()==1) month="0"+month;

        return month;

    }

    /**
     * 현재 시:분:초 가져오기
     */
    public static String getCurrTime()
    {
        GregorianCalendar cal = new GregorianCalendar();
        int hour =  cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        int sec = cal.get(Calendar.SECOND);
        String time =  String.valueOf( toLen2(hour) ) + ":" + String.valueOf(toLen2(minute)) + ":" + String.valueOf(toLen2(sec))+"";

        return time;

    }

    /**
     * 현재 시:분 가져오기
     */
    public static String getCurrTimeNoSec()
    {
             GregorianCalendar cal = new GregorianCalendar();
             int hour =  cal.get(Calendar.HOUR_OF_DAY);
             int minute = cal.get(Calendar.MINUTE);
             int sec = cal.get(Calendar.SECOND);
             String time =  String.valueOf( toLen2(hour) ) + ":" + String.valueOf(toLen2(minute)) ;
             return time;

    }

    /**
     * 현재 년도 반환 가져오기
     */
    public static String getCurrYear()
    {
        GregorianCalendar cal = new GregorianCalendar();
        String year = String.valueOf(cal.get(Calendar.YEAR));
        return year;
    }

    /**
     * YYYYMMDDHHmmss 20000427210948 반환
     */
    public static String getDateTimeSec()
    {
        GregorianCalendar cal = new GregorianCalendar();
        StringBuffer date = new StringBuffer();
        //년
        date.append(cal.get(1));
        //월
        if(cal.get(2) < 9) date.append('0');
        date.append(cal.get(2) + 1);
        //일
        if(cal.get(5) < 10) date.append('0');
        date.append(cal.get(5));
        //시
        if(cal.get(11) < 10) date.append('0');
        date.append(cal.get(11));
        //분
        if(cal.get(12) < 10) date.append('0');
        date.append(cal.get(12));
        //초
        if(cal.get(13) < 10) date.append('0');
        date.append(cal.get(13));

        return date.toString();
    }
    
    public static String getDateTimeSec(int ss)
    {
        GregorianCalendar cal = new GregorianCalendar();
        StringBuffer date = new StringBuffer();
        //년
        date.append(cal.get(1));
        //월
        if(cal.get(2) < 9) date.append('0');
        date.append(cal.get(2) + 1);
        //일
        if(cal.get(5) < 10) date.append('0');
        date.append(cal.get(5));
        //시
        if(cal.get(11) < 10) date.append('0');
        date.append(cal.get(11));
        //분
        if(cal.get(12) < 10) date.append('0');
        date.append(cal.get(12));
        //초
        if(cal.get(13) < 10) date.append('0');
        date.append(cal.get(13)+ss);

        return date.toString();
    }

    /**
     * 현재년월의 마지막날인 yyyymmdd반환
     */
    public static String getEndDate()
    {
        int year  = Integer.valueOf(getCurrYear()).intValue();
        int month = Integer.valueOf(getCurrMonth()).intValue();
        return toLen(year,4)+toLen2(month)+getEndOfMonthDay(year,month);
    }

    /**
     * 년월의 마지막날인 yyyymmdd반환
     */
    public static String getEndDate(int year,int month)
    {
        return toLen(year,4) + toLen2(month) + toLen2(getEndOfMonthDay(year,month));
    }

    /**
     * 년월의 마지막날인 yyyymmdd반환
     */
    public static String getEndDate(String date)
    {
        int year  = Integer.valueOf(date.substring(0,4)).intValue();
        int month = Integer.valueOf(date.substring(4,6)).intValue();

        return toLen(year,4) + toLen2(month) + toLen2(getEndOfMonthDay(year,month));
    }

    /**
     * 년월의 마지막날 구하기
     */
    public static int getEndOfMonthDay(int year,int month)
    {
        if (String.valueOf(year).length() != 4  || String.valueOf(month).length() < 1 || String.valueOf(month).length() > 2)  return 0;

        int daysList[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        if(month == 2)
        {
            if(((year%4 == 0)&&(year%100 != 0))||(year%400 == 0))
            {
                return(29);
            }
        }
        return  (daysList[month-1]);
    }

    /**
     * 년월의 마지막날 구하기
     */
    public static int getEndOfMonthDay(String date)
    {
        int year  = Integer.valueOf(date.substring(0,4)).intValue();
        int month = Integer.valueOf(date.substring(4,6)).intValue();

        if (String.valueOf(year).length() != 4  || String.valueOf(month).length() < 1 || String.valueOf(month).length() > 2)  return 0;

        int daysList[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        if(month == 2)
        {
            if(((year%4 == 0)&&(year%100 != 0))||(year%400 == 0))
            {
                return(29);
            }
        }
        return  (daysList[month-1]);
    }

    /**
     * 2000년04월22일 12:13:23반환
     */
    public static String getFormatCurrDateTime()
    {
        GregorianCalendar cal = new GregorianCalendar();
        int year   = cal.get(Calendar.YEAR);
        int month  = cal.get(Calendar.MONTH) + 1;
        int day    = cal.get(Calendar.DATE);
        int hour   =  cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        int sec    = cal.get(Calendar.SECOND);
        StringBuffer date = new StringBuffer();
        date.append(year);
        date.append("년");
        date.append(toLen2(month));
        date.append("월");
        date.append(toLen2(day));
        date.append("일");
        date.append(" ");
        date.append(toLen2(hour));
        date.append(":");
        date.append(toLen2(minute));
        date.append(":");
        date.append(toLen2(sec));

        return date.toString();

    }

    /**
     * 2000년04월22일 12:13:23반환<br>
     * 현재시간을 원하는 형식으로<br>
     * format "YYYYMMDD hh:mm:ss<br>
     * format "YYYYMMDDhhmmssms<br>
     * format "YYYY년 MM월 DD일 hh-mm-ss 등등<br>
     * format YYYY<br>
     * format mm<br>
     * format mm.dd<br>
     */
    public static String getFormatCurrDateTime(String format)
    {
        GregorianCalendar cal = new GregorianCalendar();
        int year   = cal.get(Calendar.YEAR);
        int month  = cal.get(Calendar.MONTH) + 1;
        int day    = cal.get(Calendar.DATE);
        int hour   =  cal.get(Calendar.HOUR_OF_DAY);
        int minute = cal.get(Calendar.MINUTE);
        int sec    = cal.get(Calendar.SECOND);
        int msec    = cal.get(Calendar.MILLISECOND);


        format = replaceStringAll( format, "YYYY",toLen( year,4) );
        //format = replaceString( format, "YY", yy );
        format = replaceStringAll( format, "MM", toLen2(month) );
        format = replaceStringAll( format, "DD", toLen2(day) );
        format = replaceStringAll( format, "hh", toLen2(hour) );
        format = replaceStringAll( format, "mm", toLen2(minute) );
        format = replaceStringAll( format, "ss", toLen2(sec) );
        format = replaceStringAll( format, "ms", toLen2(msec) );
        return format.toString();

    }

    /**
     * 년월일을 원하는 형식으로
     */
    public static String getFormatDate(String date,String flag)
    {
        String result = "";
        if (date == null ) return date; //|| (date.length() != 8 && date.length() != 6)
        
        if (flag.toUpperCase().equals("ENG") && date.length()==4)
        {
            
            result =  date.substring(2,4) + viewEngMonth2(date.substring(0,2)) ;
            
        }else{
        
	        if(!date.equals(""))
	        {
	            StringBuffer newDate = new StringBuffer(date);
	            if (date.length()==8)
	            {
	                if (flag.toUpperCase().equals("KOR"))
	                {
	                    newDate.insert(8, "일");
	                    newDate.insert(6, "월");
	                    newDate.insert(4, "년");
	                }else{
	                    newDate.insert(6, flag);
	                    newDate.insert(4, flag);
	                }
	
	            }else if (date.length()==6)
	            {
	                if (flag.toUpperCase().equals("KOR"))
	                {
	                    newDate.insert(6, "월");
	                    newDate.insert(4, "년");
	                }else{
	                    newDate.insert(4, flag);
	                }
	            }
	            else if (date.length()==4)
	            {
	                if (flag.toUpperCase().equals("KOR"))
	                {
	                    newDate.insert(4, "일");
	                    newDate.insert(2, "월");
	                }else{
	                    newDate.insert(2, flag);
	                }
	            }
	            else if (date.length()==10 )
	            {
	                newDate= new StringBuffer( date );
	            }
	            else
	            {
	                //newDate= new StringBuffer( getCurrDate() );
	                newDate= new StringBuffer( date );
	            }
	
	            result = newDate.toString();
	        }
        }
        return result;
    }
    
    
    /**
     * 년월일을 원하는 형식으로
     */
    public static String getFormatDateEng(String date,String flag)
    {
        String result = "";
        if (date == null ) return date; //|| (date.length() != 8 && date.length() != 6)
        if(!date.equals(""))
        {
            StringBuffer newDate = new StringBuffer(date);
            if (date.length()==4)
            {
                
                result =  viewEngMonth2(date.substring(0,4)) + date.substring(2,4);
                
            }
            
            result = date;
        }
        return result;
    }

    /**
     * 년월일 8자리or10자리 입력받아 그 차를 일로 표시<br>
     * 년월일 8자리또는 6자리씩을 입력받아 그 월의 차를  표시<br>
     * 통상적으로 199903에서 199904의 차는  1개월이지만 여기서는 2개월로<br>
     * 년월일 8자리또는 6자리씩을 입력받아 그 월의 차를  표시<br>
     */
    public static int getSubtractMonth(String from_date,String toxx_date)
    throws IOException
    {
        // 뿌려질 결과의 컬럼개수
        int diff_month =   0 ;

        int END_MONTH           = 12 ;
        int start_mon_of_from_date    =  0;//시작년월의 시작월
        int start_mon_of_toxx_date    =  0;//끝년월의   시작월

        int loop_of_from_date    = 0;//시작년월의  loop 수
        int loop_of_toxx_date    = 0;//끝년월의    loop 수
        int loop_of_year         = 0;
        //시작 년월의 시작년
        int year_of_from_date = Integer.valueOf( from_date.substring(0,4)).intValue();
        //끝 년월의 끝년
        int year_of_toxx_date = Integer.valueOf( toxx_date.substring(0,4) ).intValue();

        int  pointDash  = 0;
        int  pointSlash = 0;

        if ( year_of_from_date == year_of_toxx_date )
        {//시작 년과 끝 년이 같을때
            pointDash  = from_date.lastIndexOf( "-" );
            pointSlash = from_date.lastIndexOf( "/" );

            if( pointDash == -1 && pointSlash == -1)
            {
                start_mon_of_from_date    =  Integer.valueOf(from_date.substring(4,6) ).intValue();
                start_mon_of_toxx_date    =  Integer.valueOf(toxx_date.substring(4,6) ).intValue();
            }
            else
            {
                start_mon_of_from_date    =  Integer.valueOf(from_date.substring(5,7) ).intValue();
                start_mon_of_toxx_date    =  Integer.valueOf(toxx_date.substring(5,7) ).intValue();
            }
            //
            loop_of_from_date    = start_mon_of_toxx_date;
            loop_of_toxx_date    = 0;

            // 컬럼에 개수 = toxx_date 와 from_date 컬럼 격차 +1
            if (start_mon_of_toxx_date >= start_mon_of_from_date)
                diff_month = ( start_mon_of_toxx_date - start_mon_of_from_date +1) ;
            else
                diff_month = -( start_mon_of_from_date - start_mon_of_toxx_date +1) ;

        }
        else if( year_of_from_date < year_of_toxx_date )
        {
            pointDash  = from_date.lastIndexOf( "-" );
            pointSlash = from_date.lastIndexOf( "/" );

            if( pointDash == -1 && pointSlash == -1)
            {
                //시작달
                start_mon_of_from_date    =  Integer.valueOf(from_date.substring(4,6) ).intValue();
            }
            else
            {
                start_mon_of_from_date    =  Integer.valueOf(from_date.substring(5,7) ).intValue();
            }
            start_mon_of_toxx_date    =  1;

            //
            loop_of_from_date    = END_MONTH ;

            pointDash  = toxx_date.lastIndexOf( "-" );
            pointSlash = toxx_date.lastIndexOf( "/" );

            if( pointDash == -1 && pointSlash == -1)
            {
                loop_of_toxx_date    = Integer.valueOf(toxx_date.substring(4,6) ).intValue();
            }
            else
            {
                loop_of_toxx_date    = Integer.valueOf(toxx_date.substring(5,7) ).intValue();
            }
            loop_of_year         = year_of_toxx_date - year_of_from_date-1;

            diff_month = ( loop_of_from_date - start_mon_of_from_date +1) +( loop_of_year * END_MONTH )+ (loop_of_toxx_date - start_mon_of_toxx_date+1);
        }
        else if( year_of_from_date > year_of_toxx_date )
        {
            pointDash  = from_date.lastIndexOf( "-" );
            pointSlash = from_date.lastIndexOf( "/" );

            if( pointDash == -1 && pointSlash == -1)
            {
                //시작달
                start_mon_of_from_date    =  Integer.valueOf(toxx_date.substring(4,6) ).intValue();
                start_mon_of_toxx_date    =  1;

                //
                loop_of_from_date    = END_MONTH ;
                loop_of_toxx_date    = Integer.valueOf(from_date.substring(4,6) ).intValue();
            }
            else
            {
                //시작달
                start_mon_of_from_date    =  Integer.valueOf(toxx_date.substring(5,7) ).intValue();
                start_mon_of_toxx_date    =  1;
                //
                loop_of_from_date    = END_MONTH ;
                loop_of_toxx_date    = Integer.valueOf(from_date.substring(5,7) ).intValue();

            }
            loop_of_year         = year_of_from_date - year_of_toxx_date -1 ;

            diff_month = ( loop_of_from_date - start_mon_of_from_date + 1) +( loop_of_year * END_MONTH )+ (loop_of_toxx_date - start_mon_of_toxx_date+1);
            diff_month = -diff_month;
        }
        return diff_month;
    }

    /**
     * 사용 주의 사항 년/월/일 미리 체크 요망<br>
     * 입력한날의 요일 가져오기<br>
     */
    public static String getWantDayOfWeek(int yyyy,int mm, int dd)
    {
        GregorianCalendar calendar= new GregorianCalendar();
        String days="";

        int day=0;
        calendar.set( yyyy,mm-1,dd);
        day=calendar.get(calendar.DAY_OF_WEEK);

        if ( day==1)       days = "일";
        else if ( day==2)  days = "월";
        else if ( day==3)  days = "화";
        else if ( day==4)  days = "수";
        else if ( day==5)  days = "목";
        else if ( day==6)  days = "금";
        else if ( day==7)  days = "토";

        return days;

	}

    /**
     * 사용 주의 사항 년/월/일 미리 체크 요망<br>
     * 입력한날의 요일 가져오기<br>
     */
    public static String getWantDayOfWeek2( String sdate)
    {
        GregorianCalendar calendar= new GregorianCalendar();
        String days="";

        sdate = replaceStringAll(sdate, "-","");
        sdate = replaceStringAll(sdate, "/","");
        sdate = replaceStringAll(sdate, ".","");
        sdate = replaceStringAll(sdate, " ","");

        //입력받은 날의 요일 반환
        int yyyy  = Integer.valueOf(sdate.substring(0,4)).intValue();
        int mm    = Integer.valueOf(sdate.substring(4,6)).intValue();
        int dd    = Integer.valueOf(sdate.substring(6,8)).intValue();

        int day=0;
        calendar.set( yyyy,mm-1,dd);
        day=calendar.get(calendar.DAY_OF_WEEK);

        if ( day==1)       days = "일";
        else if ( day==2)  days = "월";
        else if ( day==3)  days = "화";
        else if ( day==4)  days = "수";
        else if ( day==5)  days = "목";
        else if ( day==6)  days = "금";
        else if ( day==7)  days = "토";

        return days;
	}

    /**
     * 200003반환
     */
    public static String getYYYYMM()
    {
        GregorianCalendar cal = new GregorianCalendar();
        StringBuffer date = new StringBuffer();

        date.append(cal.get(1));
        if(cal.get(2) < 9) date.append('0');
        date.append(cal.get(2) + 1);

        return date.toString();

    }

    /**
     * 그 주의 월요일부터 일요일을 제외하고 3일씩 끊어 Format대로 반환
     */
    public static String  getHalfOfWeek( String date ,int destday, String format )
    {

        //입력받은 날의 요일 반환
        int year  = Integer.valueOf(date.substring(0,4)).intValue();
        int month = Integer.valueOf(date.substring(4,6)).intValue();
        int day   = Integer.valueOf(date.substring(6,8)).intValue();

        format = getHalfOfWeek( year,month,day,destday,format);

        return format;
    }

    /**
     * 그 주의 월요일부터 일요일을 제외하고 3일씩 끊어 Format대로 반환
     */
    public static String  getHalfOfWeek( int year,int month,int day  ,int destday, String format )
    {

        GregorianCalendar calendar= new GregorianCalendar();

        calendar.set( year,month-1,day);

        //(1-일,2-월,...7-토)
        int dayofweek = calendar.get(calendar.DAY_OF_WEEK);


        //그주의 월요일을 받아오기
        GregorianCalendar cal= new GregorianCalendar();
        cal.set(year,month-1, day - dayofweek + destday + 1);

        String stryear  = String.valueOf(cal.get(Calendar.YEAR)).toString();
        String strmonth = toLen2( cal.get(Calendar.MONTH) + 1);
        String strday   = toLen2( cal.get(Calendar.DATE));

        format = replaceStringAll( format, "YYYY", stryear );
        //format = replaceString( format, "YY", yy );
        format = replaceStringAll( format, "MM", strmonth );
        format = replaceStringAll( format, "DD", strday );

        return format;
    }

    /**
     * 현재 날짜에서 월을 더해 Format대로 반환
     */
    public static String  getNextMonth( String date ,int destmonth, String format )
    {
        //var arg  = getUserDate1( oneday )
        //arg - date형식
        int year  = Integer.valueOf(date.substring(0,4)).intValue();
        int month = Integer.valueOf(date.substring(4,6)).intValue();
        int day   = Integer.valueOf(date.substring(6,8)).intValue();

        format = getNextMonth( year,month, day , destmonth,  format );
        return format;
    }

    /**
     * 현재 날짜에서 월을 더해 Format대로 반환
     */
    public static String  getNextMonth( int year,int month,int day ,int destmonth, String format )
    {

        GregorianCalendar cal= new GregorianCalendar();
        cal.set(year,month-1+destmonth,day );

        String stryear  = String.valueOf(cal.get(Calendar.YEAR)).toString();
        String strmonth = toLen2( cal.get(Calendar.MONTH) + 1);
        String strday   = toLen2( cal.get(Calendar.DATE));


        format = replaceStringAll( format, "YYYY", stryear );
        //format = replaceString( format, "YY", yy );
        format = replaceStringAll( format, "MM", strmonth );
        format = replaceStringAll( format, "DD", strday );

        return format;
    }

    //==================================================================================
    // 파일 관련 함수
    //==================================================================================

    /**
     * nareadme.htm입력받아 20000614090248_nareadme.htm반환
     */
    public static String makeFileName(String srcfile)
    {
        StringBuffer filename = new StringBuffer();
        GregorianCalendar cal = new GregorianCalendar();
        //년
        filename.append(cal.get(1));
        //월
        if(cal.get(2) < 9) filename.append('0');
        filename.append(cal.get(2) + 1);
        //일
        if(cal.get(5) < 10) filename.append('0');
        filename.append(cal.get(5));
        //시
        if(cal.get(11) < 10) filename.append('0');
        filename.append(cal.get(11));
        //분
        if(cal.get(12) < 10) filename.append('0');
        filename.append(cal.get(12));
        //초
        if(cal.get(13) < 10) filename.append('0');
        filename.append(cal.get(13));
        filename.append('_');

        // 파일이름중 공백에 _로
        srcfile= replaceStringAll(  srcfile, " ", "_" );

        if(srcfile.lastIndexOf("\\") == -1)
            filename.append(srcfile);
        else
            filename.append(srcfile.substring(srcfile.lastIndexOf("\\") + 1));
        try
        {
            return filename.toString();
        }
        catch(Exception e)
        {
            return srcfile+":"+e.getMessage();

        }
        //return null;
    }

    /**
     * file만들고 output스트림 만들기
     */
    public static PrintWriter openLog(String filename)
    {
        try
        {
            return new PrintWriter( new BufferedWriter(new FileWriter(filename)));
        }
        catch (IOException ie)
        {
            return null;
        }
        catch (Exception e)
        {
            return null;
        }
    }

    /**
     * file만들고 output스트림 만들기<br>
     * appent가  true시 덧 붙이기 ,false시  덮어쓰기
     */
    public static PrintWriter openLog(String path,String fileName,boolean append)
    {
        String path_file =  "";
        if ( path.endsWith( System.getProperty("file.separator") ))
            path_file = path+fileName;
        else
            path_file = path+System.getProperty("file.separator")+fileName;

        try
        {
            return new PrintWriter(
                                   new BufferedWriter(
                                                       new FileWriter( path_file,append)
                                                     )
                                   );
        }
        catch (IOException ie)
        {
            return null;
        }
        catch (Exception e)
        {
            return null;
        }
    }

    /**
     * file upload시 사용
     */
    public static Hashtable parseMulti(String boundary, ServletInputStream in)
    throws IOException
    {
        int buffSize = 8192*4;

        Hashtable hash = new Hashtable();
        String boundaryStr = "--" + boundary;
        byte b[] = new byte[buffSize];
        int result = in.readLine(b, 0, b.length);
        if(result == -1)
                        throw new IllegalArgumentException("InputStream truncated");
        String line = new String(b, 0, result);
        if(!line.startsWith(boundaryStr))
                        throw new IllegalArgumentException("MIME boundary missing: " + line);

        do
        {
            String lowerline;
            ByteArrayOutputStream content;
            String filename;
            String contentType;
            String name;

            long   filelen=0l;
            do
            {
                filename = null;
                contentType = null;
                content = new ByteArrayOutputStream();
                name = null;
                result = in.readLine(b, 0, b.length);
                if(result == -1)
                {
                    return hash;
                }
                line = new String(b, 0, result - 2);
                lowerline = line.toLowerCase();
            }while(!lowerline.startsWith("content-disposition"));

            int ind = lowerline.indexOf("content-disposition: ");
            int ind2 = lowerline.indexOf(";");
            if(ind == -1 || ind2 == -1)
                    throw new IllegalArgumentException("Content Disposition line misformatted: " + line);
            String disposition = lowerline.substring(ind + 21, ind2);
            if(!disposition.equals("form-data"))
                    throw new IllegalArgumentException("Content Disposition of " + disposition + " is not supported");
            int ind3 = lowerline.indexOf("name=\"", ind2);
            int ind4 = lowerline.indexOf("\"", ind3 + 7);
            if(ind3 == -1 || ind4 == -1)
                    throw new IllegalArgumentException("Content Disposition line misformatted: " + line);
            name = line.substring(ind3 + 6, ind4);
            int ind5 = lowerline.indexOf("filename=\"", ind4 + 2);
            int ind6 = lowerline.indexOf("\"", ind5 + 10);
            if(ind5 != -1 && ind6 != -1)
                    filename = line.substring(ind5 + 10, ind6);
            result = in.readLine(b, 0, b.length);
            if(result == -1)
            {
                return hash;
            }
            line = new String(b, 0, result - 2);
            lowerline = line.toLowerCase();
            if(lowerline.startsWith("content-type"))
            {
                int ind7 = lowerline.indexOf(" ");
                if(ind7 == -1)
                        throw new IllegalArgumentException("Content-Type line misformatted: " + line);
                contentType = lowerline.substring(ind7 + 1);
                result = in.readLine(b, 0, b.length);
                if(result == -1) return hash;

                line = new String(b, 0, result - 2);
                if(line.length() != 0)
                        throw new IllegalArgumentException("Unexpected line in MIMEpart header: " + line);
            } else
                if(line.length() != 0)
                        throw new IllegalArgumentException("Misformatted line following disposition: " + line);
                boolean readingContent = true;
                boolean firstLine = true;
                byte buffbytes[] = new byte[buffSize];
                int buffnum = 0;
                result = in.readLine(b, 0, b.length);
                if(result == -1) return hash;

                line = new String(b, 0, result);
                if(!line.startsWith(boundaryStr))
                {
                    System.arraycopy(b, 0, buffbytes, 0, result);
                    buffnum = result;
                    result = in.readLine(b, 0, b.length);
                    if(result == -1) return hash;

                    line = new String(b, 0, result);
                    firstLine = false;
                    if(line.startsWith(boundaryStr)) readingContent = false;
                } else {
                    readingContent = false;
                }

                while(readingContent)
                {
                    content.write(buffbytes, 0, buffnum);
                    System.arraycopy(b, 0, buffbytes, 0, result);
                    buffnum = result;
                    result = in.readLine(b, 0, b.length);

                    filelen+=result;
                    if(result == -1) return hash;
                    line = new String(b, 0, result);
                    if(line.startsWith(boundaryStr)) readingContent = false;
                }

                if(!firstLine && buffnum > 2)   content.write(buffbytes, 0, buffnum - 2);
                if(filename == null)
                {// file태그가 아닐때
                    if(hash.get(name) == null)
                    {
                        String values[] = new String[1];
                        values[0] = content.toString();
                        hash.put(name, values);
                    } else {
                        Object prevobj = hash.get(name);
                        if(prevobj instanceof String[])
                        {
                            String prev[] = (String[])prevobj;
                            String newStr[] = new String[prev.length + 1];
                            System.arraycopy(prev, 0, newStr, 0, prev.length);
                            newStr[prev.length] = content.toString();
                            hash.put(name, newStr);
                        } else
                        {
                            throw new IllegalArgumentException("failure in parseMulti hashtable building code");
                        }
                    }
                }
                else
                {// file태그일때
                    if(hash.get(name) == null)
                    {//hash에 없다면
                        Hashtable filehash = new Hashtable(5);
                        filehash.put("name", name);
                        filehash.put("filename", filename);
                        if(contentType == null) contentType = "application/octet-stream";
                        filehash.put("content-type", contentType);
                        filehash.put("content", content.toByteArray());
                        filehash.put("filesize", String.valueOf(filelen));

                        Hashtable values[] = new Hashtable[1];
                        values[0] =  filehash;
                        hash.put(name, values);
                    }
                    else
                    {//hash에 이미 있다면
                        Object prevobj = hash.get(name);
                        if(prevobj instanceof Hashtable[])
                        {
                            Hashtable prev[] = (Hashtable[])prevobj;
                            Hashtable newStr[] = new Hashtable[prev.length + 1];
                            System.arraycopy(prev, 0, newStr, 0, prev.length);

                            Hashtable filehash = new Hashtable(5);
                            filehash.put("name", name);
                            filehash.put("filename", filename);
                            if(contentType == null) contentType = "application/octet-stream";
                            filehash.put("content-type", contentType);
                            filehash.put("content", content.toByteArray());
                            filehash.put("filesize", String.valueOf(filelen));

                            newStr[prev.length] = filehash;
                            hash.put(name, newStr);


                        } else {
                            throw new IllegalArgumentException("failure in parseMulti hashtable building code");
                        }
                    }
                }//file태그인지 아닌지일때
        }while(true);
    }

    /**
     * file upload시 사용
     */
    public static Hashtable parseMulti(HttpServletRequest req,long maxSize)
    throws IOException
    {
        if(!req.getContentType().toLowerCase().startsWith("multipart/form-data"))
        {
            throw new IOException("Posted content type isn't multipart/form-data");
            //out.println("\uD30C\uC77C Upload\uB97C \uC704\uD55C Content-type\uC774 \uC9C0\uC815\uB418\uC9C0 \uC54A\uC558\uC2B5\uB2C8\uB2E4");
            //return null;
        }

        long length = req.getContentLength();

        if ( length > maxSize ) {
            throw new IOException("Posted content length of " + length +
                " exceeds limit of " + maxSize );
        }

        int ind = req.getContentType().indexOf("boundary=");
        if(ind == -1)
        {
            throw new IOException("Separation boundary was not specified");

            //return null;
        }
        String boundary = req.getContentType().substring(ind + 9);
        if(boundary == null)
        {
            throw new IOException("Separation boundary was not specified");
            //return null;
        }
        try
        {
            return parseMulti(boundary, req.getInputStream());
        }
        catch(Exception e)
        {
            //e.printStackTrace();
        	System.out.println("ComUtil:2738");
        }
        return null;
    }

    
    //==================================================================================
    // 데이터 체크 관련 함수
    //==================================================================================
	/**
     * 주민등록번호 검사<br>
     * 주민등록 구성 : 생년월일(6X) + 성별(1X) + 난수(5X) + 합계검사(1X)<br>
     * 합계검사 = 앞 12자리의 (각 숫자 * 알파)를 합계한 수를 11로 나눈 나머지를 구한 후,<br>
     * 11에서 이 나머지를 뺀 수인 데, 1자리로 만들기 위해<br>
     * 여기서 한번더 10으로 나눈 나머지를 구한다.<br>
	 * @param	val (String) 검사 대상 문자열
	 * @return	boolean
	 * @see
     */
    public static boolean isResidentNo( String val ) {
        if (val.length() != 13) // 자릿수 검사
            return false;

        else if (isNumber(val) == false) // 숫자형 검사
            return false;

        else if (isDate(val.substring(0,6), "yyMMdd") == false) // 생년월일 검사
            return false;

        else if ("1234".indexOf(val.substring(6,7)) < 0) // 성별검사
            return false;

        else { // 합계검사(CheckSum)
            int iSum = 0;
            int iAlpas[] = {2,3,4,5,6,7,8,9, 2,3,4,5};  // 배열 초기화

            for (int i = 0; i < 12; i++)                                // 첫자리부터 12번째 자리까지
                iSum = iSum + str2int(val.substring(i,i+1)) * iAlpas[i];

            int iRemain = (int) remain2long((long)iSum , 11); // 11로 나눈 나머지
            int iCheck = 11 - iRemain; // 11과 나머지의 차이

            if (iCheck >= 10) iCheck = iCheck - 10; // 나머지 끝 1자리

            if (str2int(val.substring(12, 13)) == iCheck)
                return true;
            else
                return false;
        }
    }

	/**
     * 우편번호 검사
	 * @param	val (String) 검사 대상 문자열
	 * @return	숫자형 검사와 자릿수 검사(6자리) true
	 * @see
     */
    public static boolean isZipCode( String val ) {
        if (val.length()!= 6) // 자릿수 검사
            return false;
        else if (isNumber(val) == false) // 숫자형 검사
            return false;
        else
            return true;
    }
    public static String checkVal( String val, boolean nullable ) {
        return checkVal(val, nullable, null, null, null, null, null);
    }
    public static String checkVal( String val, boolean nullable, String type ) {
        return checkVal(val, nullable, type, null, null, null, null);
    }
    public static String checkVal( String val, boolean nullable, String type, String minLen ) {
        return checkVal(val, nullable, type, minLen, null, null, null);
    }
    public static String checkVal( String val, boolean nullable, String type, String minLen, String maxLen ) {
        return checkVal(val, nullable, type, minLen, maxLen, null, null);
    }
    public static String checkVal( String val, boolean nullable, String type, String minLen, String maxLen, String minVal ) {
        return checkVal(val, nullable, type, minLen, maxLen, minVal, null);
    }
    public static String checkVal( String val, boolean nullable, String type, String minLen, String maxLen, String minVal, String maxVal )
    {
        String sRet = "";

        // 널 검사
        if (isNull(val) == true){	//val이 null일때
            if (nullable == true)	// nullable(널허용) : 널 값은 더 이상 검사하지 않는다.
                return "";
            else
                return MSG_ERR_NULL_TYPE;
        }
/*
        if (isSpecialChar(val)==false) {
            return "사용할수 없는 특수문자가 존재합니다.";
        }
*/
        // 타입 검사
        if (isNull(type) == false) {
            sRet = checkType(val, type, "");

            if (isNull(sRet) == false)
                return sRet;
        }

        // 길이 범위 검사
        if ((isNull(maxLen) == false) || (isNull(minLen) == false)) {
            sRet = checkLen(val, type, maxLen, minLen);

            if (isNull(sRet) == false)
                return sRet;
        }

        // 값 범위 검사
        if ((isNull(maxVal) == false) || (isNull(minVal) == false)) {
            sRet = checkRange(val, type, "", maxVal, minVal);

            if (isNull(sRet) == false)
                return sRet;
        }
        return sRet;
    }

	/**
     * Null Check
     */
    public static String checkNull(String val,			// 검사하고자 하는 값
							boolean nullable	// 널가능
							)
    {
        String sRet = "";

        if (nullable == false)
            if (isNull(val) == true)
                sRet = MSG_ERR_NULL_TYPE;

        return sRet;
    }

	/**
     * 특수문자 존재여부 검사
     */
    public static boolean isSpecialChar(String sValue) {
        String  sRet    = "\"'";
        int     iLength = 0;
        int     i       = 0;
        char    cCheck;

        sValue = trim(sValue);

        for (i=0; i< sValue.length(); i++) {
            cCheck = sValue.charAt(i);

            if (sRet.indexOf(cCheck,0) != -1){
                return false;
            }
        }
        return true;
    }

	/**
     * 타입 검사
     * Number Type 	: TAG_NUM
     * Int Type		: TAG_INT
     * Date Type	: TAG_DATE
     */
    public static String checkType(String val,		// 검사하고자 하는 값
							String type,	// 데이터타입
							String format	// 형식
							)
    {
        String sRet = "";

        if (type.equals(TAG_NUM)) {
            if (isNumber(val) == false)
                sRet = MSG_ERR_NUM_TYPE;
        }
        else if (type.equals(TAG_INT)) {
            if (isInteger(val) == false)
                sRet = MSG_ERR_INT_TYPE;
        }
        else if (type.equals(TAG_DATE)) {
            format = null2str(format,FMT_DATE);
            if (isDate(val, format) == false){
                sRet = MSG_ERR_DATE_TYPE;
                sRet = sRet + " \\n형식 " + format ;
            }
        }
        return sRet;
    }

    /**
     * 길이 범위 검사
     */
    public static String checkLen(	String val,             // 검사하고자 하는 값
							String type,        	// 데이터타입
							String maxLen,          // 최대길이
							String minLen           // 최소길이
						   )
    {
        String sRet = "";

        if (type.equals(TAG_INT) || type.equals(TAG_NUM)) // 정수형, 소수형
            sRet = checkLenNum(val, maxLen, minLen);
        else // 문자형, 날짜형
            sRet = checkLenText(val, maxLen, minLen);

        return sRet;
    }

	/**
     * 문자형, 날짜형 길이 범위 검사
     */
    public static String checkLenText(	String val,             // 검사하고자 하는 값
								String maxLen,          // 최대길이
								String minLen           // 최소길이
							  )
    {
        String sRet = "";

        if (isNull(maxLen)) maxLen = "9999";
        if (isNull(minLen)) minLen = "0";

        //int iMaxLen = (new Integer(maxLen)).intValue();
        //int iMinLen = (new Integer(minLen)).intValue();
        int iMaxLen = (new Double(maxLen)).intValue();
        int iMinLen = (new Double(minLen)).intValue();
        //int iLen = val.length(); // 유니코드 문자열 바이트수
        int iLen = strLen(val); // 한글 문자열 바이트수

        if (iLen > iMaxLen){
            sRet = MSG_ERR_LEN_LONG;
            sRet = sRet + "\\n최대 허용 길이 " + iMaxLen;
        }
        else if (iLen < iMinLen){
            sRet = MSG_ERR_LEN_SHORT;
            sRet = sRet + "\\n최소 허용 길이 " + iMinLen;
        }

        return sRet;
    }


    /**
     * 숫자형 길이 범위 검사
     */
    public static String checkLenNum(	String val,             // 검사하고자 하는 값
								String maxLen,          // 최대길이
								String minLen           // 최소길이
							  )
    {
        String sRet = "";

        if (isNull(maxLen)) maxLen = "9999";
        if (isNull(minLen)) minLen = "0";

        Float myMaxLen = new Float(maxLen);
        float nMaxLen = myMaxLen.floatValue();
        int iMaxLenInt = myMaxLen.intValue();

         // 소수부 길이 4.1 * 10 - 4 * 10 = 1
        int iMaxLenFraction = (int) (nMaxLen * 10 - iMaxLenInt * 10);
         // 정수부 길이 = 전체 길이 - 소수부 길이
        iMaxLenInt = iMaxLenInt - iMaxLenFraction;
        if (iMaxLenInt < 0 ) iMaxLenInt = 0;

        Float myMinLen = new Float(minLen);
        float nMinLen = myMinLen.floatValue();
        int iMinLenInt = myMinLen.intValue();

        int iMinLenFraction = (int) (nMinLen * 10 - iMinLenInt * 10);
        iMinLenInt = iMinLenInt - iMinLenFraction;
        if (iMinLenInt < 0 ) iMinLenInt = 0;
/*
        Double myDouble = (new Double(val));
        double nVal = myDouble.doubleValue();
        if (nVal < 0 ) nVal = nVal * -1;

        String sVal = String.valueOf(nVal); // 8자리 이상부터는 검사안 됨. 수정요망... (ysj)******************
*/
        String sVal = val; // 수정함... 2000-09-20 ysj

        int iLen = sVal.length(); // ysj 06-06

        String sValInt = "";
        String sValFraction = "";
        int iPos = 0;

        iPos = sVal.indexOf(".", 0); // 소숫점 위치
        if (iPos < 0 ) {
            sValInt = sVal;
            //sValFraction = ""; // new Float(sValFraction)).floatValue() 에서 NumberFormatException Error 발생
            sValFraction = "0"; // 2000-10-01 수정 ysj
        }
        else {
            sValInt = sVal.substring(0, iPos);
            sValFraction = sVal.substring(iPos+1, iLen);
        }

        if ((new Float(sValFraction)).floatValue() == 0)
            sValFraction="";


        int iLenInt = sValInt.length();
        if (iLenInt > 20){
            //sRet = " 정수부분 길이가 너무 깁니다.";
            sRet = MSG_ERR_LEN_LONG;
            sRet = sRet + "\\n최대 허용 정수부 길이 " + iMaxLenInt;
            return sRet;
        }
        if ((new Long(sValInt)).longValue() < 0) iLenInt = iLenInt - 1; // 음수 부호 감안 (2000-09-20 ysj)

        int iLenFraction = sValFraction.length();

        if (iLenInt > iMaxLenInt){
            //sRet = " 정수부분 길이가 너무 깁니다.";
            sRet = MSG_ERR_LEN_LONG;
            sRet = sRet + "\\n최대 허용 정수부 길이 " + iMaxLenInt;
        }
        else if (iLenFraction > iMaxLenFraction){
            //sRet = " 소수부분 길이가 너무 깁니다.";
            sRet = MSG_ERR_LEN_LONG;
            sRet = sRet + "\\n최대 허용 소수부 길이 " + iMaxLenFraction ;
        }

        else if (iLenInt < iMinLenInt){
            //sRet = " 정수부분 길이가 너무 짧습니다.";
            sRet = MSG_ERR_LEN_SHORT;
            sRet = sRet + "\\n최소 허용 정수부 길이 " + iMinLenInt ;
        }
        else if (iLenFraction < iMinLenFraction){
            //sRet = " 소수부분 길이가 너무 짧습니다.";
            sRet = MSG_ERR_LEN_SHORT;
            sRet = sRet + "\\n최소 허용 소수부 길이 " + iMinLenFraction ;
        }
        else
            sRet = "";

        return sRet;
    }

	/**
     * 값 범위 검사
     */
    public static String checkRange( String val,		// 검사하고자 하는 값
							  String type,		// 데이터타입
							  String format,	// 날짜형 형식
							  String maxVal,	// 최대값
							  String minVal		// 최소값
							 )
    {
        String sRet = "";

        if (type.equals(TAG_NUM) || type.equals(TAG_INT))
            sRet = checkRangeNum(val, type, maxVal, minVal);
        else if (type.equals(TAG_DATE))
            sRet = checkRangeDate(val, format, maxVal, minVal);

        return sRet;
    }

	/**
     * 숫자형 값 범위 검사
     */
    public static String checkRangeNum(String val,			// 검사하고자 하는 값
								String type,        // 데이터타입
								String maxVal,		// 최대값
								String minVal		// 최소값
								)
    {
        String sRet = "";
        double nMaxVal;
        double nMinVal;
        double nVal = (new Double(val)).doubleValue();

        if (isNull(maxVal))
            nMaxVal = Double.POSITIVE_INFINITY;
        else
            nMaxVal = (new Double(maxVal)).doubleValue();

        if (isNull(minVal))
            nMinVal = Double.NEGATIVE_INFINITY;
        else
            nMinVal = (new Double(minVal)).doubleValue();

        if (nVal > nMaxVal){
            sRet = MSG_ERR_VAL_LARGE;
            sRet = sRet + " \\n허용 최대값 " + maxVal;
        }
        else if (nVal < nMinVal){
            sRet = MSG_ERR_VAL_SMALL;
            sRet = sRet + "\\n허용 최소값 " + minVal ;
        }

        return sRet;
    }

	/**
     * 날짜형 값 범위 검사
     */
    public static String checkRangeDate(String val,             // 검사하고자 하는 값
								 String format,          // 날짜형 형식
								 String maxVal,          // 최대값
								 String minVal           // 최소값
								)
    {
        String sRet = "";
        Date dDate;
        Date dMaxDate;
        Date dMinDate;

        try{
            format = null2str(format, FMT_DATE);
            maxVal = null2str(maxVal, "9999-12-31");
            minVal = null2str(minVal, "0001-01-01");

            dDate = str2date(val, format);
            dMaxDate = str2date(maxVal, format);
            dMinDate = str2date(minVal, format);

            if (dDate.after(dMaxDate)){
                sRet = MSG_ERR_VAL_LARGE;
                sRet = sRet + "\\n최대 허용 값 " + date2str(dMaxDate, format);
            }
            else if (dDate.before(dMinDate)){
                sRet = MSG_ERR_VAL_SMALL;
                sRet = sRet + "\\n최소 허용 값 " + date2str(dMinDate, format);
            }

        } catch (Exception e) {
            sRet = e.toString();
        }

        return sRet;
    }

    //==================================================================================
    // 객체 생성 관련 함수
    //==================================================================================
    /*
     *  *************************************************************************
     *  콤보 객체를 생성하기 위한 문자열 생성
     *  -------------------------------------------------------------------------
     *  목적 : 리스트 상에 출력되는 콤보의 경우 수시로 데이터 베이스를
     *         갔다 와야 하는 부하르 최소화.
     *  -------------------------------------------------------------------------
     * @ method       : dispComboSerch()
     * @ method desc  : select Box Htm gString sFilter		//제약 조건
     * -------------------------------------------------------------------------
     * @ parameter    : String sObjName		Object Name
     * @ parameter    : String sSelectStr	기초 Select 생성 문자열
     * @ parameter    : String sDefaultVal	선택되고자 하는 값(value 값과 비교함)
     * @ parameter    : String sErrorMsg			에러메시지
     * -------------------------------------------------------------------------
     * @ return value : String  -- 선택된 값으로 설정된 Select 생성 문자열
     * -------------------------------------------------------------------------
     * @ exception    :  ClassNotFoundException
     * *************************************************************************
     */
        public static String dispComboSerch( String sObjName, String sSelectStr, String sDefaultVal,String sErrorMsg ) throws ClassNotFoundException
    {
    	String CHR_NEWLINE = System.getProperty("line.separator");
        String sReturn		= ""; // return value
        StringBuffer sException	= new StringBuffer();


		sException.append("<select name='SCHFAIL'").append(" >").append(CHR_NEWLINE);
		sException.append("<option value='' selected>코드조회오류</option>").append(CHR_NEWLINE);
		sException.append(" </select>").append(CHR_NEWLINE);

        try {

        	sReturn = sSelectStr;


        } catch(Exception e) {
            sReturn = sException.toString();
        }

        finally {
        }

        return sReturn;
	}


    //==================================================================================
    // 형변환 및 포멧팅 관련 함수
    //==================================================================================
	/**
     * 개행문자대신 "BR" 붙이기
     */
    public static String appendHtmlBr(String comment)
    {
        int length = comment.length();
        StringBuffer buffer = new StringBuffer();

        for (int i = 0; i < length; ++i)
        {
            String comp = comment.substring(i, i+1);
            if ("\r".compareTo(comp) == 0)
            {
                comp = comment.substring(++i, i+1);
                if ("\n".compareTo(comp) == 0)
                    buffer.append("<BR>\r");
                else
                    buffer.append("\r");
            }
            buffer.append(comp);
        }
        return buffer.toString();
    }

    /**
     * 원하는 길이에서 br을 추가해 라인 바꾸기<br>
     * reqtColumn은 한글기준 (30이면 영문은 60개<br>
     * \r \n: 길이 1 ,br길이 4<br>
     */
    public static String changeBrLine( String Data, int reqtColumn )
    {
        String newStr = "" ;
        int    len    = Data.length();

        try
        {
            if( Data == null )
            {
                return setSpace( reqtColumn ) ;
            }
            if ( len > reqtColumn)
            {// data길이가 요구 길이보다 클때

                if( Data.toLowerCase().indexOf("<br>\r") ==-1 )
                {//<br>\r이 없을때
                    int    cursor = 0;
                    int    engCount = 0;

                    for(int i =0 ; i < len ; i++)
                    {
                        String addStr = Data.substring(i,i+1);

                        // 원하는 길이가 됐을때
                        if (cursor == reqtColumn)
                        {
                            addStr += "<br>\r";
                            cursor =  0;
                        }

                        cursor ++; // 위에 쓰면 첫라인은 1개가 들찍힘

                        //30개로 끊을때 한글은 30개,영문은 60개로 끊기위해
                        char c = addStr.charAt(0);
                        if ( (int)Character.toUpperCase(c) >= 65 && (int)Character.toUpperCase(c) <= 90  )
                        {
                            engCount++;// 영문2개를 한개로 잡기위해
                            if (engCount == 2     )
                            {
                               cursor--;
                               engCount=0;
                            }
                        }
                        newStr +=addStr ;

                    }
                }
                else
                {//<br>\r이 있을때
                    int    cursor   = 0;
                    int    engCount = 0;
                    String currStr  = "";

                    for(int i=0;i<len;i++)
                    {
                        if(len-i > 5 )   currStr = Data.substring(i,i+5);
                        else             currStr = Data.substring(i,len);

                        String addStr   = "";

                        if( currStr.toLowerCase().equals("<br>\r"))
                        {//<br>이 있을때
                            addStr=currStr;
                            i+=4;
                            cursor = 0;//cursor도중에 <br>\r있으면 0으로 초기화
                        }
                        else
                        {//<br>이 없을때
                            addStr = Data.substring(i,i+1);

                            // 원하는 길이가 됐을때
                            if (cursor == reqtColumn)
                            {
                                addStr += "<br>\r";
                                cursor =  0;
                            }
                            cursor ++; // 위에 쓰면 첫라인은 1개가 들찍힘

                            //30개로 끊을때 한글은 30개,영문은 60개로 끊기위해
                            char c = addStr.charAt(0);
                            if ( (int)Character.toUpperCase(c) >= 65 && (int)Character.toUpperCase(c) <= 90  )
                            {
                                engCount++;// 영문2개를 한개로 잡기위해
                                if (engCount == 2     )
                                {
                                    cursor--;
                                    engCount=0;
                                }
                            }
                        }// -  br이 있고 없을때
                        newStr +=addStr ;
                    }//for
                } //br이 있고 없을때
            }
            else
            {// data길이가 요구 길이보다 작을때
                newStr = Data;
            }
        }
        catch( java.lang.Exception ex )
        {

            return "changeline error :"+ex.getMessage();

        }
        return newStr ;
    }

	/**
     * blank Check하여 &nbsp; 반환
     */
    public static String checkBlank2Nbsp( String string )
    {
        if( string.length() ==0  || string.equals(""))
        {
            return "&nbsp;" ;
        }
        else
        {
            return string ;
        }
    }

    /**
     * NullCheck하여 공백 반환
     */
    public static String checkNull2Blank( String nullString )
    {
        if( nullString == null || nullString.equals("null"))
        {
            return "" ;
        }
        else
        {
            return nullString ;
        }
    }

    /**
     * NullCheck하여 "-" 반환
     */
    public static String checkNull2Dash( String nullString )
    {
        if( nullString == null || nullString.trim().equals( "null" ) )
        {
            return "-" ;
        }
        else
        {
            return nullString.trim() ;
        }
    }


    /**
     * Null Check하여 &nbsp; 반환
     */
    public static String checkNull2Space( String nullString )
    {
        if( nullString == null || nullString.equals("null"))
        {
            return "&nbsp;" ;
        }
        else
        {
            return nullString ;
        }
    }

    /**
     * String 배열을 입력받아 NullCheck하여 원하는 값 반환
     */
    public static String checkNull2Value( String[] nullArray,int i,String value )
    {
        if( nullArray == null )
        {
            return value ;
        }
        else if(nullArray[i]== null)
        {
            return value;
        }
        else
        {
            return nullArray[i] ;
        }
    }

    /**
     * NullCheck하여 원하는 값 반환
     */
    public static String checkNull2Value( String nullString,String value )
    {
        if( nullString == null || nullString.equals("null"))
        {
            return value ;
        }
        else
        {
            return nullString ;
        }
    }

    /**
     * NullCheck하여 "0" 반환
     */
    public static String checkNull2Zero( String nullString )
    {
        if( nullString == null || nullString.equals("null") )
        {
            return "0" ;
        }
        else
        {
            return nullString ;
        }
    }

    /**
     * null이나 빈공백시 0로 setting
     */
    public static String checkReturnZero(String str)
    {
        if (str==null)              str="0";
        else if (str.trim().equals("") || str.trim().length() < 1)  str="0";

        return str;
    }

    /**
     * 원하는 문자로 원하는 갯수(totalLength-data크기)만큼 채워준다<br>
     * 반환 크기 data length
     */
    public static String fillChar2String ( String str, int totalLength ,String fillChar,String align)
    {
        if ( str == null   )
            str="";

        String strData  =  "";
        int CheckNum  = totalLength - str.length();

        for ( int i = 0 ; i < CheckNum ; i++ )
                strData += fillChar;

        if( align.toUpperCase().equals("RIGHT") )
            strData = str + strData;
        else
            strData = strData + str;

        return strData;
    }

    /**
     * 원하는 문자로 원하는 갯수(totalLength)만큼 채워준다<br>
     * 반환 크기 data length +totalLength
     */
    public static String fillChar2StringSumSize ( String str, int totalLength ,String data,String align)
    {
        if ( str == null   )  str="";

        String strData  =  "";

        for ( int i = 0 ; i < totalLength ; i++ )
                strData += data;
        if( align.toUpperCase().equals("RIGHT") )
            strData = str + strData;
        else
            strData = strData + str;

        return strData;
    }

	/**
     * 좌측정렬    : 문자열+원하는 스페이스크기<br>
     * 오른쪽 정렬 : 원하는 스페이스크기 + 문자열<br>
     * 중간 정렬   : 원하는 스페이스크기/2 + 문자열 + 원하는 스페이스크기/2<br>
     * 반환 크기 SpaceNum<br>
     */
    public static String   fillSpace2String( String Data, int SpaceNum, String Align )
    {
        String LeftSpace   = "" ;
        String RightSpace  = "" ;
        String ReturnValue = "" ;
        int    CheckNum    = 0  ;

        try
        {
            if( Data == null )
            {
                return setSpace( SpaceNum ) ;
            }
            // 가져온 데이터가 보여주고자하는 길이보다 클 경우 보여주고자하는 길이만큼 잘라준다.
            if( toCode( Data ).length() > SpaceNum )
            {
                // 잘리는 부분에 한글이 들어가면 그 컬럼 전체가 빠짐
                // 그래서 한글일 경우 그 전에서 자름
                if( Data.length() == toCode( Data ).length() )
                {
                    Data = Data.substring( 0, SpaceNum ) ;
                }
                else
                {
                    if( toHangul( toCode( Data ).substring( SpaceNum - 1, SpaceNum + 1 ) ).equals(
                                  toCode( Data ).substring( SpaceNum - 1, SpaceNum + 1 ) )
                    )
                    {
                        Data = toCode( Data ).substring( 0, SpaceNum - 1 ) + " "  ;
                    }
                    else
                    {
                        Data = toCode( Data ).substring( 0, SpaceNum ) ;
                    }
                    Data = toHangul( Data ) ;
                }
            }
            else
            {
                CheckNum = SpaceNum - toCode( Data ).length() ;
            }
            int LeftCheckNum  = CheckNum / 2            ;
            int RightCheckNum = CheckNum - LeftCheckNum ;
            for( int i = 0 ; i < LeftCheckNum ; i++ )
            {
                LeftSpace += " " ;
            }
            for( int i = 0 ; i < RightCheckNum ; i++ )
            {
                RightSpace += " " ;
            }
            // 왼쪽으로 정렬
            if( Align.toUpperCase().equals( "LEFT" ) )
            {
                ReturnValue = Data + LeftSpace + RightSpace ;
            }
            // 오른쪽으로 정렬
            else if( Align.toUpperCase().equals( "RIGHT" ) )
            {
                ReturnValue = LeftSpace + RightSpace + Data ;
            }
            // 가운데로 정렬
            else if( Align.toUpperCase().equals( "CENTER" ) )
            {
                ReturnValue = LeftSpace + Data + RightSpace ;
            }
        }
        catch( java.lang.Exception ex )
        {
            ReturnValue = Data+":"+ex.getMessage();
        }
        return ReturnValue ;
    }
    /**
     * 특수문자를  임의의 기호로
     */
    public static String replaceCode(String orgstr)
    {
        int    len        = orgstr.length();
        String rplStr     = "";
        String currStr    = "";
        String replaceStr = "";
        int    i = 0;

        for( i = 0;i<len;i++)
        {
            currStr = orgstr.substring(i,i+1);
            if( currStr.equals("\""))
            {
                rplStr = "##34";
            }else if( currStr.equals("\'"))
            {
                rplStr = "##39";
            }else if( currStr.equals(">"))
            {
                rplStr = "##60";
            }else if( currStr.equals("<"))
            {
                rplStr = "##62";
            }else if( currStr.equals("/"))
            {
                rplStr = "##47";
            }else if( currStr.equals("\\"))
            {
                rplStr = "##92";
            }else if( currStr.equals("("))
            {
                rplStr = "##40";
            }else if( currStr.equals(")"))
            {
                rplStr = "##41";

            }else if( currStr.equals(","))
            {
                rplStr = "##44";

            } else
            {
                rplStr = currStr ;
            }
            replaceStr += rplStr ;
        }
        return replaceStr;
    /* 개행문자도 가능
            }else     if( currStr.equals("\n"))
            {
                              rplStr = "##10";
    */
    }

    /**
     * [새로 작성] 특수문자를  기호(키워드)로
     */
    public static String replaceCodeKey(String orgstr)
    {
        int    len        = orgstr.length();
        String rplStr     = "";
        String currStr    = "";
        String replaceStr = "";
        int    i = 0;

        for( i = 0;i<len;i++)
        {
            currStr = orgstr.substring(i,i+1);

            if( currStr.equals("&"))
            {
                rplStr = "&amp;";
            }
            else if( currStr.equals("<"))
            {
                rplStr = "&lt;";
            }
            else if( currStr.equals(">"))
            { 
                rplStr = "&gt;";
            }
            else if( currStr.equals("\""))
            {
                rplStr = "&quot;";
            }
            else if( currStr.equals("\'"))
            {
                rplStr = "&#039";
            }
            else if( currStr.equals("%"))
            {
                rplStr = "&#037";
            }
            else if( currStr.equals("@"))
            {
                rplStr = "&#064";
            }
            else if( currStr.equals(" "))
            {
                rplStr = "&nbsp;&nbsp;&nbsp;";
            }
            else
            {
                rplStr = currStr ;
            }
            replaceStr += rplStr ;
        }
        return replaceStr;
    }

    /**
     * 임의의 기호를 특수문자로
     */
    public static String replaceSign(String orgstr)
    {
        int    len        = orgstr.length();
        String rplStr     = "";
        String currChrs   = "";
        String currStr    = "";
        String replaceStr = "";
        int    j = 0,i = 0;
        boolean flag = true;

        for( i=0;i<len;i++)
        {
            currChrs = orgstr.substring(i,i+1);
            flag = true;

            j = i;
            if(len-j >= 4)   currStr = orgstr.substring(j,j+4);
            else             currStr = orgstr.substring(j,j+1);

            if( currStr.equals("##34"))
            {
                rplStr = "\"";
            }else if( currStr.equals("##39"))
            {
                rplStr = "\'";
            }else if( currStr.equals("##60"))
            {
                rplStr = ">";
            }else if( currStr.equals("##62"))
            {
                rplStr = "<";
            }else if( currStr.equals("##47"))
            {
                rplStr = "/";
            }else if( currStr.equals("##92"))
            {
                rplStr = "\\";
            }else if( currStr.equals("##40"))
            {
                rplStr = "(";
            }else if( currStr.equals("##41"))
            {
                rplStr = ")";
            }else if( currStr.equals("##44"))
            {
                rplStr = ",";
            }else
            {
                rplStr = currChrs ;
                flag   = false;
            }
            replaceStr +=rplStr ;
            if(flag == true)
            {
                i = i+3;
            }
        }
        return replaceStr;
        /*개행문자도 가능

                    }else     if( currStr.equals("##10"))
                    {
                                    rplStr = "";
        */
    }

    /**
     *
     */
    public static String replaceSignSave(String orgstr)
    {
        // pos = 0;
        int     len         = orgstr.length();
        String  rplStr      = "";
        String  currChrs    = "";
        String  currStr     = "";
        String  replaceStr  = "";
        int j = 0,i = 0;
        boolean flag        = true;

        for( i = 0;i<len;i++)
        {
            currChrs = orgstr.substring(i,i+1);
            flag     = true;

            j=i;
            if(len-j >=4) currStr = orgstr.substring(j,j+4);
            else          currStr = orgstr.substring(j,j+1);

            if( currStr.equals("##34"))
            {
                rplStr = "\"";
            }else if( currStr.equals("##39"))
            {
                rplStr = "\'";
            }else if( currStr.equals("##60"))
            {
                rplStr = ">";
            }else if( currStr.equals("##62"))
            {
                rplStr = "<";
            }else if( currStr.equals("##47"))
            {
                rplStr = "/";
            }else if( currStr.equals("##92"))
            {
                rplStr = "\\";
            }else if( currStr.equals("##10"))
            {
                            rplStr = "";
            }else if( currStr.equals("##40"))
            {
                rplStr = "(";
            }else if( currStr.equals("##41"))
            {
                rplStr = ")";

            }else if( currStr.equals("##44"))
            {
                rplStr = ",";

            } else
            {
                rplStr = currChrs ;
                flag   = false;
            }
            replaceStr += rplStr ;
            if(flag == true)
            {
                i=i+3;
            }

                    }

             return replaceStr;
    }

    /**
     * String Replace 시킴 - 문자열의 변환(전체문자열에는 영향없음)
     */
    public static String replaceStringAll(String in, String find, String replace )
    {
        String data  = in ;
        int    pos  = 0 ;
        int    npos = in.indexOf (find , pos);

        while ( npos >= 0 )
        {
            data = data.substring ( 0 , npos ) + replace + data.substring (npos + find.length(),data.length());
            pos = npos + find.length();
            npos = data.indexOf (find, pos);
        }
        return data;
    }

    /**
     * String Replace 시킴 - 문자열의 변환(전체문자열에는 영향없음)
     */
    public static String replaceStringAll2( String Source, String FindText, String replace )
    {
        String rtnSource  = "";
        String rtnCheck   = "";
/*
        // JRun 한글문제
        try{
            replace = new String( replace.getBytes( "iso-8859-1" ), "ksc5601" ) ;
        }
        catch( UnsupportedEncodingException e ) {
        }
*/
        int FindLength    = Source.length();


        // 찾을 문자 길이
        int FindTextLength = FindText.length() ;

        char SourceArrayChar[] = new char[FindLength];
        SourceArrayChar = Source.toCharArray();
        for ( int i = 0 ; i < FindLength ; i++ )
        {
            rtnCheck=Source.substring(i,i+1);
            int j=i;
            if( FindLength - j >= FindTextLength)    rtnCheck=Source.substring(j,j+FindTextLength);
            else                                     rtnCheck=Source.substring(j,j+1);

            if ( rtnCheck.equals(FindText) )
            {
                rtnSource += replace;
                i+= (FindTextLength-1);
            }
            else
            {
                rtnSource += SourceArrayChar[i];
            }
        }
        return rtnSource;

    }

    /**
     * 문자열의 색깔변환(전체문자열에는 영향없음)
     */
    public static String replaceStringColor( String Source, String FindText, String Color,String replaceFlag )
    {
        String rtnSource   = "";
        String rtnCheck    = "";

        int FindLength     = Source.length();
        int FindIndex      = Source.indexOf( FindText ) ;

        // 찾을 문자 길이
        int FindTextLength = FindText.length() ;

        char SourceArrayChar[] = new char[FindLength];
        SourceArrayChar = Source.toCharArray();
        for ( int i = 0 ; i < FindLength ; i++ )
        {
            rtnCheck=Source.substring(i,i+1);
            int j=i;
            if( FindLength - j >= FindTextLength)    rtnCheck=Source.substring(j,j+FindTextLength);
            else                                     rtnCheck=Source.substring(j,j+1);

            if (replaceFlag.equals("BOTH"))
            {// 대문자이건 소문자이건
                if ( rtnCheck.equals(FindText.toUpperCase()) || rtnCheck.equals(FindText.toLowerCase()) )
                {
                    rtnSource += "<font color='"+Color+"'>"+rtnCheck+"</font>";
                    i+= (FindTextLength-1);
                }
                else
                {
                    rtnSource += SourceArrayChar[i];
                }
            }
            else
            {//일치하는 것만 - ONLY
                if ( rtnCheck.equals(FindText) )
                {
                    rtnSource += "<font color='"+Color+"'>"+rtnCheck+"</font>";
                    i+= (FindTextLength-1);
                }
                else
                {
                    rtnSource += SourceArrayChar[i];
                }

            }
        }

        return rtnSource;

    }

    /**
     * 원하는 사이즈만큼의 char넣기<br>
     */
    public static String setChar( int loopNum ,String fillChar)
    {
        String rtn = "";
        for( int i = 0 ; i < loopNum ; i++ )
                rtn = rtn + fillChar;

        return rtn;
    }

    /**
     * comma세팅
     */
    public static String setComma(String data)
    {
        if (data == null || data.trim().length() == 0 )  return "";

        data = data.trim();

        //.이하를 제외한 길이
        int strLen = 0;

        // -가 있으면 잘라냈다  반환시 붙여 준다
        int     dash = data.indexOf( '-' );
        // - 의 위치를 못 찾았으면
        if( dash == -1 )   data = data;
        else               data = data.substring(dash+1);

        // .가 있으면 반환시 붙여 준다
        int point = data.indexOf( '.' );

        if( point == -1 ) strLen = data.length();
        else              strLen = point;

        int underNum =  data.length() - point;

        double d = 0.0D;

        try
        {
            d = Double.valueOf(data.substring(0,strLen)).doubleValue();
        }
        catch(Exception _ex)
        {
            d = d;
        }

        String formats = "";

        if( underNum ==0 ) formats = "###,###,###,###";
        else               formats = "###,###,###,###." +  setChar( underNum ,"#");
        DecimalFormat df = new DecimalFormat(formats);
        String commaStr = df.format(d);

        // 소숫점이하 값이 있으면 마지막에 붙여 준다.
        if( point > -1 ) commaStr += data.substring( point, data.length());
        // - 가 있으면 앞에 붙여준다
        if( dash > -1 )  commaStr = '-'+commaStr;

        return commaStr ;
    }

    /**
     * comma세팅
     */
    public static String setComma(double num)
    {
        String data = "";
        try
        {
            data = String.valueOf(num).toString();
        }
        catch(Exception _ex)
        {
            data = "0.00";
        }


        return  setComma( data);
    }

    /**
     * comma세팅
     */
    public static String setComma(long num)
    {
        String data = "";
        try
        {
            data = String.valueOf(num).toString();
        }
        catch(Exception _ex)
        {
            data = "0";
        }


        return  setComma( data);
    }

    /**
     * comma세팅
     */
    public static String setComma(int num)
    {
        String data = "";
        try
        {
            data = String.valueOf(num).toString();
        }
        catch(Exception _ex)
        {
            data = "0";
        }


        return  setComma( data);
    }

    /**
     * 원하는 사이즈만큼의 space넣기
     */
    public static String setSpace( int loopNum )
    {
        String rtn = "";
        for( int i = 0 ; i < loopNum ; i++ )
                rtn = rtn + " ";

        return rtn;
    }

    /**
     * 주어진 문자열(str)을 double 형 숫자로 변환한다.<br>
     * 단, 숫자 문자열로서 유효하지 않은 문자열은 0 을 리턴한다.<br>
     */
    public static  double string2Double( String str )
    {
        double ret = 0.0;

        try{
            ret = new Double( str ).doubleValue();
        }
        catch( Exception e ){
            return ret;
        }

        return ret;
    }

    /**
     * 주어진 문자열(str)을 Integer 형 숫자로 변환한다.<br>
     * 단, 숫자 문자열로서 유효하지 않은 문자열은 0 을 리턴한다.<br>
     */
    public  static int string2Int( String str )
    {
        int ret = 0;

        try{
            if ( str == null || str.trim().length() == 0 ) return 0;

            int position = str.indexOf(".");
            switch( position ){
                case -1:
                    ret = new Integer( str ).intValue();
                    break;
                case 0:
                    ret = 0;
                    break;
                default:
                    ret = new Integer( str.substring( 0, position ) ).intValue();
            }
        }
        catch( Exception e ){
            return 0;
        }

        return ret;
    }

    /**
     * 주어진 문자열(str)을 long 형 숫자로 변환한다.<br>
     * 단, 숫자 문자열로서 유효하지 않은 문자열은 0 을 리턴한다.<br>
     */
    public static  long string2Long( String str )
    {
        long ret = 0;

        try{
            if ( str == null || str.trim().length() == 0 ) return 0;

            int position = str.indexOf(".");
            switch( position ){
                case -1:
                    ret = new Long( str ).longValue();
                    break;
                case 0:
                    ret = 0;
                    break;
                default:
                    ret = new Long( str.substring( 0, position ) ).longValue();
            }
        }
        catch( Exception e ){
            return 0;
        }

        return ret;
    }

    /**
     * 한글을 일반코드로 변환한다.<br>
     */
    public static String toCode ( String kscode )// throws UnsupportedEncodingException
    {
        if ( kscode == null ) return null;
        String data = "";
        try
        {
            data = new String( kscode.getBytes( "KSC5601" ), "8859_1" ) ;
        }
        catch(UnsupportedEncodingException e)
        {
            data = kscode+" : UnsupportedEncodingException";
        }
        catch(Exception e)
        {
            data = kscode+" : Exception";
        }
        return data;
    }

    /**
     * 유니코드를 한글로 변환한다.<br>
     */
    public static String toHangul(String str) //throws java.io.UnsupportedEncodingException
    {
        if ( str == null ) return null;
        String data = "";
        try
        {
            //data = new String(str.getBytes("8859_1"),"KSC5601");
            data = new String(str.getBytes(),"KSC5601");

        }
        catch(UnsupportedEncodingException e)
        {
            data = str+" : UnsupportedEncodingException";
        }
        catch(Exception e)
        {
            data = str+" : Exception";
        }
        return data;
        //한글인데 한번 더 쓰면 ??? 표시
    }

    /**
     * 유니코드를 한글로 변환한다.<br>
     */
    public static String toKr(String str) //throws java.io.UnsupportedEncodingException
    {
        if ( str == null ) return null;
        String data = "";
        try
        {
            data = new String(str.getBytes("8859_1"),"KSC5601");

        }
        catch(UnsupportedEncodingException e)
        {
            data = str+" : UnsupportedEncodingException";
        }
        catch(Exception e)
        {
            data = str+" : Exception";
        }
        return data;
    }

    /**
     * 유니코드를 한글로 변환한다.<br>
     */
    public static String toKsc(String str) //throws java.io.UnsupportedEncodingException
    {
        if ( str == null ) return null;
        String data = "";
        try
        {
            data = new String(str.getBytes("EUC-KR"),"KSC5601");

        }
        catch(UnsupportedEncodingException e)
        {
            data = str+" : UnsupportedEncodingException";
        }
        catch(Exception e)
        {
            data = str+" : Exception";
        }
        return data;
    }

    /**
     * 유니코드를 한글로 변환한다.<br>
     */
    public static String toChn(String str) //throws java.io.UnsupportedEncodingException
    {
        if ( str == null ) return null;
        String data = "";
        try
        {
            data = new String(str.getBytes("KSC5601"),"GB2312");

        }
        catch(UnsupportedEncodingException e)
        {
            data = str+" : UnsupportedEncodingException";
        }
        catch(Exception e)
        {
            data = str+" : Exception";
        }
        return data;
    }

    /**
     * 유니코드를 한글로 변환한다.<br>
     */
    public static String toDChn(String str) //throws java.io.UnsupportedEncodingException
    {
        if ( str == null ) return null;
        String data = "";
        try
        {
            data = new String(str.getBytes(),"GB2312");

        }
        catch(UnsupportedEncodingException e)
        {
            data = str+" : UnsupportedEncodingException";
        }
        catch(Exception e)
        {
            data = str+" : Exception";
        }
        return data;
    }

    /**
     * length크기에 맞추어 0을 붙여 반환
     */
    public static String toLen ( int nums, int length )
    {
        String num = String.valueOf(nums).toString();
        int space = length - num.length();
        int i = 0;
        String buf = "";

        for( i = 0; i < space; i++ )
            buf += "0";
        num = buf + num;

        return num;
    }

    /**
     * length크기에 맞추어 0을 붙여 반환
     */
    public static String toLen2 ( int nums )
    {
        String num=String.valueOf(nums).toString();
        if ( num.length() == 1 )
                num = "0" + num;
        return num;
    }
    /**
     * 원하는 크기로 자르기
     */
    public static String subString(String str,int i)
    {
            if ( str == null )  return "";
            if ( str.length() == 0 || str.trim().equals("") ) return "";

            try
            {
                if (str.length() >= i ) str = str.substring(0,i);
            }catch(Exception e)
            {
                str = "Data cut error : ["+str+"]";
            }
            return str;

    }

    /**
     * reqtColumn은 한글기준 (30이면 영문은 60개<br>
     * \r \n: 길이 1 ,<br>길이 4
     * 원하는 길이에서 <br>을 추가해 라인 바꾸기<br>
     */
    public static String changeLine( String Data, int reqtColumn )
    {
        String newStr = "" ;
        int    len    = Data.length();
        int    cursor = 0;
        try
        {
            if( Data == null )
            {
                return "" ;
            }

            if(len <= reqtColumn ) return Data;

            for(int i =0 ; i < len ; i++)
            {

                String addStr = Data.substring(i,i+1);

                if(addStr.equals("\r"))
                {
                    cursor = 0;
                    continue;
                }

                //한영판단
                //char c = addStr.charAt(0);
                byte[] b = addStr.getBytes("ksc5601");

                if (b.length == 1)
                {
                   //영문
                   cursor += 1;
                }
                else
                {
                   //한글
                   cursor += 2;
                }

                if ( cursor > reqtColumn)
                {
                    newStr += addStr + "\r";
                    cursor = 0;

                }
                else
                {
                    newStr +=addStr ;
                }
            }

        }
        catch( java.lang.Exception ex )
        {

            return "changeline error :"+ex.getMessage();

        }
        return newStr ;
    }



	/**
     * 숫자값중 0값이 있으면 공백(" ")으로 변환.
	 * @param	sValue (String) 대상 숫자 문자열
	 * @return	입력된 숫자값 또는 " "(공백)
	 * @see		changeZeroSpace(val)
     */
    public static String changeZeroSpace(String sValue) {

        if (sValue == null || sValue.equals("0")) sValue = " ";

        return sValue;
    }

	/**
	 * 숫자 포멧(세자리 마다 comma를 찍는다.
	 * ex) addComma("492875927.8374" , 7) --> 492,875,927.8374000
	 * @param	val (String) 대상 변경 문자열
	 * @param	len (int) 소숫점이하 절사 자릿수(잉여 자리수는 0으로 셋팅)
	 * @return	세 자리마다 comma가 추가된 문자열
	 * @see		#String
     */
    public static String addComma( String val, int len){

        String sVal = "";
        String result = "";
        int leng = 0;
        int iPos = 0;
        int i = 0;
        String addZero = "";

        if(trim(val).length() > 0){
	        iPos = val.indexOf(".", 0); // 소숫점 위치
			if(iPos > 0){
		        sVal = val.substring(iPos);
		        leng = trim(sVal).length();

		        if(leng-1 > len){
		        	sVal = sVal.substring(0, len+1);
		        }else if(leng-1 < len){
		        	for(i = 0; i < (len - (leng-1)); i++){
		        		addZero += "0";
		        	}
		        	sVal += addZero;
		        }
	        	result = formatNumber(val.substring(0,iPos),"###,###") + sVal;
	        }else if(len == 0){
	        	result = formatNumber(val,"###,###");
			}else{
	        	for(i = 0; i < len; i++){
	        		addZero += "0";
	        	}
	        	result = formatNumber(val,"###,###") + "." + addZero;
	        }
		}

        return result;
    }



    //==================================================================================
    // 기타 함수
    //==================================================================================


    /**
     * 클라이언트의 브라우저 cache못쓰게 하기
     */
    public static void setResponse(HttpServletResponse response)
    throws UnsupportedEncodingException, IOException
    {
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Cache-Control", "no-cache");
    }

    /**
     * 실제로 파일에 쓰기
     */
    public static void writeLog(String string,PrintWriter log)
    {
        if (log ==null) return;
        // writing operation
        log.println(string);
        // print() method never throws IOException,
        // so we should check error while printing
        if (log.checkError())
        {
            System.err.println("File write error.");
        }
    }

    /**
     * Html Textarea에서 오는 값에 Sql의 in문에 쓸수 있도록 정의
     */
    public static String conditionToTextArea(String data)
    {

        //Html textarea에서 enter치면  \r\n
        if (data==null || data.equals("")) return "";

        String find_str ="\r\n";
        String replace_str = "','";
        int pos = data.indexOf(find_str);

        if(pos == -1)
        {
            data = "('"+data+"')";
        }else
        {
            data = "('"+replaceStringAll2( data,find_str,replace_str)+"')";
        }

        return data;

    }

    /**
     *
     */
    public static Hashtable putOfHashtableToArray(Hashtable parameters,String name,String value)
    {
            if(parameters.get(name) == null)
            {
                String values[] = new String[1];
                       values[0] = value;
                       parameters.put(name, values);
            } else {
                Object prevobj = parameters.get(name);
                if(prevobj instanceof String[])
                {
                    String prev[] = (String[])prevobj;
                    String newStr[] = new String[prev.length + 1];
                    System.arraycopy(prev, 0, newStr, 0, prev.length);
                    newStr[prev.length] = value;
                    parameters.put(name, newStr);
                } else
                {
                    throw new IllegalArgumentException("failure in parseMulti hashtable building code");
                }
        }

        return parameters;
    }

    //==================================================================================
    // eOffice에서 추가해온것들.
    //==================================================================================

    /**
     * 문자열의 길이가 size크기가 되도록 '0'을 문자열앞에 덧붙인다.
     *
     *@param		str						Description of the Parameter
     *@param		size					Description of the Parameter
     *@return		String
     */
    public static String addZero(String str, int size) {
      String result = "";

      if(size < str.length()) return str;

      for(int i = 0; i < size - str.length(); i++)
        result = result + "0";

      return result + str;
    }


    /**
     *	문자열에서 선두에 있는 '0'을 제거한다.
     *
     *@param		str						Description of the Parameter
     *@return		String
     */
    public static String delZero(String str) {
      int startPtr;
      int i;

      if(str == null)			return null;
      if(str.length() == 0)	return null;

      for(i = 0; i < str.length(); i++)
        if(str.charAt(i) != '0') break;

      return ((i == str.length()) ? "0" : str.substring(i, str.length()));
    }
    /**
     * 1 Kilograms = 2.2046 Pound
     *  convertKgToLb
     * @pararm double kg
     * @return doubble (kg*2.20459)
     * @action Kilogram을 Pound로 변환
     * 1자리로
     */

    public  static double convertKgToLb(double kg)
    {
      return kg * 2.20459;
    }
    /**
     * 1 Pound =0.4536 Kilograms
     *  convertLbToKg
     * @pararm double lb
     * @return double (lb*0.45359)
     * @action Pound을 Kilogram로 변환
     */
    public  static double convertLbToKg(double lb)
    {
      return lb * 0.45359;
    }
    /**
     *  1m³=35.3165ft³
     *  convertM3ToFt3
     * @pararm double m3
     * @return double (m3*35.3165)
     * @action m³을 ft³로 변환
     * 3자리로
     */
    public  static double convertM3ToFt3(double m3)
    {
      return m3 * 35.3165;
    }

    /**
     * 1ft³=0.02831m³
     *  convertFt3ToM3
     * @pararm double ft3
     * @return double (ft3*0.02831)
     * @action ft³을 m³로 변환
     */
    public  static double convertFt3ToM3(double ft3)
    {
      return ft3 * 0.02831;
    }


    /**
     * 5자리로 된 FLT no 를 6자리 FLT No 로 변환하여 반환한다.
     * KE0001J, KE0001A 등의 예외 FLT No 추가.
     * @param				String					FLT NO 값.
     * @return			String					6자리로 변환된 FLT NO 값
     */
    public  static String toSixNo(String flt_no) {
      flt_no = flt_no.toUpperCase();
      int fltNoLength = flt_no.length();

      StringBuffer noFltHead		= new StringBuffer(flt_no.substring(0,2));
      StringBuffer noFltEndTail	= new StringBuffer();
      StringBuffer noFltTail		= new StringBuffer();
      StringBuffer tmp					= new StringBuffer();
      String chk								= flt_no.substring(fltNoLength -1);

      if(chk.equals("J") || chk.equals("A")) {
        noFltEndTail.append(chk);
        noFltTail.append(flt_no.substring(2, fltNoLength -1).trim());
      }
      else {
        noFltTail.append(flt_no.substring(2, fltNoLength).trim());
      }

      int loop = 4 - noFltTail.length();
      for (int i = 0; i < loop; i++) {
        tmp.append("0");
      }

      return noFltHead.toString() + tmp.toString() + noFltTail.toString() + noFltEndTail.toString();
    }
    /**
     * 문자열에서 지정된 문자 제거.
     *
     *@param		str						Description of the Parameter
     *@param		ch						Description of the Parameter
     *@return		String
     */
    public static String delChar(String str, char ch) {
      StringBuffer strbuf = new StringBuffer();
      int i;

      if(str == null)			return "";
      if(str.length() == 0)	return "";

      try {
        for(i = 0; i < str.length(); i++) {
          if(str.charAt(i) != ch)
            strbuf.append(str.charAt(i));
        }
        return strbuf.toString();
      }
      catch(Exception e) {
        return "";
      }
    }
    /**
     * request에 있은 parameter값을 dump함.
     *
     *@param		req						HttpServletRequest
     *@return		String
     */
    public static String param(HttpServletRequest req) {
      StringBuffer rtn = new StringBuffer();

      rtn.append("\n getParameter START =================================== <br>\r\n");
      Enumeration a = req.getParameterNames();
      while(a.hasMoreElements()) {
        String name = (String) a.nextElement();
        try {
          if(req.getParameter(name).equals(""))
            rtn.append("  <font color=green> "+name +" = '"+ req.getParameter(name) + "'</font><br>\r\n");
          else
            rtn.append("  <font color=blue> "+name +" = '"+ req.getParameter(name) + "'</font><br>\r\n");
        }
        catch (NullPointerException npe) {
          rtn.append("  <font color=red> "+name +" = Null</font><br>\r\n");
        }
      }
      rtn.append("getParameter END ===================================== <br>\r\n");

      return rtn.toString();
    }

    /**
     * request에 있은 Attribut값을 dump함.
     *
     *@param		req						HttpServletRequest
     *@return		String
     */
    public static String reqAttb(HttpServletRequest req) {
      StringBuffer rtn = new StringBuffer();

      rtn.append("\n getAttribute START =================================== <br>\n");
      Enumeration a = req.getAttributeNames();
      while(a.hasMoreElements()) {
        String name = (String) a.nextElement();
        try {
          if(req.getAttribute(name).equals(""))
            rtn.append("  <font color=green> '" + name + "' = '"+ req.getAttribute(name) + "'</font><br>\r\n");
          else
            rtn.append("  <font color=blue> '" + name + "' = '"+ req.getAttribute(name) + "'</font><br>\r\n");
        }
        catch (NullPointerException npe) {
          rtn.append("  <font color=red> '"+name +"' = Null</font><br>\r\n");
        }
      }
      rtn.append(" getAttribute END ===================================== <br>\n");

      return rtn.toString();
    }

    /**
     * src문자열에 있는 from문자열을 to문자열로 치환
     *
     * @param		src						String
     * @param        from                    String
     * @param        to                      String
     * @return		String
     */
    public static String replace(String src, String from, String to) {
        if (src == null)return "";
        if (from == null)return "";
        if (to == null)return "";

        StringBuffer buf = new StringBuffer();

        for (int pos; (pos = src.indexOf(from)) >= 0; ) {
            buf.append(src.substring(0, pos));
            buf.append(to);

            src = src.substring(pos + from.length());
        }

        buf.append(src);

        return buf.toString();
    }

    /**
     * 두 날짜간의 차이 일수를 return
     *
     * @param      from_dt                    String (yyyyMMdd)
     * @param      to_dt                      String (yyyyMMdd)
     * @return		long
     */
    public static long getDateDiff(String from_dt, String to_dt){

      long start =  date2long("yyyyMMdd",   from_dt);
      long end   =  date2long("yyyyMMdd",   to_dt);
      return ( end - start ) / ( 60 * 60 * 24 * 1000);
    }

    /**
     * 두 날짜간의 차이 시간수를 return
     *
     * @param      from_dtm                    String (yyyyMMddHH)
     * @param      to_dtm                      String (yyyyMMddHH)
     * @return		long
     */
    public static long getTimeDiff(String from_dtm, String to_dtm){

      long start =  date2long("yyyyMMddHH",   from_dtm);
      long end   =  date2long("yyyyMMddHH",   to_dtm);
      return ( end - start ) / ( 60 * 60 * 1000);
    }

    /**
     * 두 날짜간의 차이 분수를 return
     *
     * @param      from_dtm                    String (yyyyMMddHHmm)
     * @param      to_dtm                      String (yyyyMMddHHmm)
     * @return		long
     */
    public static long getMinuteDiff(String from_dtm, String to_dtm){

      long start =  date2long("yyyyMMddHHmm",   from_dtm);
      long end   =  date2long("yyyyMMddHHmm",   to_dtm);
      return ( end - start ) / ( 60 * 1000);
    }


    /**
     * 일자를 long type으로 retun
     *
     * @param		dateFormat      		String
     * @param       dayStr                  String
     * @return		String
     */
    private static long date2long( String dateFormat, String dayStr ){
      long rtValue = 0L;
      SimpleDateFormat sdf = new SimpleDateFormat( dateFormat );
      try{
        Date d = sdf.parse( dayStr );
        rtValue = d.getTime();
      }catch( ParseException e ){
//        System.out.println( e );
      }
      return rtValue;
    }

	/**
     * ULD No.와 PC를 가져온다.
     * 2004.07.23일자로 다시 수정함.
     * '\n'이 안 들어오므로...
     *
     * @param		str      		String
     * @return		String
     */
    public static  String parseUldInfo(String str){
    	String tmpString = "";
		StringBuffer result = new StringBuffer();
	    Vector vec = new Vector();
	    //StringTokenizer st = new StringTokenizer(trim(str), "null\n");
	    StringTokenizer st = new StringTokenizer(trim(str), "*");
	    while (st.hasMoreTokens()) {
	      tmpString = st.nextToken();
	      //if (tmpString.startsWith("*ULD/"))
	      	if (tmpString.startsWith("ULD/"))
	        vec.addElement(tmpString);
	    }
	    for (int i = 0; i < vec.size(); i++) {
	      String res = (String) vec.get(i);
	      result.append(res.substring(4,15).trim());//ULD No.
	      result.append("/");
	      result.append(res.substring(19,23).trim());//PC
	      //if(res.length() > 23)	result.append(res.substring(23,24).trim());//Satus
	      result.append("<br>");
	    }
	    return result.toString();
	}

	/**
     * ULD No.와 PC를 가져온다.
     *
     * @param		String   original string
     * @param		int      가져오고자 하는 건수
     * @return		String
     */
    public static  String parseUldInfo(String str, int len){
		String tmpString = "";
		StringBuffer result = new StringBuffer();
	    Vector vec = new Vector();
	    //StringTokenizer st = new StringTokenizer(trim(str), "null\n");
	    StringTokenizer st = new StringTokenizer(trim(str), "*");

	    while (st.hasMoreTokens()) {
	      tmpString = st.nextToken();
	      //if (tmpString.startsWith("*ULD/"))
	      if (tmpString.startsWith("ULD/"))
	        vec.addElement(tmpString);
	    }
	    for (int i = 0; i < vec.size(); i++) {
	      String res = (String) vec.get(i);
	      result.append(res.substring(4,15).trim());//ULD No.
	      result.append("/");
	      result.append(res.substring(19,23).trim());//PC
	      //if(res.length() > 23) result.append(res.substring(23,24).trim());//Satus
	      if(i == len-1) break;
	      if(i < vec.size()-1) result.append("<br>");
	    }

	    return result.toString();
	}
    
    
    /**
     * ULD No.와 PC를 가져온다.
     *
     * @param		String   original string
     * @param		int      가져오고자 하는 건수
     * @return		String
     */
    public static  String parseUldInfoTrk(String str, int len){
		String tmpString = "";
		StringBuffer result = new StringBuffer();
	    Vector vec = new Vector();
	    //StringTokenizer st = new StringTokenizer(trim(str), "null\n");
	    StringTokenizer st = new StringTokenizer(trim(str), "*");

	    while (st.hasMoreTokens()) {
	      tmpString = st.nextToken();
	      //if (tmpString.startsWith("*ULD/"))
	      if (tmpString.startsWith("ULD/"))
	        vec.addElement(tmpString);
	    }
	    for (int i = 0; i < vec.size(); i++) {
	      String res = (String) vec.get(i);
	      result.append(res.substring(4,15).trim());//ULD No.
	      result.append("/");
	      result.append(res.substring(19,23).trim());//PC
	      //if(res.length() > 23) result.append(res.substring(23,24).trim());//Satus
	      if(i == len-1) break;
	      if(i < vec.size()-1) result.append("^");
	    }

	    return result.toString();
	}
    
    /**
     * ULD No.와 PC를 가져온다.
     *
     * @param		String   original string
     * @param		int      가져오고자 하는 건수
     * @return		String
     */
    public static  String parseUldInfo2(String str, int len){
		String tmpString = "";
		StringBuffer result = new StringBuffer();
	    Vector vec = new Vector();
	    StringTokenizer st = new StringTokenizer(trim(str), "*");

	    while (st.hasMoreTokens()) {
	      tmpString = st.nextToken();
	      if (tmpString.startsWith("ULD/"))
	        vec.addElement(tmpString);
	    }
	    for (int i = 0; i < vec.size(); i++) {
	      String res = (String) vec.get(i);
	      result.append(res.substring(4,res.length()) );//ULD No.
	      if(i == len-1) break;
	      if(i < vec.size()-1) result.append("<br>");
	    }

	    return result.toString();
	}

	/**
     * ULD No.와 PC를 가져온다.
     *
     * @param		String   original string
     * @param		int      가져오고자 하는 건수
     * @return		String
     */
    public static int parseUldCount(String str){
		String tmpString = "";
		Vector vec = new Vector();
	    //StringTokenizer st = new StringTokenizer(trim(str), "null\n");
	    StringTokenizer st = new StringTokenizer(trim(str), "*");

	    while (st.hasMoreTokens()) {
	      tmpString = st.nextToken();
	      //if (tmpString.startsWith("*ULD/"))
	      if (tmpString.startsWith("ULD/"))
	        vec.addElement(tmpString);
	    }
	    return vec.size();
	}

	/**
     * 문자열에 특정 자릿수 만큼 특정 문자를 추가한다.
	 * @param	val (String)	대상  문자열
	 * @param	len (int)		총 문자열 길이
	 * @param	thisFormat (String) 추가 하고 싶은 문자.
	 * @return	String 변경된 문자열
	 * @see		#String
     */
    public static String replaceAddString( String	val,
										   int		len,
									       String	thisFormat )
	{
        int x = 0;
    	int replaceSize	= trim(val).length();
        StringBuffer replaceString = new StringBuffer(10);

        try{
        	replaceString.append(trim(val));
            for(x=replaceSize; len > x; x++){
            	replaceString.append(thisFormat);
            }

        } catch (Exception e) {
            return null;
        }

        return replaceString.toString();
    }

	/**
     * 특정문자열로 구분하여 String 배열로 값을 넘겨준다
     *   예:  splitS("01:23:25:25",":")
     * 			return 값 =>  String[0] = 01
     *                        String[1] = 23
     *                        String[1] = 25
     *                        String[1] = 25
	 * @param	src (String)	대상  문자열
	 * @param	delim (String)		구분 문자열
	 * @return	String[]
     */
	public static String[] splitS(String src ,String delim) throws Exception
	{
	  	int delimIndex = 0;

	  	String splitString = "";
	  	splitString = src;
	  	String preSplitString = "";
	  	preSplitString = src;
		Vector results = null;
		results = new Vector();
	  	int count = 0;

	  	for( int i = 0 ; i < src.length() ; i++ ){
	  		delimIndex = splitString.indexOf(delim);
	  		if( delimIndex >= 0){

		  		preSplitString = splitString.substring( 0 , delimIndex );
	            splitString = splitString.substring( delimIndex+1 , splitString.length() );
		  		results.addElement(preSplitString);

		  		//System.out.println("i" + i);
		  		//System.out.println("delimIndex" + delimIndex);
		  		//System.out.println("splitString" + splitString);
		  		//System.out.println("preSplitString" + preSplitString);

	  		}


	  	}
	    if( src.lastIndexOf(delim) > 0 ){
	  		//System.out.println("src.substring( src.lastIndexOf(delim) , src.length()" + src.substring( src.lastIndexOf(delim)+1 , src.length()) );
	  		results.addElement( src.substring( src.lastIndexOf(delim)+1 , src.length() ) ) ;
	    }

	    String[] returnString = new String[results.size()];
	    results.copyInto(returnString);

	    for(int i = 0; i < returnString.length ; i++ ){
	        //System.out.println("i = " + returnString[i]);
	    }
		if( returnString.length == 0 ){
		  returnString = new String[1];
		  returnString[0] = src;
		}
	    return returnString;
	}

	/**
     * Dow 내용을 화면에 보여주기 위한 함수
	 * @param	_orgViewDow (String)	대상  문자열
	 * @return	String
     */
	public String viewDow(String _orgViewDow){
		return viewDow(_orgViewDow,"eng");
	}

	/**
     * Dow 내용을 화면에 보여주기 위한 함수
	 * @param	_orgViewDow (String)	대상  문자열
	 * @param	version (String)		버젼정보
	 * @return	String
     */
	public String viewDow(String _orgViewDow,String version){

			String orgViewDow = _orgViewDow;
			String viewDow = "";
			String viewKorDow = "";
			String viewEngDow = "";
			String checkDow = "";
			if( orgViewDow.trim().equals("") ){
				return orgViewDow;
			}
			//System.out.println("_orgViewDow = " + _orgViewDow);

			for(int kk=0 ; kk < orgViewDow.length(); kk++ ){
				checkDow = orgViewDow.substring(kk,kk+1);
				if(checkDow.equals("1")){
						 viewKorDow = "월";
						 viewEngDow = "MON";

				}
				if(checkDow.equals("2")){
					if( viewKorDow.equals("") ){
						 viewKorDow = "화";
						 viewEngDow = "TUE";
					}else{
						 viewKorDow = viewKorDow+"/화";
						 viewEngDow = viewEngDow+"/TUE";
					}
				}
				if(checkDow.equals("3")){
					if( viewKorDow.equals("") ){
						 viewKorDow = "수";
						 viewEngDow = "WED";
					}else{
						 viewKorDow = viewKorDow+"/수";
						 viewEngDow = viewEngDow+"/WED";
					}
				}
				if(checkDow.equals("4")){
					if( viewKorDow.equals("") ){
						 viewKorDow = "목";
						 viewEngDow = "THU";
					}else{
						 viewKorDow = viewKorDow+"/목";
						 viewEngDow = viewEngDow+"/THU";
					}
				}
				if(checkDow.equals("5")){
					if( viewKorDow.equals("") ){
						 viewKorDow = "금";
						 viewEngDow = "FRI";
					}else{
						 viewKorDow = viewKorDow+"/금";
						 viewEngDow = viewEngDow+"/FRI";
					}
				}
				if(checkDow.equals("6")){
					if( viewKorDow.equals("") ){
						 viewKorDow = "토";
						 viewEngDow = "SAT";
					}else{
						 viewKorDow = viewKorDow+"/토";
						 viewEngDow = viewEngDow+"/SAT";
					}
				}
				if(checkDow.equals("7")){
					if( viewKorDow.equals("") ){
						 viewKorDow = "일";
						 viewEngDow = "SUN";
					}else{
						 viewKorDow = viewKorDow+"/일";
						 viewEngDow = viewEngDow+"/SUN";
					}
				}
		    }

			//System.out.println("viewKorDow = " + viewKorDow);
			//System.out.println("viewEngDow = " + viewEngDow);

		    if( version.equals("kor") ){
		    	viewDow = viewKorDow;
		    }else{
		    	viewDow = viewEngDow;
			}

		    return viewDow;
	}

	/**
     * ENG MONTH를 가져온다.
	 * @param	sMonth (String)	대상  문자열
	 * @return	String
     */
	public String viewEngMonth(String sMonth){

		if( sMonth.equals("01") ){
			sMonth = "JAN";
		}else if( sMonth.equals("02") ){
			sMonth = "FEB";
		}else if( sMonth.equals("03") ){
			sMonth = "MAR";
		}else if( sMonth.equals("04") ){
			sMonth = "APR";
		}else if( sMonth.equals("05") ){
			sMonth = "MAY";
		}else if( sMonth.equals("06") ){
			sMonth = "JUN";
		}else if( sMonth.equals("07") ){
			sMonth = "JUL";
		}else if( sMonth.equals("08") ){
			sMonth = "AUG";
		}else if( sMonth.equals("09") ){
			sMonth = "SEP";
		}else if( sMonth.equals("10") ){
			sMonth = "OCT";
		}else if( sMonth.equals("11") ){
			sMonth = "NOV";
		}else if( sMonth.equals("12") ){
			sMonth = "DEC";
		}
		return sMonth;
	}
	
	/**
     * ENG MONTH를 가져온다.
	 * @param	sMonth (String)	대상  문자열
	 * @return	String
     */
	public static String viewEngMonth2(String sMonth){

		if( sMonth.equals("01") ){
			sMonth = "JAN";
		}else if( sMonth.equals("02") ){
			sMonth = "FEB";
		}else if( sMonth.equals("03") ){
			sMonth = "MAR";
		}else if( sMonth.equals("04") ){
			sMonth = "APR";
		}else if( sMonth.equals("05") ){
			sMonth = "MAY";
		}else if( sMonth.equals("06") ){
			sMonth = "JUN";
		}else if( sMonth.equals("07") ){
			sMonth = "JUL";
		}else if( sMonth.equals("08") ){
			sMonth = "AUG";
		}else if( sMonth.equals("09") ){
			sMonth = "SEP";
		}else if( sMonth.equals("10") ){
			sMonth = "OCT";
		}else if( sMonth.equals("11") ){
			sMonth = "NOV";
		}else if( sMonth.equals("12") ){
			sMonth = "DEC";
		}
		return sMonth;
	}

	/**
     * MONTH를 가져온다.
	 * @param	sMonth (String)	대상  문자열
	 * @return	String
     */
	public String getMonth(String sMonth){

		if( sMonth.equals("JAN") ){
			sMonth = "01";
		}else if( sMonth.equals("FEB") ){
			sMonth = "02";
		}else if( sMonth.equals("MAR") ){
			sMonth = "03";
		}else if( sMonth.equals("APR") ){
			sMonth = "04";
		}else if( sMonth.equals("MAY") ){
			sMonth = "05";
		}else if( sMonth.equals("JUN") ){
			sMonth = "06";
		}else if( sMonth.equals("JUL") ){
			sMonth = "07";
		}else if( sMonth.equals("AUG") ){
			sMonth = "08";
		}else if( sMonth.equals("SEP") ){
			sMonth = "09";
		}else if( sMonth.equals("OCT") ){
			sMonth = "10";
		}else if( sMonth.equals("NOV") ){
			sMonth = "11";
		}else if( sMonth.equals("DEC") ){
			sMonth = "12";
		}
		return sMonth;
	}

	/**
     *
	 *
	 * @return	String[]
     */
	public String[] getViewDate(String aDayOfWeek,String stToday){
		 String[] viewDate = new String[7] ;
		if(aDayOfWeek.equals("월")){
		 	viewDate[0] = getChangeDay(stToday,0);
		 	viewDate[1] = getChangeDay(stToday,1);
		 	viewDate[2] = getChangeDay(stToday,2);
		 	viewDate[3] = getChangeDay(stToday,3);
		 	viewDate[4] = getChangeDay(stToday,4);
		 	viewDate[5] = getChangeDay(stToday,5);
			viewDate[6] = getChangeDay(stToday,6);
		}else if(aDayOfWeek.equals("화")){
		 	viewDate[1] = getChangeDay(stToday,0);
		 	viewDate[2] = getChangeDay(stToday,1);
		 	viewDate[3] = getChangeDay(stToday,2);
		 	viewDate[4] = getChangeDay(stToday,3);
		 	viewDate[5] = getChangeDay(stToday,4);
		 	viewDate[6] = getChangeDay(stToday,5);
			viewDate[0] = getChangeDay(stToday,6);
		}else if(aDayOfWeek.equals("수")){
		 	viewDate[2] = getChangeDay(stToday,0);
		 	viewDate[3] = getChangeDay(stToday,1);
		 	viewDate[4] = getChangeDay(stToday,2);
		 	viewDate[5] = getChangeDay(stToday,3);
		 	viewDate[6] = getChangeDay(stToday,4);
		 	viewDate[0] = getChangeDay(stToday,5);
			viewDate[1] = getChangeDay(stToday,6);
		}else if(aDayOfWeek.equals("목")){
		 	viewDate[3] = getChangeDay(stToday,0);
		 	viewDate[4] = getChangeDay(stToday,1);
		 	viewDate[5] = getChangeDay(stToday,2);
		 	viewDate[6] = getChangeDay(stToday,3);
		 	viewDate[0] = getChangeDay(stToday,4);
		 	viewDate[1] = getChangeDay(stToday,5);
			viewDate[2] = getChangeDay(stToday,6);
		}else if(aDayOfWeek.equals("금")){
		 	viewDate[4] = getChangeDay(stToday,0);
		 	viewDate[5] = getChangeDay(stToday,1);
		 	viewDate[6] = getChangeDay(stToday,2);
		 	viewDate[0] = getChangeDay(stToday,3);
		 	viewDate[1] = getChangeDay(stToday,4);
		 	viewDate[2] = getChangeDay(stToday,5);
			viewDate[3] = getChangeDay(stToday,6);
		}else if(aDayOfWeek.equals("토")){
		 	viewDate[5] = getChangeDay(stToday,0);
		 	viewDate[6] = getChangeDay(stToday,1);
		 	viewDate[0] = getChangeDay(stToday,2);
		 	viewDate[1] = getChangeDay(stToday,3);
		 	viewDate[2] = getChangeDay(stToday,4);
		 	viewDate[3] = getChangeDay(stToday,5);
			viewDate[4] = getChangeDay(stToday,6);
		}else if(aDayOfWeek.equals("일")){
		 	viewDate[6] = getChangeDay(stToday,0);
		 	viewDate[0] = getChangeDay(stToday,1);
		 	viewDate[1] = getChangeDay(stToday,2);
		 	viewDate[2] = getChangeDay(stToday,3);
		 	viewDate[3] = getChangeDay(stToday,4);
		 	viewDate[4] = getChangeDay(stToday,5);
			viewDate[5] = getChangeDay(stToday,6);
		}else{
		 	viewDate[1] = "";
		 	viewDate[2] = "";
		 	viewDate[3] = "";
		 	viewDate[4] = "";
		 	viewDate[5] = "";
		 	viewDate[6] = "";
			viewDate[0] = "";
		}
		return viewDate;
	}

	public boolean equationMct(String dayMon1,String dayMon2,String ttime1, String ttime2, String ttime3){

		try{
			int[] monthDay = {31,31,59,90,120,151,181,212,253,283,314,334,365};

			String sDay1 = dayMon1.substring(0,2);
			String sDay2 = dayMon2.substring(0,2);


			String sMon1 = getMonth(dayMon1.substring(2,5));
			String sMon2 = getMonth(dayMon2.substring(2,5));

			String sTime1 = ttime1.substring(0,2)+ttime1.substring(3,5);
			String sTime2 = ttime2.substring(0,2)+ttime2.substring(3,5);
			
			String sDayChanged1 = "0";
			String sDayChanged2 = "0";
			int a3 = 0;
			int a4 = 0;
			if(ttime1.length() >= 9){
				sDayChanged1 = ttime1.substring(6,ttime1.length()-1);
				sDayChanged1 = trim(removeChar(sDayChanged1,"+"));
				sDayChanged1 = trim(removeChar(sDayChanged1,"-"));
				sDayChanged1 = trim(removeChar(sDayChanged1," "));
				if( trim(ttime1.substring(6,ttime1.length()-2)).equals("-") ){
					a3 = - Integer.parseInt(sDayChanged1);
				}else{
					a3 = Integer.parseInt(sDayChanged1);
				}
			}
			if(ttime3.length() >= 9){
				sDayChanged2 = trim(ttime3.substring(6,ttime3.length()-1));
				sDayChanged2 = trim(removeChar(sDayChanged2,"+"));
				sDayChanged2 = trim(removeChar(sDayChanged2,"-"));
				sDayChanged2 = trim(removeChar(sDayChanged2," "));
				if( trim(ttime3.substring(6,ttime3.length()-2)).equals("-") ){
					a4 = - Integer.parseInt(sDayChanged2);
				}else{
					a4 = Integer.parseInt(sDayChanged2);
				}
			}

			int a1 = (Integer.parseInt(sDay2)+monthDay[Integer.parseInt(sMon2)]) 
			         - ( Integer.parseInt(sDay1)+monthDay[Integer.parseInt(sMon1)]) 
			         - a3 - a4 ;
			         
			int c1 = 0;         
			if( a1 > 0 ){
				c1 = Integer.parseInt(sTime2)*2400 - Integer.parseInt(sTime1);
			}else if( a1 == 0 ){
				c1 = Integer.parseInt(sTime2) - Integer.parseInt(sTime1);
			}else{
				c1 = 0;
			}

			if( c1 > 400 ){
				return true;
			}else{
				return false;
			}
		}catch(Exception e){
			//e.printStackTrace();
			System.out.println("ComUtil:5422");
			return false;
		}

	}

	public boolean equationMct(String dayMon1,String dayMon2,String ttime1, String ttime2){

		try{
			int[] monthDay = {31,31,59,90,120,151,181,212,253,283,314,334,365};
		
			String sDay1 = dayMon1.substring(0,2);
			String sDay2 = dayMon2.substring(0,2);

			String sMon1 = getMonth(dayMon1.substring(2,5));
			String sMon2 = getMonth(dayMon2.substring(2,5));

			String sTime1 = ttime1.substring(0,2)+ttime1.substring(3,5);
			String sTime2 = ttime2.substring(0,2)+ttime2.substring(3,5);

			String sDayChanged1 = "0";
			String sDayChanged2 = "0";
			         
			int a3 = 0;
			int a4 = 0;
			if(ttime1.length() >= 9){
				sDayChanged1 = ttime1.substring(6,ttime1.length()-1);
				sDayChanged1 = trim(removeChar(sDayChanged1,"+"));
				sDayChanged1 = trim(removeChar(sDayChanged1,"-"));
				sDayChanged1 = trim(removeChar(sDayChanged1," "));
				if( trim(ttime1.substring(6,ttime1.length()-2)).equals("-") ){
					a3 = - Integer.parseInt(sDayChanged1);
				}else{
					a3 = Integer.parseInt(sDayChanged1);
				}
			}
			if(ttime2.length() >= 9){
				sDayChanged2 = trim(ttime2.substring(6,ttime2.length()-1));
				sDayChanged2 = trim(removeChar(sDayChanged2,"+"));
				sDayChanged2 = trim(removeChar(sDayChanged2,"-"));
				sDayChanged2 = trim(removeChar(sDayChanged2," "));
				if( trim(ttime2.substring(6,ttime2.length()-2)).equals("-") ){
					a4 = - Integer.parseInt(sDayChanged2);
				}else{
					a4 = Integer.parseInt(sDayChanged2);
				}
			}
			int a1 = (Integer.parseInt(sDay2)+monthDay[Integer.parseInt(sMon2)]) 
			         - ( Integer.parseInt(sDay1)+monthDay[Integer.parseInt(sMon1)]) 
			         - a3 - a4 ;
			         
			int c1 = 0;         
			if( a1 > 0 ){
				c1 = Integer.parseInt(sTime2)*2400 - Integer.parseInt(sTime1);
			}else if( a1 == 0 ){
				c1 = Integer.parseInt(sTime2) - Integer.parseInt(sTime1);
			}else{
				c1 = 0;
			}


			if( c1 > 400 ){
				return true;
			}else{
				return false;
			}
		}catch(Exception e){
			//e.printStackTrace();
			System.out.println("ComUtil:5489");
			return false;
		}

	}

	/**
     * Full Name과 Code가 같이 보여질경우()에 의해 코드값이 쌓여있을경우  Code만 따로 가져온다.
     *   예:  Korea(KOR)
     * 			return 값 =>  KOR
	 * @param	src (String)	대상  문자열
	 * @return	String
     */
	public static String getCodeName(String src) throws Exception
	{
		String resultString = "";

		int firstIndex	 = src.indexOf("(");
		int lastIndex	 = src.lastIndexOf(")");

		if( firstIndex > 0 && lastIndex > 0 &&  lastIndex > firstIndex ){
			resultString = src.substring(firstIndex+1,lastIndex);
		}else{
			resultString = src;
		}
		
		
		int firstIndex1	 = src.indexOf("[");
		int lastIndex1	 = src.lastIndexOf("]");

		if( firstIndex1 > 0 && lastIndex1 > 0 &&  lastIndex1 > firstIndex1 ){
			resultString = src.substring(firstIndex1+1,lastIndex1);
		}else{
			resultString = src;
		}

		return resultString;
	}

	/**
     * 6자리로 된 FLT no를 0으로 시작하면 제거한다.
     * @param			String					FLT NO 값.
     * @return			String					첫번째 0가 제거된 변환된 FLT NO 값
     */
    public  static String toDelZeroFltNo(String flt_no) {
		flt_no = flt_no.toUpperCase();
		 
		String noFltHead		= flt_no.substring(0,2);
		String noFltTail		= flt_no.substring(2, flt_no.length()).trim();
		
		if(noFltTail.length() == 4){
			if(noFltTail.substring(0,1).equals("0"))
				noFltTail = noFltTail.substring(1,4);
		}
		
		return noFltHead.toString() + noFltTail;
    }
    
    /**
	 * <pre>
	 * Descriptions : encode는 space를 '+'로 바꿈으로 
	 * 					'+'를 '%20'으로 바꿔주어야만 한다.
	 * </pre>
	 * @param String
	 * @return none 
	 */	
	public static String encode(String param) {
		String encoding = "";
		try{
			encoding = URLEncoder.encode(param,"UTF-8");
		}catch(Exception e){
		}   	
		   StringTokenizer st = new StringTokenizer(encoding, "+"); 
		
		   StringBuffer returnString = new StringBuffer();
		   int tokenCnt = st.countTokens();
		   int inx = 1;
		    
		   while (st.hasMoreTokens() ) {
		        
		       returnString.append(st.nextToken());
		        
		       if ( inx != tokenCnt )
		           returnString.append("%20");
		            
		       inx++;
		   }
		    
		   return returnString.toString();
		
			 
	}
	
	/**
     * 특수문자를  없애기
     */
    public static String replaceSpeCode(String orgstr)
    {
        int    len        = orgstr.length();
        String rplStr     = "";
        String currStr    = "";
        String replaceStr = "";
        int    i = 0;

        for( i = 0;i<len;i++)
        {
            currStr = orgstr.substring(i,i+1);
            if( currStr.equals("~"))
            {
                rplStr = "";
            }else if( currStr.equals("!"))
            {
                rplStr = "";
            }else if( currStr.equals("@"))
            {
                rplStr = "";
            }else if( currStr.equals("#"))
            {
                rplStr = "";
            }else if( currStr.equals("$"))
            {
                rplStr = "";
            }else if( currStr.equals("%"))
            {
                rplStr = "";
            }else if( currStr.equals("^"))
            {
                rplStr = "";
            }else if( currStr.equals("&"))
            {
                rplStr = "";

            }else if( currStr.equals("*"))
            {
                rplStr = "";

            }else if( currStr.equals("("))
            {
                rplStr = "";

            }else if( currStr.equals(")"))
            {
                rplStr = "";

            }else if( currStr.equals(";"))
            {
                rplStr = "";

            }else if( currStr.equals(":"))
            {
                rplStr = "";

            }else if( currStr.equals("'"))
            {
                rplStr = "";

            }else if( currStr.equals(","))
            {
                rplStr = "";

            }else if( currStr.equals("?"))
            {
                rplStr = "";

            }else if( currStr.equals("/"))
            {
                rplStr = "";

            }else if( currStr.equals("\\"))
            {
                rplStr = "";

            }
            
             else
            {
                rplStr = currStr ;
            }
            replaceStr += rplStr ;
        }
        return replaceStr;
      }
    
    
    
    /**
     * 특수문자를  없애기
     */
    public static String replaceFlashLink(String orgstr)
    {
        int    len        = orgstr.length();
        String rplStr     = "";
        String currStr    = "";
        String replaceStr = "";
        int    i = 0;

        for( i = 0;i<len;i++)
        {
            currStr = orgstr.substring(i,i+1);
            if( currStr.equals("~"))
            {
                rplStr = "";
            }else if( currStr.equals("!"))
            {
                rplStr = "";
            }else if( currStr.equals("@"))
            {
                rplStr = "";
            }else if( currStr.equals("#"))
            {
                rplStr = "";
            }else if( currStr.equals("$"))
            {
                rplStr = "";
            }else if( currStr.equals("%"))
            {
                rplStr = "";
            }else if( currStr.equals("^"))
            {
                rplStr = "";
            }else if( currStr.equals("&"))
            {
                rplStr = "";

            }else if( currStr.equals("*"))
            {
                rplStr = "";

            }else if( currStr.equals("("))
            {
                rplStr = "";

            }else if( currStr.equals(")"))
            {
                rplStr = "";

            }else if( currStr.equals(";"))
            {
                rplStr = "";

            }else if( currStr.equals(":"))
            {
                rplStr = "";

            }else if( currStr.equals("'"))
            {
                rplStr = "";

            }else if( currStr.equals(","))
            {
                rplStr = "";

            }else if( currStr.equals("?"))
            {
                rplStr = "";

            }else if( currStr.equals("\\"))
            {
                rplStr = "";

            }            
             else
            {
                rplStr = currStr ;
            }
            replaceStr += rplStr ;
        }
        return replaceStr;
      }
    
    
    public static String filter(String value) {
    	if (value == null) {
    	return null;
    	}
    	value = replace(value, "<SCRIPT>", " ");
    	value = replace(value, "SCRIPT", " ");
    	value = replace(value, "<script>", " ");
    	value = replace(value, "script", " ");
    	value = replace(value, "Script", " ");
    	value = replace(value, "sCript", " ");
    	value = replace(value, "./", "");
    	value = replace(value, "../", "");
    	value = replace(value, "//", "");
    	value = replace(value, ".//", "");
		
    	StringBuffer result = new StringBuffer(value.length());
    	for (int i=0; i<value.length(); ++i) {
    		switch (value.charAt(i)) {
	    		case '<':
					result.append("&lt;");
					break;
				case '>':
					result.append("&gt;");
					break;
				case '"':
					result.append("&quot;");
					break;
				case '\'':
					result.append("’");
					break;
				case '%':
					result.append("&#37;");
					break;
				case ';':
					result.append("&#59;");
					break;
				case '(':
					result.append("[");  
					break;
				case ')':
					result.append("]");
					break;
				case '&':
					result.append("&amp;");
					break;
				case '+':
					result.append("＋");//특수문자표 값
					break;
				default:
					result.append(value.charAt(i));
					break;
    		}
    	}
    	return result.toString();
    }
    
    
    public static String paramFilter(String strValue) {
    	
    	if (strValue == null) {
        	return null;
        }else{
    	
	    	strValue = filter(null2str(strValue));
	    	
	    	if (!"kor".equals(strValue.toLowerCase()) && !"eng".equals(strValue.toLowerCase()) && !"jpn".equals(strValue.toLowerCase()) && !"chn".equals(strValue.toLowerCase()) ){
	    		strValue = "";
	    	}
	    	
	    	return strValue.toString();
        }
    }
    
    public static String filter3(String value) {
    	value = replace(replace(replace(replace(value,"&lt;","<"),"&gt;",">"),"&amp;nbsp&#59;","&nbsp;"),"&amp;amp&#59;","&");
    	return value;
    }
    
    public static int filter(int value) {
    	
    	String strValue = "";
    	strValue = replace(value+"", "<SCRIPT>", " ");
    	strValue = replace(value+"", "SCRIPT", " ");
    	strValue = replace(value+"", "<script>", " ");
    	strValue = replace(value+"", "script", " ");
    	strValue = replace(value+"", "Script", " ");
    	strValue = replace(value+"", "sCript", " ");
    	
    	StringBuffer result = new StringBuffer(strValue.length());
    	for (int i=0; i<strValue.length(); ++i) {
    		switch (strValue.charAt(i)) {
	    		case '<':
					result.append("&lt;");
					break;
				case '>':
					result.append("&gt;");
					break;
				case '"':
					result.append("&quot;");
					break;
				case '\'':
					result.append("’");
					break;
				case '%':
					result.append("&#37;");
					break;
				case ';':
					result.append("&#59;");
					break;
				case '(':
					result.append("["); 
					break;
				case ')':
					result.append("]");
					break;
				case '&':
					result.append("&amp;");
					break;
				case '+':
					result.append("＋");//특수문자표 값
					break;
				default:
					result.append(strValue.charAt(i));
					break;
    		}
    	}
    	return Integer.parseInt(strValue);
    }
    
    public static double filter(double value) {
    	
    	String strValue = "";
    	strValue = replace(value+"", "<SCRIPT>", " ");
    	strValue = replace(value+"", "SCRIPT", " ");
    	strValue = replace(value+"", "<script>", " ");
    	strValue = replace(value+"", "script", " ");
    	strValue = replace(value+"", "Script", " ");
    	strValue = replace(value+"", "sCript", " ");
    	
    	StringBuffer result = new StringBuffer(strValue.length());
    	for (int i=0; i<strValue.length(); ++i) {
    		switch (strValue.charAt(i)) {
	    		case '<':
					result.append("&lt;");
					break;
				case '>':
					result.append("&gt;");
					break;
				case '"':
					result.append("&quot;");
					break;
				case '\'':
					result.append("’");
					break;
				case '%':
					result.append("&#37;");
					break;
				case ';':
					result.append("&#59;");
					break;
				case '(':
					result.append("["); 
					break;
				case ')':
					result.append("]");
					break;
				case '&':
					result.append("&amp;");
					break;
				case '+':
					result.append("＋");//특수문자표 값
					break;
				default:
					result.append(strValue.charAt(i));
					break;
    		}
    	}
    	return Double.parseDouble(strValue);
    }
    
    
    public static long filter(long value) {
    	
    	String strValue = "";
    	strValue = replace(value+"", "<SCRIPT>", " ");
    	strValue = replace(value+"", "SCRIPT", " ");
    	strValue = replace(value+"", "<script>", " ");
    	strValue = replace(value+"", "script", " ");
    	strValue = replace(value+"", "Script", " ");
    	strValue = replace(value+"", "sCript", " ");
    	
    	StringBuffer result = new StringBuffer(strValue.length());
    	for (int i=0; i<strValue.length(); ++i) {
    		switch (strValue.charAt(i)) {
	    		case '<':
					result.append("&lt;");
					break;
				case '>':
					result.append("&gt;");
					break;
				case '"':
					result.append("&quot;");
					break;
				case '\'':
					result.append("’");
					break;
				case '%':
					result.append("&#37;");
					break;
				case ';':
					result.append("&#59;");
					break;
				case '(':
					result.append("["); 
					break;
				case ')':
					result.append("]");
					break;
				case '&':
					result.append("&amp;");
					break;
				case '+':
					result.append("＋");//특수문자표 값
					break;
				default:
					result.append(strValue.charAt(i));
					break;
    		}
    	}
    	return Long.parseLong(strValue);
    }
    
    public static float filter(float value) {
    	
    	String strValue = "";
    	strValue = replace(value+"", "<SCRIPT>", " ");
    	strValue = replace(value+"", "SCRIPT", " ");
    	strValue = replace(value+"", "<script>", " ");
    	strValue = replace(value+"", "script", " ");
    	strValue = replace(value+"", "Script", " ");
    	strValue = replace(value+"", "sCript", " ");
    	
    	StringBuffer result = new StringBuffer(strValue.length());
    	for (int i=0; i<strValue.length(); ++i) {
    		switch (strValue.charAt(i)) {
	    		case '<':
					result.append("&lt;");
					break;
				case '>':
					result.append("&gt;");
					break;
				case '"':
					result.append("&quot;");
					break;
				case '\'':
					result.append("’");
					break;
				case '%':
					result.append("&#37;");
					break;
				case ';':
					result.append("&#59;");
					break;
				case '(':
					result.append("["); 
					break;
				case ')':
					result.append("]");
					break;
				case '&':
					result.append("&amp;");
					break;
				case '+':
					result.append("＋");//특수문자표 값
					break;
				default:
					result.append(strValue.charAt(i));
					break;
    		}
    	}
    	return Float.parseFloat(strValue);
    }
    
    public static String sqlFilter(String sql_value) {
		if (sql_value == null) {
			return null;
		}
		
		String sql_val = "";

		sql_val = sql_value;
		sql_val = replace(sql_val, ";", " ");
		sql_val = replace(sql_val, "+", " ");
		sql_val = replace(sql_val, "print ", " ");
		sql_val = replace(sql_val, "set ", " ");
		sql_val = replace(sql_val, "PRINT ", " ");
		sql_val = replace(sql_val, "SET ", " ");
		sql_val = replace(sql_val, "%", " ");
		sql_val = replace(sql_val, "<script>", " ");
		sql_val = replace(sql_val, "<SCRIPT>", " ");
		sql_val = replace(sql_val, "script", " ");
		sql_val = replace(sql_val, "SCRIPT", " ");
		sql_val = replace(sql_val, " or ", " ");
		sql_val = replace(sql_val, " union ", " ");
		sql_val = replace(sql_val, " and ", " ");
		sql_val = replace(sql_val, " insert ", " ");
		sql_val = replace(sql_val, " openrowset ", " ");
		sql_val = replace(sql_val, " OR ", " ");
		sql_val = replace(sql_val, " UNION ", " ");
		sql_val = replace(sql_val, " AND ", " ");
		sql_val = replace(sql_val, " INSERT ", " ");
		sql_val = replace(sql_val, "OPENROWSET ", " ");
		sql_val = replace(sql_val, "--", " ");
		sql_val = replace(sql_val, "/*", " ");
		sql_val = replace(sql_val, "*/", " ");
		sql_val = replace(sql_val, "xp_ ", " ");
		sql_val = replace(sql_val, "decare", " ");
		sql_val = replace(sql_val, "select", " ");
		sql_val = replace(sql_val, "update", " ");
		sql_val = replace(sql_val, "delete", " ");
		sql_val = replace(sql_val, "shutdown", " ");
		sql_val = replace(sql_val, "drop", " ");
		sql_val = replace(sql_val, "XP_", " ");
		sql_val = replace(sql_val, "DECLARE", " ");
		sql_val = replace(sql_val, "SELECT ", " ");
		sql_val = replace(sql_val, "UPDATE ", " ");
		sql_val = replace(sql_val, "DELETE ", " ");
		sql_val = replace(sql_val, "SHUTDOWN ", " ");
		sql_val = replace(sql_val, "DROP ", " ");

		return sql_val;
    }
    
    
    public static String sqlFilter2(String sql_value) {
		if (sql_value == null) {
			return null;
		}
		
		String sql_val = "";

		sql_val = sql_value;
		sql_val = replace(sql_val, ";", " ");
		sql_val = replace(sql_val, "+", " ");
		sql_val = replace(sql_val, "print ", " ");
		sql_val = replace(sql_val, "set ", " ");
		sql_val = replace(sql_val, "PRINT ", " ");
		sql_val = replace(sql_val, "SET ", " ");
		//sql_val = replace(sql_val, "%", " ");
		sql_val = replace(sql_val, "<script>", " ");
		sql_val = replace(sql_val, "<SCRIPT>", " ");
		sql_val = replace(sql_val, "script", " ");
		sql_val = replace(sql_val, "SCRIPT", " ");
		sql_val = replace(sql_val, " or ", " ");
		sql_val = replace(sql_val, " union ", " ");
		sql_val = replace(sql_val, " and ", " ");
		sql_val = replace(sql_val, " insert ", " ");
		sql_val = replace(sql_val, " openrowset ", " ");
		sql_val = replace(sql_val, " OR ", " ");
		sql_val = replace(sql_val, " UNION ", " ");
		sql_val = replace(sql_val, " AND ", " ");
		sql_val = replace(sql_val, " INSERT ", " ");
		sql_val = replace(sql_val, "OPENROWSET ", " ");
		sql_val = replace(sql_val, "--", " ");
		sql_val = replace(sql_val, "/*", " ");
		sql_val = replace(sql_val, "*/", " ");
		sql_val = replace(sql_val, "xp_ ", " ");
		sql_val = replace(sql_val, "decare", " ");
		sql_val = replace(sql_val, "select", " ");
		sql_val = replace(sql_val, "update", " ");
		sql_val = replace(sql_val, "delete", " ");
		sql_val = replace(sql_val, "shutdown", " ");
		sql_val = replace(sql_val, "drop", " ");
		sql_val = replace(sql_val, "XP_", " ");
		sql_val = replace(sql_val, "DECLARE", " ");
		sql_val = replace(sql_val, "SELECT ", " ");
		sql_val = replace(sql_val, "UPDATE ", " ");
		sql_val = replace(sql_val, "DELETE ", " ");
		sql_val = replace(sql_val, "SHUTDOWN ", " ");
		sql_val = replace(sql_val, "DROP ", " ");

		return sql_val;
    }
    
    
    public static byte [] genMD5(String str) { 
    	
    	byte [] buffer = null; 
    	try 
    	{ 
    		// Obtain a message digest object. 
    		MessageDigest md = MessageDigest.getInstance("MD5"); 
    		
    		// Calculate the digest for the given file. 
    		md.update(str.getBytes()); 
    		// computing digest 
    		buffer = md.digest(); 
    		md.reset(); 
    	} 
    	catch (NoSuchAlgorithmException ns) { 
    		System.out.println("MD5 ERROR..."); 
    	} 

    	return buffer; 
    }
    
    public static byte [] genStringToMD5(String str) { 
    	
    	byte [] buffer = null; 
    	try 
    	{ 
    		// Obtain a message digest object. 
    		MessageDigest md = MessageDigest.getInstance("MD5"); 
    		
    		// Calculate the digest for the given file. 
    		//md.update(str.getBytes()); 
    		// computing digest 
    		buffer = md.digest(); 
    		md.reset(); 
    	} 
    	catch (NoSuchAlgorithmException ns) { 
    		System.out.println("MD5 ERROR..."); 
    	} 

    	return buffer; 
    }
    
    public static String PasswordEncript(String password) 
    { 
	    BASE64Encoder b64e = new BASE64Encoder(); 
	
	    MessageDigest md; 
	    String md5Passwd = null; 
	
	    try 
	    { 
	    
		    md = MessageDigest.getInstance( "MD5" ); 
		    md.update( password.getBytes() ); 
		
		    byte [] raw = md.digest(); 
		    //System.out.println( "MessageDigest : +" + raw + "+" ); 
		    md5Passwd = b64e.encode( raw ); 
		    //System.out.println( "Base64Encode : +" + md5Passwd + "+" ); 
		
	    } 
	    catch ( NoSuchAlgorithmException e ) 
	    { 
		    //e.printStackTrace();
	    	System.out.println("ComUtil:6188");
		    md5Passwd = null; 
	    } 
	
	    return md5Passwd; 
	
    } 
    
    public static byte[] md5Decode(String strDecode) {
        
        BASE64Decoder base64Decoder = new BASE64Decoder();
        ByteArrayInputStream bin = new ByteArrayInputStream(strDecode.getBytes());
        ByteArrayOutputStream bout = new ByteArrayOutputStream();
        byte[] buf = null;

        try {		
            base64Decoder.decodeBuffer(bin, bout);
        } catch(Exception e) {
            System.out.println("Exception");
            //e.printStackTrace();
            System.out.println("ComUtil:6208");
        }

        buf = bout.toByteArray();

        return buf;

    }
	
	
	
	
	
	
	
	
	
	
	
	
	private static String[] HEXSTR = {
		"00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0a", "0b", "0c", "0d", "0e", "0f",
		"10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "1a", "1b", "1c", "1d", "1e", "1f",
		"20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "2a", "2b", "2c", "2d", "2e", "2f",
		"30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "3a", "3b", "3c", "3d", "3e", "3f",
		"40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "4a", "4b", "4c", "4d", "4e", "4f",
		"50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "5a", "5b", "5c", "5d", "5e", "5f",
		"60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "6a", "6b", "6c", "6d", "6e", "6f",
		"70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "7a", "7b", "7c", "7d", "7e", "7f",
		"80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "8a", "8b", "8c", "8d", "8e", "8f",
		"90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "9a", "9b", "9c", "9d", "9e", "9f",
		"a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "aa", "ab", "ac", "ad", "ae", "af",
		"b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "ba", "bb", "bc", "bd", "be", "bf",
		"c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "ca", "cb", "cc", "cd", "ce", "cf",
		"d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "da", "db", "dc", "dd", "de", "df",
		"e0", "e1", "e2", "e3", "e4", "e5", "e6", "e7", "e8", "e9", "ea", "eb", "ec", "ed", "ee", "ef",
		"f0", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "fa", "fb", "fc", "fd", "fe", "ff"
	};

	public static String toHexString(byte[] data)
	{
		return toHexString(data, 0, data.length);
	}

	public static String toHexString(byte[] data, int start, int length)
	{
		StringBuffer sb = new StringBuffer(length * 2);
		for (int i = start, iend = start + length; i < iend; i++)
			sb.append(HEXSTR[(data[i] + 256) % 256]);
		return sb.toString();
	}

	private static byte[] getBytes(byte[] data, int length, byte defaultValue)
	{
		byte[] tmp = new byte[length];
		Arrays.fill(tmp, defaultValue);
		System.arraycopy(data, 0, tmp, 0, Math.min(length, data.length));
		return tmp;
	}

	public static byte[] encrypt(byte[] data)
	{
		try
		{
			MessageDigest md = MessageDigest.getInstance("SHA-512");
			md.update(data);
			return md.digest();
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			System.out.println("ComUtil:6293");
			return null;
		}
	}

	public static String hashToHex(String str, String charset)
	{
		try
		{
			return toHexString(encrypt(str.getBytes(charset)));
		}
		catch (Exception e)
		{
			return null;
		}
	}

	public static String hashToBase64(String str, String charset)
	{
		try
		{
			return new BASE64Encoder().encode(encrypt(str.getBytes(charset))).replaceAll("\r|\n","");
		}
		catch (Exception e)
		{
			return null;
		}
	}
	
	public static String getDigest(String pwd) 
    {
		try
		{
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-512");
	        byte[] pb = messageDigest.digest(pwd.getBytes());
	        StringBuffer sb = new StringBuffer(pb.length << 1);
	        for (int i=0, iend=pb.length; i<iend ; i++)
	        {
	            int val = (pb[i] + 256) & 0xff;
	            sb.append(Integer.toHexString(val>>4)).append(Integer.toHexString(val & 0xf));
	        }

	        return sb.toString();
		}
		catch(Exception e)
		{
			//e.printStackTrace();
			System.out.println("ComUtil:6340");
			return null;
		}
    }
	
	
	
	public static String filter2(String value) {
    	if (value == null) {
    	return null;
    	}
    	
    	value = replace(value, "<br>", "<br>");
    	value = replace(value, "&nbsp;", "&nbsp;");
    	
    	return value.toString();
    }
    
	
	public static String filter4(String value) {
    	if (value == null) {
    	return null;
    	}
    	value = replace(value, "<SCRIPT>", " ");
    	value = replace(value, "SCRIPT", " ");
    	value = replace(value, "<script>", " ");
    	value = replace(value, "script", " ");
    	value = replace(value, "Script", " ");
    	value = replace(value, "sCript", " ");
    	value = replace(value, "./", "");
    	value = replace(value, "../", "");
    	value = replace(value, "//", "");
    	value = replace(value, ".//", "");
		
    	StringBuffer result = new StringBuffer(value.length());
    	for (int i=0; i<value.length(); ++i) {
    		switch (value.charAt(i)) {
	    		case '<':
					result.append("");
					break;
				case '>':
					result.append("");
					break;
				case '"':
					result.append("");
					break;
				case '%':
					result.append("");
					break;
				case ';':
					result.append("");
					break;
				case '+':
					result.append("");//특수문자표 값
					break;
				default:
					result.append(value.charAt(i));
					break;
    		}
    	}
    	return result.toString();
    }
	
	
	public static String filter5(String value) {
    	if (value == null) {
    	return null;
    	}
    	value = replace(value, "<SCRIPT>", " ");
    	value = replace(value, "SCRIPT", " ");
    	value = replace(value, "<script>", " ");
    	value = replace(value, "script", " ");
    	value = replace(value, "Script", " ");
    	value = replace(value, "sCript", " ");
    	value = replace(value, "./", "");
    	value = replace(value, "../", "");
    	value = replace(value, ".//", "");
		
    	StringBuffer result = new StringBuffer(value.length());
    	for (int i=0; i<value.length(); ++i) {
    		switch (value.charAt(i)) {
	    		case '<':
					result.append("");
					break;
				case '>':
					result.append("");
					break;
				default:
					result.append(value.charAt(i));
					break;
    		}
    	}
    	return result.toString();
    }
	
	
	
	public static String HmacStringAsB64(String value){
		
		String result = value; 
		
		try{
			result = CryptoProvider.HmacStringAsB64(value, "KAL_HMAC");
		}catch(Exception ex){
			result = value;
		}
		
		return result;
	} 
	
	
	public static String EncryptStringAsHex(String val_str){

	    String result = "";
	    
	    val_str = null2str(val_str);
	    
	    if (!"".equals(val_str)){

		    try{
		      result = CryptoProvider.EncryptStringAsHex(val_str, "KAL_CGO2");
		    }catch(Exception ex){
		    	ex.printStackTrace();
		      result = val_str;
		    }
	    }else{
	    	result = "";
	    }

	    return result;
	  }
	
	
	public static String DecryptHexAsString(String val_str){

	    String result = "";
	    
	    val_str = null2str(val_str);
	    
	    if (!"".equals(val_str)){

		    try{
		      result = CryptoProvider.DecryptHexAsString(val_str, "KAL_CGO2");
		    }catch(Exception ex){
		      result = val_str;
		    }
	    }else{
		   	result = "";
		}

		return result;
	    
	  }
	
	
	public static String VocEncryptEml(String val_str){

	    String result = "";
	    
	    val_str = null2str(val_str);
	    
	    if (!"".equals(val_str)){

		    try{
		      result = CryptoProvider.EncryptStringAsHex(val_str, "KAL_EML");
		    }catch(Exception ex){
		      result = val_str;
		    }
	    }else{
	    	result = "";
	    }

	    return result;
	  }
	
	public static String VocEncryptTel(String val_str){

	    String result = "";
	    
	    val_str = null2str(val_str);
	    
	    if (!"".equals(val_str)){

		    try{
		      result = CryptoProvider.EncryptStringAsHex(val_str, "KAL_TEL");
		    }catch(Exception ex){
		      result = val_str;
		    }
	    }else{
	    	result = "";
	    }

	    return result;
	  }
	
	public static String VocDecryptHexAsString(String val_str){

	    String result = "";
	    
	    val_str = null2str(val_str);
	    
	    if (!"".equals(val_str)){

		    try{
		      result = CryptoProvider.DecryptHexAsString(val_str, "KAL_CGO2");
		    }catch(Exception ex){
		      result = val_str;
		    }
	    }else{
		   	result = "";
		}

		return result;
	    
	  }
	
    
}
