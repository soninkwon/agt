package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="userInfoDomain")
public class UserInfoDomain {
	
	
	private String user_id        = "";
	private String user_nm        = "";
	private String fwdr_cd        = "";
	private String user_sha       = "";
	private String user_email     = "";
	private String user_phone1    = "";
	private String user_phone2    = "";
	private String email_yn       = "";
	private String agree_type     = "";
	private String sha_update_dtm = "";
	private String reg_dtm        = "";
	
	@RemoteProperty
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	@RemoteProperty
	public String getUser_nm() {
		return user_nm;
	}
	public void setUser_nm(String user_nm) {
		this.user_nm = user_nm;
	}
	
	@RemoteProperty
	public String getFwdr_cd() {
		return fwdr_cd;
	}
	public void setFwdr_cd(String fwdr_cd) {
		this.fwdr_cd = fwdr_cd;
	}
	
	@RemoteProperty
	public String getUser_sha() {
		return user_sha;
	}
	public void setUser_sha(String user_sha) {
		this.user_sha = user_sha;
	}
	
	@RemoteProperty
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	
	@RemoteProperty
	public String getUser_phone1() {
		return user_phone1;
	}
	public void setUser_phone1(String user_phone1) {
		this.user_phone1 = user_phone1;
	}
	
	@RemoteProperty
	public String getUser_phone2() {
		return user_phone2;
	}
	public void setUser_phone2(String user_phone2) {
		this.user_phone2 = user_phone2;
	}
	
	@RemoteProperty
	public String getEmail_yn() {
		return email_yn;
	}
	public void setEmail_yn(String email_yn) {
		this.email_yn = email_yn;
	}
	
	@RemoteProperty
	public String getAgree_type() {
		return agree_type;
	}
	public void setAgree_type(String agree_type) {
		this.agree_type = agree_type;
	}
	
	@RemoteProperty
	public String getSha_update_dtm() {
		return sha_update_dtm;
	}
	public void setSha_update_dtm(String sha_update_dtm) {
		this.sha_update_dtm = sha_update_dtm;
	}
	
	@RemoteProperty
	public String getReg_dtm() {
		return reg_dtm;
	}
	public void setReg_dtm(String reg_dtm) {
		this.reg_dtm = reg_dtm;
	}

	
	
	
	
}