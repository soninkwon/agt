package com.koreanair.cargo.domain;

import java.io.IOException;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;
import org.springframework.web.multipart.MultipartFile;

@DataTransferObject(type="bean", javascript="vocTypeDomain")

public class VocTypeDomain {
	
	private String voc_type_cd       = "";
	private String voc_type_desc       = "";
	private String voc_type_lang      = "";
	
	public String getVoc_type_cd() {
		return voc_type_cd;
	}
	public void setVoc_type_cd(String voc_type_cd) {
		this.voc_type_cd = voc_type_cd;
	}
	public String getVoc_type_desc() {
		return voc_type_desc;
	}
	public void setVoc_type_desc(String voc_type_desc) {
		this.voc_type_desc = voc_type_desc;
	}
	public String getVoc_type_lang() {
		return voc_type_lang;
	}
	public void setVoc_type_lang(String voc_type_lang) {
		this.voc_type_lang = voc_type_lang;
	}

	
	
}
