package  com.koreanair.cargo.service;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.text.*;

import java.sql.Timestamp;
import javax.servlet.*;
import javax.servlet.http.*;
import java.net.*;
import java.lang.reflect.Array;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.security.*;
import sun.misc.*;

import sun.misc.BASE64Encoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.safenet.datasecure.*;
import com.safenet.datasecure.crypto.*;
 


/**
 ***********************************************
 * @sourceName  : ComUtil.java
 * ---------------------------------------------
 * DESCRIPTION  : eCustomer 공통 유틸
 ***********************************************
 * DATE         AUTHOR          HISTORY
 * ---------------------------------------------
 * 2004/06/18	JYJEON			Create
 * 2004/07/18	KHJ				parseUldInfo(String str),parseUldInfo(String str, int len) 추가
 * 2004/07/18	KHJ				parseUldCount(String str) 추가
 * 2004/07/09	JYJEON			replaceAddString(str1, int2, str3) 추가
 * 2005/03/30	KHJ				toDelZeroFltNo 추가
 * 2005/03/30	JJY				substringByteUTF 추가
 ***********************************************
 */
public interface ComUtilService {
	
	public String toHexString(byte[] data);
	public  String toHexString(byte[] data, int start, int length);
	public  byte[] encrypt(byte[] data);
	public  String hashToHex(String str, String charset);
	public  String hashToBase64(String str, String charset);
	public  String getDigest(String pwd) ;
	public  String filter2(String value) ;
    public  String filter4(String value) ;
	public  String filter5(String value) ;
	public  String HmacStringAsB64(String value);
	public  String EncryptStringAsHex(String val_str);
	public  String DecryptHexAsString(String val_str);
	public  String VocEncryptEml(String val_str);
	public  String VocEncryptTel(String val_str);
	public  String VocDecryptHexAsString(String val_str);
    
}
