package com.koreanair.cargo.common.dwr.export;

import java.util.List;
import java.util.Map;

import com.koreanair.cargo.domain.ExportReqDomain;
import com.koreanair.cargo.domain.VocReqDomain;

public interface ExportControllDwrService {
	public Map<String,Object> getVocCityList (VocReqDomain vocReqDomain);
	
	public Map<String,Object> getExportMawbList (ExportReqDomain exportReqDomain);
	
	public Map<String,Object> getExportMawbHawbList (ExportReqDomain exportReqDomain);
	
	public Map<String,Object> getExportMawbInfo (ExportReqDomain exportReqDomain);
}
