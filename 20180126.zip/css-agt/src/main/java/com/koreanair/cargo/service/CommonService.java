package com.koreanair.cargo.service;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.koreanair.cargo.domain.EawbReqDomain;
import com.koreanair.cargo.domain.VolumnWebDomain;

public interface CommonService {
	public List<Map<String, Object>> getTrmlList();
	
	public List<Map<String, Object>> selectWeighingIpList(EawbReqDomain reqDomain);
	
	public Map<String,Object> volChkWebSvc(VolumnWebDomain volWebDomain) throws JsonProcessingException;
}
