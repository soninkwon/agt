package com.koreanair.cargo.service.uld;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.net.ssl.HttpsURLConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.koreanair.cargo.domain.uld.UldCityDomain;
import com.koreanair.cargo.domain.uld.UldReqDomain;
import com.koreanair.cargo.persistence2.UldMapper;

@Service
public class UldServiceImple implements UldService {
	private static final Logger logger = LoggerFactory.getLogger(UldServiceImple.class);
	@Autowired
	UldMapper uldMapper;
	
	@Override
	public List<UldCityDomain> uldCityList(UldReqDomain reqDomain) {
		logger.info("000000000000000000000000000000000000000000>>>>>>>>");
		return uldMapper.getUldCityList2(reqDomain);
		
	}
	
	public List<UldCityDomain> uldCityList2(UldReqDomain reqDomain) {
		logger.info("000000000000000000000000000000000000000000>>>>>>>>");
		return null;
		
	}
	
}
