package com.koreanair.cargo.domain;

import org.directwebremoting.annotations.DataTransferObject;
import org.directwebremoting.annotations.RemoteProperty;

@DataTransferObject(type="bean", javascript="wsMenuDomain")
public class WsMenuDomain {
	
	
	private String ssoLoginId      = "";
	private String empNo           = "";
	private String empEngLnm       = "";
	private String empEngFnm       = "";
	private String empLocalLangLnm = "";
	private String orgCd           = "";
	private String email           = "";
	private String ofcPhone        = "";
	private String empTypNm        = "";
	private String icbSttsNm       = "";
	private String defaultOfcId    = "";
	private String office          = "";
	private String ofcId           = "";
	private String grpId           = "";
	private String grpNm           = "";
	private String menuId          = "";
	private String menuNm          = "";
	private String highMenuId      = "";
	private String outputSeq       = "";
	private String menuGrd         = "";
	private String url             = "";
	private String readPosbYn      = "";
	private String wrtPosbYn       = "";
	private String delPosbYn       = "";
	private String prtPosbYn       = "";
	private String loopCnt       = "";
	
	public String getSsoLoginId() {
		return ssoLoginId;
	}
	public void setSsoLoginId(String ssoLoginId) {
		this.ssoLoginId = ssoLoginId;
	}
	public String getEmpNo() {
		return empNo;
	}
	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}
	public String getEmpEngLnm() {
		return empEngLnm;
	}
	public void setEmpEngLnm(String empEngLnm) {
		this.empEngLnm = empEngLnm;
	}
	public String getEmpEngFnm() {
		return empEngFnm;
	}
	public void setEmpEngFnm(String empEngFnm) {
		this.empEngFnm = empEngFnm;
	}
	public String getEmpLocalLangLnm() {
		return empLocalLangLnm;
	}
	public void setEmpLocalLangLnm(String empLocalLangLnm) {
		this.empLocalLangLnm = empLocalLangLnm;
	}
	public String getOrgCd() {
		return orgCd;
	}
	public void setOrgCd(String orgCd) {
		this.orgCd = orgCd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getOfcPhone() {
		return ofcPhone;
	}
	public void setOfcPhone(String ofcPhone) {
		this.ofcPhone = ofcPhone;
	}
	public String getEmpTypNm() {
		return empTypNm;
	}
	public void setEmpTypNm(String empTypNm) {
		this.empTypNm = empTypNm;
	}
	public String getIcbSttsNm() {
		return icbSttsNm;
	}
	public void setIcbSttsNm(String icbSttsNm) {
		this.icbSttsNm = icbSttsNm;
	}
	public String getDefaultOfcId() {
		return defaultOfcId;
	}
	public void setDefaultOfcId(String defaultOfcId) {
		this.defaultOfcId = defaultOfcId;
	}
	public String getOffice() {
		return office;
	}
	public void setOffice(String office) {
		this.office = office;
	}
	public String getOfcId() {
		return ofcId;
	}
	public void setOfcId(String ofcId) {
		this.ofcId = ofcId;
	}
	public String getGrpId() {
		return grpId;
	}
	public void setGrpId(String grpId) {
		this.grpId = grpId;
	}
	public String getGrpNm() {
		return grpNm;
	}
	public void setGrpNm(String grpNm) {
		this.grpNm = grpNm;
	}
	public String getMenuId() {
		return menuId;
	}
	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}
	public String getMenuNm() {
		return menuNm;
	}
	public void setMenuNm(String menuNm) {
		this.menuNm = menuNm;
	}
	public String getHighMenuId() {
		return highMenuId;
	}
	public void setHighMenuId(String highMenuId) {
		this.highMenuId = highMenuId;
	}
	public String getOutputSeq() {
		return outputSeq;
	}
	public void setOutputSeq(String outputSeq) {
		this.outputSeq = outputSeq;
	}
	public String getMenuGrd() {
		return menuGrd;
	}
	public void setMenuGrd(String menuGrd) {
		this.menuGrd = menuGrd;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getReadPosbYn() {
		return readPosbYn;
	}
	public void setReadPosbYn(String readPosbYn) {
		this.readPosbYn = readPosbYn;
	}
	public String getWrtPosbYn() {
		return wrtPosbYn;
	}
	public void setWrtPosbYn(String wrtPosbYn) {
		this.wrtPosbYn = wrtPosbYn;
	}
	public String getDelPosbYn() {
		return delPosbYn;
	}
	public void setDelPosbYn(String delPosbYn) {
		this.delPosbYn = delPosbYn;
	}
	public String getPrtPosbYn() {
		return prtPosbYn;
	}
	public void setPrtPosbYn(String prtPosbYn) {
		this.prtPosbYn = prtPosbYn;
	}
	public String getLoopCnt() {
		return loopCnt;
	}
	public void setLoopCnt(String loopCnt) {
		this.loopCnt = loopCnt;
	}   
	
	
	
	
	
}