package com.koreanair.cargo.service.uld;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.koreanair.cargo.domain.uld.UldReqDomain;
import com.koreanair.cargo.domain.uld.UldCityDomain;

public interface UldService {
	
	public List<UldCityDomain> uldCityList(UldReqDomain reqDomain);
	
	public List<UldCityDomain> uldCityList2(UldReqDomain reqDomain);
	
}
