<!--

/* 검색할수 있는 내용 
	1. 문자한자
		1) 한글한자	is_han
		2) 영문한자 	is_alpha
		3) 숫자한자	is_num

	2. 2문자조합
		1) 한글한자+영문한자 ( 1.1 || 1.2 )		is_han_alpha
		2) 한글한자+숫자한자 ( 1.1 || 1.3 )		is_han_num
		3) 한글한자+space    ( 1.1 || ' ' )		is_han_space
		4) 영문한자+숫자한자 ( 1.2 || 1.3 )		is_alpha_num
		5) 영문한자+space    ( 1.2 || ' ' )		is_alpha_space
		6) 숫자한자+space    ( 1.3 || ' ' )		is_num_space
	3. 3문자조합
		1) 한글한자+영문한자+숫자한자 ( 2.1 + 1.3 )	is_han_alpha_num
		2) 한글한자+영문한자+space    ( 2.1 + ' ' )	is_han_alpha_space
		3) 한글한자+숫자한자+space    ( 2.2 + ' ' )	is_han_num_space
		4) 영문한자+숫자한자+space    ( 2.4 + ' ' )	is_alpha_num_space


*/

function	is_alpha( str )			/* 입력된 내용이 영문인지 검사한다 */
{
	if( ( str >= 'a' && str <= 'z' ) || 
	    ( str >= 'A' && str <= 'Z' ) )
		return true;
	
	return false;
}

function	is_alpha_space( str )
{
	if( is_alpha( str ) == true || str == ' ' ) return true;

	return false;
}

function	is_num( str )			/* 입력된 내용이 숫자인지 검사한다 */
{
	if( str >= '0' && str <= '9' )
		return true;
		
	return false;
}

function	is_num_space( str )
{
	if( is_num( str ) == true || str == ' ' ) return true;

	return false;
}

function	is_han( str )			/* 입력된 내용이 한글인지 검사한다 */
{
	if( is_invalide_han( str ) == true || is_num( str ) == true || 
            is_alpha( str ) == true || is_etc( str ) == true ) return false;

	return true;
} 

function	is_han_space( str )
{
	if( is_han( str ) == true || str == ' ' ) return true;

	return false;
}

function	is_invalide_han( str )		/* 잘못된 한글을 검사한다 */
{
	var han = 'ㄱㄴㄷㄹㅁㅂㅅㅇㅈㅊㅍㅎㅏㅑㅓㅕㅗㅛㅜㅠㅡㅣㅐㅔㅒㅖㅢㄻㅄㄺㅀㄲㄸㅆㅃㅉ'

	if( han.indexOf( str ) >= 0 ) return true;

	return false;
}

function	is_etc( str )			/* 특수문자를 검사한다 */
{
	var etc = '!@"\\#$%^&*()-_+`|{[}];:<>,.?=~'

	if( etc.indexOf( str ) >= 0 ) return true;

	return false;
}

function	is_etc_email( str )			/* 특수문자를 검사한다 */
{
	var etc = '!@"\\#$%^&*()+`|{[}];:<>,?=~'

	if ( str == ' ' ) {
		return false;
	}

	if( etc.indexOf( str ) >= 0 ) {
		return false;
	}
	return true;
}


function	are_han( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_han( str.charAt(pos) ) != true || str.charAt(pos) == ' ' ) break;
	}

	if( pos == str.length )
		return true;

	return false;
}

function	are_han_space( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_han_space( str.charAt(pos) ) != true ) break;
	}

	if( pos == str.length )
		return true;

	return false;
}

function	are_alpha( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_alpha( str.charAt(pos) ) != true ) break;
	}

	if( pos == str.length )
		return true;

	return false;
}

function	are_alpha_space( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_alpha_space( str.charAt(pos) ) != true ) break;
	}

	if( pos == str.length )
		return true;

	return false;
}

function are_num( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_num( str.charAt(pos) ) != true ) break;
	}

	if( pos == str.length )
		return true;

	return false;
}

function are_same( str )
{
	var	pos;
	var	sameChar = 0;

	for( pos = 0; pos < str.length -1 ; pos++ )
	{
		if( str.charAt(pos).indexOf(str.charAt(pos+1))>-1)
		{
			sameChar ++;
		}
	}

	if (sameChar >= 5)
	{
		return false;
	}
	
return true;
}



function	are_same1( str )

{
	
	var	pos;
	
	var	sameChar = 0;

	
	
	for( pos = 0; pos < str.length -1 ; pos++ )
	
	{
		
		if( str.charAt(pos).indexOf(str.charAt(pos+1))>-1)
		
		{
				
			sameChar ++;
		
		}
	
	}

	
	if (sameChar >= 3)
	
	{
		
		return false;
	
	}
	return true;

}


function	compare_id_pass( str1, str2 )
{
	var	pos1;
	var	pos2;
	
	for( pos1 = 0; pos1 < str1.length; pos1++ )
	{
		for( pos2 = 0; pos2 < str2.length; pos2++ )
		{
			if( str1.charAt(pos1).indexOf(str2.charAt(pos2))>-1 && (pos1 < str1.length-2) && (pos2 < str2.length-2))
			{
				if( str1.charAt(pos1+1).indexOf(str2.charAt(pos2+1))>-1 )
				{
					if( str1.charAt(pos1+2).indexOf(str2.charAt(pos2+2))>-1) 
					{
						return false;
					}
				}
			}
		}
	}

	if( pos1 == str1.length )
		return true;
}



function	compare_str( str1, str2 )

{
	
	var	pos1;
	
	var	pos2;
	
	
	for( pos1 = 0; pos1 < str1.length; pos1++ )
	
	{
		
		for( pos2 = 0; pos2 < str2.length; pos2++ )
		
		{
			
			if( str1.charAt(pos1).indexOf(str2.charAt(pos2))>-1 && (pos1 < str1.length-2) && (pos2 < str2.length-2))
			
			{
				
				if( str1.charAt(pos1+1).indexOf(str2.charAt(pos2+1))>-1 )
				
				{
					
					if( str1.charAt(pos1+2).indexOf(str2.charAt(pos2+2))>-1) 
					
					{
						
						if (str1.charAt(pos1+3).indexOf(str2.charAt(pos2+3))>-1)
						
						{
							
							return false;
						
						}
					
					}
				
				}
			
			}
		
		}
	
	}
	

	
	if( pos1 == str1.length )
		
		return true;

}


function	are_num_space( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_num_space( str.charAt(pos) ) != true ) break;
	}

	if( pos == str.length )
		return true;

	return false;
}

function	are_han_alpha_num( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_han_alpha_num( str.charAt(pos) ) != true ) break;
	}

	if( pos == str.length )
		return true;

	return false;
}

function	is_han_alpha_num( str )
{
	if( is_alpha( str ) == true || is_num( str ) == true || is_han( str ) == true ) return true;

	return false;
}

function	are_han_alpha_num_space( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_han_alpha_num_space( str.charAt(pos) ) == false ) break;
	}

	if( pos == str.length ) return true;

	return false;
}

function	is_han_alpha_num_space( str )
{
	if( is_han_alpha_num( str ) == true || str == ' ' ) return true;

	return false;
}

function	are_alpha_num( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_alpha_num( str.charAt(pos) ) != true ) break;
	}

	if( pos == str.length )
		return true;

	return false;
}

function	is_alpha_num( str )
{
	if( is_alpha( str ) == true || is_num( str ) == true ) return true;

	return false;	
}

function	are_alpha_num_etc( str )
{
	var	pos;

	for( pos = 0; pos < str.length; pos++ )
	{
		if( is_alpha_num_etc( str.charAt(pos) ) == false ) break;
	}

	if( pos == str.length )
		return true;

	return false;
}

function	is_alpha_num_etc( str )
{
	if( is_alpha_num( str ) == true || is_etc( str ) == true )
		return true;

	return false;
}



//회원가입시 사용하는 함수.
var	continue_flag = 0;
function	check_common()
{
	var	df = document.memForm;

	/* 패스워드	검사 */
	if( are_alpha_num( df.passwd1.value ) == false )
	{
		alert( "패스워드는 영문자,숫자만을 허용합니다." );
		df.passwd1.focus();

		return;
	}

	/* 패스워드가 모두 숫자인지 확인 */
	if(are_num(df.passwd1.value))
	{
		alert( "패스워드는 1자 이상의 영문자가 포함되어야 합니다." );
		df.passwd1.focus();

		return;
	}

	/* 패스워드가 모두 영문인지 확인 */
	if(are_alpha(df.passwd1.value))
	{
		alert( "패스워드는 1자 이상의 숫자가 포함되어야 합니다." );
		df.passwd1.focus();

		return;
	}

	/* 패스워드는 아이디와 동일여부  */
	if( (df.passwd1.value.toUpperCase()) == (df.userId.value.toUpperCase()))
	{
		alert( "패스워드는 아이디와 동일할 수 없습니다." );
		df.passwd1.focus();

		return;
	}
	
	/* 패스워드가 연속해서 입력되었는지 확인 */
	if(!are_same(df.passwd1.value))
	{
		alert( "패스워드는 6자리 이상 동일 또는 연속된 숫자/문자열이 들어갈 수 없습니다. " );
		df.passwd1.focus();

		return;
	}
	
	//휴대폰번호, 전화번호 동일 문자열 중복 불가
	var oPhone;
	
	oPhone = df.inputTel.value.toUpperCase().replace("-","");
	

	//if (oPhone == df.passwd1.value.toUpperCase())
	if (oPhone.length > 0 && df.passwd1.value.toUpperCase().indexOf(oPhone) > -1)
	{
		alert( "패스워드는 전화번호 전체를 포함할 수 없습니다." );
		df.passwd1.focus();

		return;
	}

	/* 비밀번호에 4자리 이상 같은 값이 있을경우 */
	userId = df.userId.value.toUpperCase();
	
	if (continue_flag == 0 && !are_same1(df.passwd1.value))
	{
		if (confirm("4자리 이상의 동일한 문자 또는 숫자열을 입력하셨습니다.\n이 경우, 해킹의 위험성이 있습니다. 그래도 사용을 원하시면 ‘확인’을 눌러주시기 바랍니다.") == true)	
		{
			continue_flag = 1;
			return;
		}
		else
		{
			continue_flag = 0;
			df.passwd1.value = "";
			df.passwd2.value = "";
			df.passwd1.focus();
			return;
		}
	}
	
	
	/* 비밀번호에 아이디가 포함되어 있을경우 */
	userId = df.userId.value.toUpperCase();
	
	if (continue_flag == 0 && !compare_id_pass(userId, df.passwd1.value.toUpperCase()))
	{
		if (confirm("패스워드에 아이디가 포함되어 있습니다.\n이 경우, 해킹의 위험성이 있습니다. 그래도 사용을 원하시면 ‘확인’을 눌러주시기 바랍니다.") == true)	
		{
			continue_flag = 1;
			return;
		}
		else
		{
			continue_flag = 0;
			df.passwd1.value = "";
			df.passwd2.value = "";
			df.passwd1.focus();
			return;
		}
	}
	
	
	/* 사무실 전화번호와 4자리이상 같은지 체크 */
	
	if (continue_flag == 0 && !compare_str(oPhone, df.passwd1.value.toUpperCase()))
	{
		if (confirm("패스워드와 전화번호가 4자리 이상 중복됩니다.\n이 경우, 해킹의 위험성이 있습니다. 그래도 사용을 원하시면 ‘확인’을 눌러주시기 바랍니다.") == true)	
		{
			continue_flag = 1;
			return;
		}
		else
		{
			continue_flag = 0;
			df.passwd1.value = "";
			df.passwd2.value = "";
			df.passwd1.focus();
			return;
		}
	}

	return true;

}


//supervisor 회원일경우 user list 가 여러개일경우 이용하는 함수.
var	continue_flag = 0;
function	check_common_1(no)
{
	var	df = document.userListForm;
	var df2= document.informationForm;

	/* 패스워드	검사 */
	if( are_alpha_num( df.userpass[no].value ) == false )
	{
		alert( "패스워드는 영문자,숫자만을 허용합니다." );
		df.userpass[no].focus();

		return;
	}

	/* 패스워드가 모두 숫자인지 확인 */
	if(are_num(df.userpass[no].value))
	{
		alert( "패스워드는 1자 이상의 영문자가 포함되어야 합니다." );
		df.userpass[no].focus();

		return;
	}

	/* 패스워드가 모두 영문인지 확인 */
	if(are_alpha(df.userpass[no].value))
	{
		alert( "패스워드는 1자 이상의 숫자가 포함되어야 합니다." );
		df.userpass[no].focus();

		return;
	}

	/* 패스워드는 아이디와 동일여부  */
	if( (df.userpass[no].value.toUpperCase()) == (df.userId[no].value.toUpperCase()))
	{
		alert( "패스워드는 아이디와 동일할 수 없습니다." );
		df.userpass[no].focus();

		return;
	}
	
	/* 패스워드가 연속해서 입력되었는지 확인 */
	if(!are_same(df.userpass[no].value))
	{
		alert( "패스워드는 6자리 이상 동일 또는 연속된 숫자/문자열이 들어갈 수 없습니다. " );
		df.userpass[no].focus();

		return;
	}

	

	/* 비밀번호에 4자리 이상 같은 값이 있을경우 */
	userId = df.userId[no].value.toUpperCase();
	
	if (continue_flag == 0 && !are_same1(df.userpass[no].value))
	{
		if (confirm("4자리 이상의 동일한 문자 또는 숫자열을 입력하셨습니다.\n이 경우, 해킹의 위험성이 있습니다. 그래도 사용을 원하시면 ‘확인’을 눌러주시기 바랍니다.") == true)	
		{
			continue_flag = 1;
			return;
		}
		else
		{
			continue_flag = 0;
			df.userpass[no].value = "";
			df.userpass[no].focus();
			return;
		}
	}
	
	
	/* 비밀번호에 아이디가 포함되어 있을경우 */
	userId = df.userId[no].value.toUpperCase();
	
	if (continue_flag == 0 && !compare_id_pass(userId.toUpperCase(), df.userpass[no].value.toUpperCase()))
	{
		if (confirm("패스워드에 아이디가 포함되어 있습니다.\n이 경우, 해킹의 위험성이 있습니다. 그래도 사용을 원하시면 ‘확인’을 눌러주시기 바랍니다.") == true)	
		{
			continue_flag = 1;
			return;
		}
		else
		{
			continue_flag = 0;
			df.userpass[no].value = "";
			df.userpass[no].focus();
			return;
		}
	}
	
	
	
	return true;

}


//supervisor 회원일경우 user list 가 한개일경우 이용하는 함수.
var	continue_flag = 0;
function	check_common_2()
{
	var	df = document.userListForm;
	var df2= document.informationForm;

	/* 패스워드	검사 */
	if( are_alpha_num( df.userpass.value ) == false )
	{
		alert( "패스워드는 영문자,숫자만을 허용합니다." );
		df.userpass.focus();

		return;
	}

	/* 패스워드가 모두 숫자인지 확인 */
	if(are_num(df.userpass.value))
	{
		alert( "패스워드는 1자 이상의 영문자가 포함되어야 합니다." );
		df.userpass.focus();

		return;
	}

	/* 패스워드가 모두 영문인지 확인 */
	if(are_alpha(df.userpass.value))
	{
		alert( "패스워드는 1자 이상의 숫자가 포함되어야 합니다." );
		df.userpass.focus();

		return;
	}
	
	/* 패스워드는 아이디와 동일여부  */
	if( (df.userpass.value.toUpperCase()) == (df.userId.value.toUpperCase()))
	{
		alert( "패스워드는 아이디와 동일할 수 없습니다." );
		df.userpass.focus();

		return;
	}
	
	/* 패스워드가 연속해서 입력되었는지 확인 */
	if(!are_same(df.userpass.value))
	{
		alert( "패스워드는 6자리 이상 동일 또는 연속된 숫자/문자열이 들어갈 수 없습니다. " );
		df.userpass.focus();

		return;
	}

	/* 비밀번호에 4자리 이상 같은 값이 있을경우 */
	userId = df.userId.value.toUpperCase();
	
	if (continue_flag == 0 && !are_same1(df.userpass.value))
	{
		if (confirm("4자리 이상의 동일한 문자 또는 숫자열을 입력하셨습니다.\n이 경우, 해킹의 위험성이 있습니다. 그래도 사용을 원하시면 ‘확인’을 눌러주시기 바랍니다.") == true)	
		{
			continue_flag = 1;
			return;
		}
		else
		{
			continue_flag = 0;
			df.userpass.value = "";
			df.userpass.focus();
			return;
		}
	}
	
	
	/* 비밀번호에 아이디가 포함되어 있을경우 */
	userId = df.userId.value.toUpperCase();
	
	if (continue_flag == 0 && !compare_id_pass(userId.toUpperCase(), df.userpass.value.toUpperCase()))
	{
		if (confirm("패스워드에 아이디가 포함되어 있습니다.\n이 경우, 해킹의 위험성이 있습니다. 그래도 사용을 원하시면 ‘확인’을 눌러주시기 바랍니다.") == true)	
		{
			continue_flag = 1;
			return;
		}
		else
		{
			continue_flag = 0;
			df.userpass.value = "";
			df.userpass.focus();
			return;
		}
	}
	
	
	return true;

}


//supervisor 가 아닌 회원이 비밀번호 변경시 체크하는 부분.
var	continue_flag = 0;
function	check_common_3()
{
	var	df = document.passwdForm;

	/* 패스워드	검사 */
	if( are_alpha_num( df.newPass.value ) == false )
	{
		alert( "패스워드는 영문자,숫자만을 허용합니다." );
		df.newPass.focus();

		return;
	}

	/* 패스워드가 모두 숫자인지 확인 */
	if(are_num(df.newPass.value))
	{
		alert( "패스워드는 1자 이상의 영문자가 포함되어야 합니다." );
		df.newPass.focus();

		return;
	}

	/* 패스워드가 모두 영문인지 확인 */
	if(are_alpha(df.newPass.value))
	{
		alert( "패스워드는 1자 이상의 숫자가 포함되어야 합니다." );
		df.newPass.focus();

		return;
	}

	/* 패스워드는 아이디와 동일여부  */
	if( (df.newPass.value.toUpperCase()) == (df.user_id.value.toUpperCase()))
	{
		alert( "패스워드는 아이디와 동일할 수 없습니다." );
		df.newPass.focus();

		return;
	}
	
	/* 패스워드가 연속해서 입력되었는지 확인 */
	if(!are_same(df.newPass.value))
	{
		alert( "패스워드는 6자리 이상 동일 또는 연속된 숫자/문자열이 들어갈 수 없습니다." );
		df.newPass.focus();

		return;
	}
	
	
	/* 비밀번호에 4자리 이상 같은 값이 있을경우 */
	user_id = df.user_id.value.toUpperCase();
	
	if (continue_flag == 0 && !are_same1(df.newPass.value))
	{
		if (confirm("4자리 이상의 동일한 문자 또는 숫자열을 입력하셨습니다.\n이 경우, 해킹의 위험성이 있습니다. 그래도 사용을 원하시면 ‘확인’을 눌러주시기 바랍니다.") == true)	
		{
			continue_flag = 1;
			return;
		}
		else
		{
			continue_flag = 0;
			df.newPass.value = "";
			df.newPass.focus();
			return;
		}
	}	
	
	/* 비밀번호에 아이디가 포함되어 있을경우 */
	user_id = df.user_id.value.toUpperCase();
	
	if (continue_flag == 0 && !compare_id_pass(user_id.toUpperCase(), df.newPass.value.toUpperCase()))
	{
		if (confirm("패스워드에 아이디가 포함되어 있습니다.\n이 경우, 해킹의 위험성이 있습니다. 그래도 사용을 원하시면 ‘확인’을 눌러주시기 바랍니다.") == true)	
		{
			continue_flag = 1;
			return;
		}
		else
		{
			continue_flag = 0;
			df.newPass.value = "";
			df.newPass.focus();
			return;
		}
	}
	

	return true;

}


//-->
