/** -----------------------------------------------------------------------------
**
**  파일명      : comUtil.js
**  버젼        : 1.0
---------------------------------------------------------------------------------
**  변경일자	변경자		변경내용
---------------------------------------------------------------------------------
**  2004-06-01	JJY			create
**  2004-09-16	JJY			maspCheckAlpha(obj, comment, mendentory) create
**  2004-11-11	JJY			funcFindFWDRCust(pID, fwdrCd, custTp, custNm, param1, param2, param3, param4, param5, param6, param7) create
** -----------------------------------------------------------------------------
*/
	var doc = document;
	var msg = '';
	var cnt = 0;

	// combo에 있는 text값을 임의의 객체에 담기
	// srcObj : 콤보객체
	// tarObj : 타겟객체(텍스트, 히든)
	function maspComboText2Hidden(srcObj, tarObj){
		tarObj.value = srcObj.options[srcObj.selectedIndex].text;
	}

	// combo에 있는 Value값을 임의의 객체에 담기
	// srcObj : 콤보객체
	// tarObj : 타겟객체(텍스트, 히든)
	function maspComboValue2Hidden(srcObj, tarObj){
		tarObj.value = srcObj.options[srcObj.selectedIndex].value;
	}

	//textbox에 작성중 focus가 떠날때 checkbox를 자동 체크
	function maspOnBlurChecked(srcObj,tgtObj){
		if(tgtObj.checked == false && srcObj.value.length >  0) tgtObj.checked = true;
		if(tgtObj.checked == true  && srcObj.value.length == 0) tgtObj.checked = false;
	}

	// 같은 이름의 라디오버튼 중에서 선택된 것의 VALUE 반환
	function maspRadioValue(obj){

		if(obj == null) return null;

		var len = obj.length;
		if(len == null){
			if(obj.checked == true) return obj.value
		}else{
			for(var i=0; i<len; i++){
				if(obj[i].checked == true) return obj[i].value
			}
		}
		return null;
	}

	//선택 체크박스를 전체 선택하던가 해제시킨다
	//form : FORM객체
	function maspProctypeSelect(form){

		var object = null;
		if(form.checkall.value == "TRUE"){
			form.checkall.value = "FALSE";
		}else{
			form.checkall.value = "TRUE";
		}

		for(i=1; i<=form.sizes.value; i++){

			object = eval("form.proctype" + i);

			if(object.disabled  == true) continue;

			if(form.checkall.value == "TRUE"){
				object.checked = true;
			}else{
				object.checked = false;
			}
		}
		return;
	}


	//다중처리 체크박스 목록에서 체크된 것이 존재하는지 확인한다
	function maspProctypeChecked(form){

		var object = null;

		for(i=1; i<=form.sizes.value; i++){

			object = eval("form.proctype" + i);
			if(object.checked == true) return true;
		}

		alert("선택된 항목이 존재하지 않습니다. 작업할 항목을 선택하십시오");
		return false;
	}

	//private함수
	function valiDate(yyyy,mm,dd) {
		var dDate;

		dDate = new Date(yyyy,mm-1,dd);

		if (dDate=="NaN") return false;

		if ((yyyy == dDate.getFullYear()) && (mm == dDate.getMonth()+1) && (dd == dDate.getDate())) {
			return true;
		}else {
			return false;
		}
	}


/*********************************************************************
*************************     Enter키 이벤트     *********************
/********************************************************************/

	var tabIndex    = 0;
	var gIndex      = 1;
	var controlName = new Array();
	var controlCode = new Array();

	function maspEnterFocus(){

		var form = document.myform;

		if(event.keyCode == 13){

			//gIndex = gIndex-1; //이 문장을 지울려면 아래 (document.onkeydown = focus;)를 삭제한다. 이벤트가 두번 먹으므로

			for(var i=0; i< controlName.length; i++){
				if(this.name == controlName[i]){
					gIndex = i + 1;
					break;
				}
			}

			if(gIndex == controlCode.length) gIndex = 0;
			tabIndex = controlCode[gIndex];
			form.elements[tabIndex].focus();
			if(form.elements[tabIndex].type == 'text'){
				form.elements[tabIndex].select();
			}
			gIndex++;
			return true;
		}
	}

	function maspEnterEvent(){

		var form = document.myform;
		var inx  = 0;

		for(var i=0; i<form.elements.length; i++){

			if(form.elements[i].type == 'text' || form.elements[i].type == 'radio' ||
			form.elements[i].type == 'checkbox' || form.elements[i].type == 'select-one' ||
			form.elements[i].type == 'file'     || form.elements[i].type == 'button'){

				controlCode[inx] = i;
				controlName[inx] = form.elements[i].name;
				inx++;
				form.elements[i].onkeydown = maspEnterFocus;
			}
		}
		tabIndex = controlCode[gIndex];
	}

	//onKeyPress시 날짜 필드에 년도 다음, 월 다음에 대쉬(-)를 첨가한다
	function maspDateDash(obj){

		if(obj.value.length == 4){
			obj.value = obj.value + '-';
		}

		if(obj.value.length == 7){
			obj.value = obj.value + '-';
		}

		if(obj.value.length > 4){
			//2001-12-31
			if(obj.value.substring(4,5) == '/' || obj.value.substring(4,5) == '.'){
				obj.value = obj.value.substring(0, 4) + '-';
			}
			if(obj.value.substring(7,8) == '/' || obj.value.substring(7,8) == '.'){
				obj.value = obj.value.substring(0, 7) + '-';
			}
		}
	}

	//onKeyPress시 우편번호 3자리 다음에 대쉬(-)를 첨가한다
	function maspPostCodeDash(obj){
		if(obj.value.length == 3){
			obj.value = obj.value + '-';
		}

		if(obj.value.length > 3){
			if(obj.value.substring(3,4) == '/' || obj.value.substring(3,4) == '.'){
				obj.value = obj.value.substring(0, 3) + '-';
			}
		}
	}

	//onBlur시 날짜 필드에 년도 다음, 월 다음에 대쉬(-)를 첨가한다
	function maspDateDash1(obj, yyyymm){

		var yyyy;
		var mm;
		var dd;

		if(obj.value.length == 2 || obj.value.length == 1){

			yyyy = yyyymm.substring(0, 4);
			mm   = yyyymm.substring(4, 6);

			if(obj.value.length == 1){
				dd   = '0' + obj.value;
			}else{
				dd   = obj.value;
			}

			if(!valiDate(yyyy,mm,dd)){
				obj.value = '';
				alert('적용가능한 날짜를 생성할 수 없습니다');
				obj.focus();
				return false;
			}

			obj.value = yyyy + '-' + mm + '-' + dd;
		}

		if(obj.value.length == 4){
			yyyy = yyyymm.substring(0, 4);
			mm   = obj.value.substring(0,2);
			dd   = obj.value.substring(2,4);

			if(!valiDate(yyyy,mm,dd)){
				obj.value = '';
				alert('적용가능한 날짜를 생성할 수 없습니다');
				obj.focus();
				return false;
			}

			obj.value = yyyy + '-' + mm + '-' + dd;
		}


		if(obj.value.length == 6){
			yyyy = yyyymm.substring(0, 2) + obj.value.substring(0,2);
			mm   = obj.value.substring(2,4);
			dd   = obj.value.substring(4,6);

			if(!valiDate(yyyy,mm,dd)){
				obj.value = '';
				alert('적용가능한 날짜를 생성할 수 없습니다');
				obj.focus();
				return false;
			}

			obj.value = yyyy + '-' + mm + '-' + dd;
		}

		if(obj.value.length == 8){
			yyyy = obj.value.substring(0,4);
			mm   = obj.value.substring(4,6);
			dd   = obj.value.substring(6,8);

			if(!valiDate(yyyy,mm,dd)){
				obj.value = '';
				alert('적용가능한 날짜를 생성할 수 없습니다');
				obj.focus();
				return false;
			}

			obj.value = yyyy + '-' + mm + '-' + dd;
		}
	}


/*********************************************************************
*************************     브라우저변수     ***********************
/********************************************************************/
    var bName = navigator.appName;
    var bVer = parseInt(navigator.appVersion);
    var bVersion = navigator.appVersion;

    var bPlatform = navigator.platform
    var NS = (bName == "Netscape");
    var IE = (bName == "Microsoft Internet Explorer");

    var NS4 = (bName == "Netscape" && bVer >= 4);
    var IE4 = (bName == "Microsoft Internet Explorer" && bVersion.indexOf("MSIE 4") != -1);
    var NS3 = (bName == "Netscape" && bVer < 4);
    var IE3 = (bName == "Microsoft Internet Explorer" && bVer < 4);

    var NS4_7 = (bName == "Netscape" && bVersion.substring(0,3) >= 4.7);
    var IE5 = (bName == "Microsoft Internet Explorer" && bVersion.indexOf("5.") != -1);
    

/*********************************************************************
*************************     공통사용     ***************************
/********************************************************************/
	//서버에 있는 파일을 link를 걸어주면 화일에 따라 새로운 창이 뜨며 그 창에 뿌려질지 자동 다운로드가 될지 결정
	function funcLinkFile(file_path){
		/*
		▶win98,NT, unix서버에서  클라이언트가  netscape사용시 한글명이 깨질때 escape쓴다
		▶win98,NT,unix서버에서 클라이언트가  internet explore5.0 상관 없음
		*/
		if(NS){
			file_type = maspGetFileType(file_path).toLowerCase();
			if(isBlankOpenOfNetscape(file_type)){//빈화면 열리는것 방지,화일이 다운로드 묻는 창이 떠야 되는 경우
				location.href = escape(file_path);
			}else{//화일이 바로 열리면 윈도우 창에 내용이 뿌려지는 경우
				var link_file = window.open(escape(file_path), 'file_view', 'scrollbars=yes,status=yes,menubar=no,location=top,toolbar=no,directory=no,resizable=yes,top=200,left=200,width=500,height=500');
				link_file.focus();
			}
		}else{
			var link_file = window.open(file_path, 'file_view', 'scrollbars=yes,status=yes,menubar=no,location=top,toolbar=no,directory=no,resizable=yes,top=200,left=200,width=500,height=500');
			link_file.focus();
		}
	}

    //문자열 내 특정 문자를 치환한다.
    function maspReplaceString(org_str, find_str, replace_str){
        var pos = 0;
        pos = org_str.indexOf(find_str);

        while(pos != -1){
            pre_str = org_str.substring(0, pos);
            post_str = org_str.substring(pos + find_str.length, org_str.length);
            org_str = pre_str + replace_str + post_str;

            pos = org_str.indexOf(find_str);
        }
        return org_str;
    }

    //년월에 따른 day의 list 변경
    function getListOfDay(yyObj,mmObj,ddObj){

        var year =yyObj.options[yyObj.selectedIndex].value;
        var month=mmObj.options[mmObj.selectedIndex].value;
        var endday= maspGetLastDay(year , month)

        ddObj.length=endday;

        for(i = 0; i < endday; i++){
           ddObj.options[i].value =toLen2(i+1);
           ddObj.options[i].text  = i+1;
        }
        ddObj.selectedIndex = 0;
    }

	//년월에 따른 day의 list 변경
    function toLen2 (nums){
        var num=0;

        if(nums >= 1 && nums <=9)
            num = '0' + nums;
        else
            num=nums;
        return num;
    }

    //년도, 월을 입력하면 [해당년도-해당월]의 마지막 날짜를 반환한다
    //[해당년도-해당월]의 총 날짜수를 알 수 있다
    function  maspGetLastDay(yy, mm){

        var max_days=0;

        if(mm == 1)        max_days = 31;
        else if(mm == 2){

            if(((yy % 4 == 0) && (yy % 100 != 0)) || (yy % 400 == 0))
                            max_days = 29;
            else
                            max_days = 28;
        }
        else if(mm == 3)   max_days = 31;
        else if(mm == 4)   max_days = 30;
        else if(mm == 5)   max_days = 31;
        else if(mm == 6)   max_days = 30;
        else if(mm == 7)   max_days = 31;
        else if(mm == 8)   max_days = 31;
        else if(mm == 9)   max_days = 30;
        else if(mm == 10)  max_days = 31;
        else if(mm == 11)  max_days = 30;
        else if(mm == 12)  max_days = 31;
        else{

            return '';
        }
            return max_days;
    }

    //한글을 2byte로 인식하여 length 체크
    function maspGetByteLength(data){
        var len = 0;
        var str = data.substring(0);

        if(str == null) return 0;

        for(var i=0; i < str.length; i++){
            var ch = escape(str.charAt(i));

            if(ch.length == 1) len++;
            else
            if(ch.indexOf("%u") != -1) len += 2;
            else
            if(ch.indexOf("%") != -1) len += ch.length/3;
       }

       return len;
    }

    //전체 파일 패스를 입력하면 해당 파일의 확장자를 반환한다
    function maspGetFileType(str){
        var newstr="";
        var  len=0  ;
        if(str==null)   return "";

        var text = str.substring(0);
        if(text=='' || text.length < 1)   return '';

        var  point = text.lastIndexOf(".");
        if(point == -1) len = str.length;
        else len = point;

        newstr = text.substring(len+1);

        return newstr;
    }

  //오른쪽 공백문자를 제거한다
    function  maspRtrim(str){

		var src = new String(str);
		var tmp = new String();
		var i,lastnum, len = src.length;

		for(i = len;i >= 0;i--){
			tmp = src.substring(i,i-1);
			if(tmp != ' '){
				lastnum = i;
				break;
			}
		}

		tmp = src.substring(0,lastnum);
		return tmp;
    }

	//왼쪽 공백문자를 제거한다
    function  maspLtrim(str){

		var src = new String(str);
		var tmp = new String();
		var i,firstnum, len = src.length;

		for(i = 0;i < len;i++){
			tmp = src.substring(i,i+1);
			if(tmp != ' '){
				firstnum = i;
				break;
			}
		}

		tmp = src.substring(firstnum);
		return tmp;
    }


    //입력받은 문자열의 왼쪽/오른쪽 공백문자를 제거한다
    function  maspTrim(str){

	    var src = new String(str);
	    var tmp = new String();
	    tmp = maspLtrim(maspRtrim(str));
	    return tmp;
    }


    //특수문자를 변환문자로 변환한다
    function maspReplaceCode(str){
	    var pos = 0;
	    var len = str.length;
	    var replace_chr;
	    var cur_chr;
	    var replace_str = '';

	    for(var i=0; i < len; i++){
			cur_chr = str.charAt(i);

			if(cur_chr=='\"')      replace_chr='##34';
			else if(cur_chr=='\'') replace_chr='##39';
			else if(cur_chr=='>')  replace_chr='##60';
			else if(cur_chr=='<')  replace_chr='##62';
			else if(cur_chr=='/')  replace_chr='##47';
			else if(cur_chr=='\\') replace_chr='##92';
			else if(cur_chr=='(')  replace_chr='##40';
			else if(cur_chr==')')  replace_chr='##41';
			else if(cur_chr==',')  replace_chr='##44';
			else
			replace_chr = cur_chr;
			replace_str += replace_chr;
	    }

		return replace_str;
    }


    //변환문자를 원래의 특수문자로 변환한다
    function maspReplaceSign(str){
        var pos = 0;
        var len = str.length;
        var replace_chr;
        var cur_chr;
        var replace_str = '';

        for(var i=0; i < len; i++){
            cur_chr = str.charAt(i);

            if(cur_chr == '#'){
                cur_chr = str.substring(i,i+4);
                i += 3;
            }

            if(cur_chr=='##34') replace_chr='\"';
            else if(cur_chr=='##39') replace_chr='\'';
            else if(cur_chr=='##60') replace_chr='>';
            else if(cur_chr=='##62') replace_chr='<';
            else if(cur_chr=='##47') replace_chr='/';
            else if(cur_chr=='##92') replace_chr='\\';
            else if(cur_chr=='##40') replace_chr='(';
            else if(cur_chr=='##41') replace_chr=')';
            else if(cur_chr=='##44') replace_chr=',';
            else
                replace_chr = cur_chr;

            replace_str += replace_chr;
        }
        return replace_str;
    }


	//입력받은 객체의 값을 대문자로 변환해서 리턴한다
    function lCase2Ucase(obj){
        obj.value = obj.value.toUpperCase();
    }



/*********************************************************************
*************************     기타체크     ***************************
/********************************************************************/
    function maspCheckHidden(hidobj, obj, comment, mendentory){

        if(hidobj.length == 0 && mendentory){
            alert(comment + " 필드가 정상적으로 입력되지 않았습니다.\n" + comment + " 필드는 필수 입력항목입니다.\n\n 찾기 기능을 사용해서 선택하십시오.");
            obj.focus();
            obj.select();
            return false;
        }
        return true;
    }

	//필수입력 콤보박스를 체크한다
	function maspCheckCombo(obj, str){
		if(obj.selectedIndex == 0){
			alert(str + "를(을) 선택하세요\n" + str + "는(은) 필수선택 항목입니다");
			obj.focus();
			return false;
		}

		return true;
	}

    //들어온 자리수 체크
    /*인자
      Obj           : 객체
      startLength   : 자리수부터(0이면 endLength까지만
      endLength     : 자리수까지(0이면 startLength부터 무한대
      comment       : head명
      mendentory    : 필수여부
    */
    function maspCheckLength(Obj, startLength, endLength, comment, mendentory){
        //var data_length =  Obj.value.length;

        data_length = maspGetByteLength(Obj.value);
        //년월일이 입력되었는지 Check
        //필수 입력항목일 경우
        if(data_length == 0   && mendentory) {
            var mesg = "";
            if(startLength ==  endLength && startLength != 0){
                mesg = ""+startLength+"자리";

            }
            else if(startLength!=0 && endLength !=0){
                mesg = ""+startLength+"자리이상 " +endLength +"자리이하";

            }
            else if(startLength==0){
                mesg = "" +endLength +"자리이하";
            }else if(endLength ==0){
                mesg = ""+startLength+"자리이상";
            }

            alert(comment + " 필드가 입력되지 않았습니다.\n" +
                  comment + " 는(은) "+mesg+" 필수 입력항목입니다.\n  ");
            Obj.focus();

        }
        else if(data_length != 0){
            if(startLength==0 && endLength ==0){
                return true;
            }
            else if(startLength ==  endLength && startLength !=  data_length){
                alert(comment + "의 입력값은 길이 "+startLength+"자리가 입력되어야 합니다.\n");
                Obj.focus();
                Obj.select();
            }

            else if(startLength==0 && endLength < data_length){
                alert(comment + "의 입력값은 길이 "+endLength+"자리이하 입력되어야 합니다.\n");
                Obj.focus();
                Obj.select();
            }
            else if(startLength > data_length  && endLength == 0){
                alert(comment + "의 입력값은 길이 "+startLength+"자리이상  입력되어야 합니다.\n");
                Obj.focus();
                Obj.select();
            }
            else if((startLength > data_length) || (data_length > endLength)){
                if(startLength !=0 && endLength !=0)        {
                    alert(comment + "의 입력값은 길이 "+startLength+"자리이상 "+endLength+"자리이하가 입력되어야 합니다.\n");
                    Obj.focus();
                    Obj.select();
                }
                else{
                    return true;
                }
            }
            else{
                return true;
            }
        }
        else{
            return true;
        }

        return false;

    }

	//E-Mail 입력창을  체크한다
    function maspCheckEmail(obj, comment,mendentory){

		var data = obj.value;

        if(obj.value.length == 0 && mendentory){
			alert("E-mail을 등록하여 주시기 바랍니다.");
			obj.focus();
			return false;
        }else if(obj.value.length != 0){
			var sign = data.indexOf("@");
			var dot = data.indexOf(".");

			if(sign == -1 || dot == -1){
				alert("E-mail 주소 형식이 잘못되었습니다. (aaa@koreanair.com)");
				obj.focus();
				obj.select();

				return false;
			}
        }

        return true;
    }
    
    
    //E-Mail 입력창을  체크한다
    function maspCheckEmail2(obj, comment,mendentory){

		var data = obj.value;

        if(obj.value.length == 0 && mendentory){
			alert("E-mail을 확인하여 주시기 바랍니다.");
			obj.focus();
			return false;
        }else if(obj.value.length != 0){
			var sign = data.indexOf("@");
			var dot = data.indexOf(".");

			if(sign == -1 || dot == -1){
				alert("E-mail 주소 형식이 잘못되었습니다. (aaa@koreanair.com)");
				obj.focus();
				obj.select();

				return false;
			}
        }

        return true;
    }

	//URL 입력창을  체크한다
    function maspCheckURL(obj, comment,mendentory){

		var data = obj.value;

        if(obj.value.length == 0 && mendentory){
            alert(comment + " Internet 주소 필드가 입력되지 않았습니다.\n" +
                  comment + " Internet 주소 필드는 필수 입력항목입니다.\n\n ");
            obj.focus();
            return false;
        }else if(obj.value.length != 0){
			var sign  = data.indexOf("http://");
			var dot   = data.indexOf(".");
			var addsign = "";

			if(sign == -1 || dot == -1){
				if(sign == -1 ){
					ans = confirm(comment + " Internet 주소 형식이 잘못되었습니다. (http://www.myhome.com) \n" + " Internet 주소는  'http://'로 시작해야 합니다." + "\n\n 'http://' 를 추가하시겠습니까?" );

					if(ans == true)  obj.value = "http://" + obj.value;
				}else{
					alert(comment + " Internet 주소 형식이 잘못되었습니다. (http://www.myhome.com) " + addsign);
				}

				obj.focus();
				obj.select();

				return false;
			}

        }
        return true;
    }

	//필수 문자열 입력창을  체크한다
    function check_text(obj,comment){

		if(obj.value == '' || obj.value.length == 0){
			alert(comment + " 필드가 입력되지 않았습니다.\n" +
				comment + " 필드는 필수 입력항목입니다.\n");

			obj.focus();
			obj.select();
			return false;
		}

		return true;
    }

    //오브젝의 값이 범위를 지정할 경우 시작값과 종료값의 범위를 Check하는 함수
    //파라메터는 오브젝트로 전달, 형식에 맞지 않으면 False 리턴
    function check_Range(startObj, endObj, comment){
        if(startObj.value > endObj.value){
            alert(comment + " 범위의 시작값이 종료값보다 큽니다.\n시작값과 종료값을 확인바랍니다.\n");
            startObj.focus();
            startObj.select();
        }else{
            return true;
        }

        return false;
    }

/*********************************************************************
*************************     숫자체크     ***************************
/********************************************************************/

	//자리수 유효성을 확인한다
	//before_len : 소수점 이전(0이면 상관 없음)
	//after_len  : 소수점 이하
	//정확하게 소수점 아래 자리수까지 입력받아야 할 경우 사용한다
    function maspCheckDouble(obj, before_len, after_len, comment, mendentory){

    	obj.value = maspTrim(obj.value); //공백제거

        var before_ex ='';
        var after_ex = '';
        var i=0;

        for(i=1;i<=before_len;i++){
            if(i==1)    before_ex +=  Math.floor(Math.random()*9 +1);       //1과 9 사이 정수
            else if(i <10)      before_ex +=  Math.floor(Math.random()*10); //0과 9 사이 정수
            else                before_ex += '3';
        }

        for(i=1;i<=after_len;i++){
            if(i <10)           after_ex +=   Math.floor(Math.random()*10);
            else                after_ex += '2';
        }

        var ex = before_ex + '.'+ after_ex
    	var str = obj.value;

        point = str.indexOf('.');
        if(point == -1  && mendentory){
            alert(comment + " 필드가 입력되지 않았습니다.\n" +
                  comment + " 는(은) 필수 입력항목입니다.\n\n 예) "+ex);
            obj.focus();
            return false;
        }else if(point != -1){
			before_str = str.substring(0, point);
			after_str = str.substring(point+1, str.length);

			if(before_len !=0  && before_str.length > before_len){
				/* alert('자리수 초과입니다.'); */
				alert(comment + " 필드는 소수점 이상 "+before_len+"자리로 입력하세요.\n\t\t 예) " + ex);
				obj.focus();
				obj.select();
				return false;
			}

			if(after_str.length > after_len){
				/* alert('소수점이하 ' + after_len + '자리로 입력하세요.');*/
				alert(comment + " 필드는 소수점 이하 "+after_len+"자리로 입력하세요.\n\t\t 예) " + ex);
				obj.focus();
				obj.select();
				return false;
			}
        }else{
            return true;
        }

        return true;
    }

    //단순 숫자체크(숫자여부와 널체크)
    //오브젝트의 값이 숫자인지 Check하는 함수
    //파라메터는 오브젝트로 전달
    function maspCheckNumber(obj, comment, mendentory){

	    obj.value       = maspTrim(obj.value);                   //공백제거
	    var check_value = maspReplaceString(obj.value, ",", ""); //콤마제거

	    obj.value = check_value; //콤마를 없앤다

        if(check_value.length == 0 && mendentory){
            alert(comment + " 필드가 입력되지 않았습니다.\n" + comment + " 필드는 필수 입력항목입니다.\n\n 예) 1234");
            obj.focus();
            return false;
        }else if(check_value.length != 0){
            if(isNaN(check_value)){
                alert(comment + " 필드는 숫자만 입력 가능합니다.\n" + "문자는 사용할 수 없습니다.");
                obj.focus();
                obj.select();

                return false;
            }
            else{
                return true;
            }
        }
        return true;
    }

    //숫자체크(숫자여부와 널체크)
    //오브젝트의 값이 숫자인지 숫자인 경우 자릿수 체크Check하는 함수
    //파라메터는 오브젝트로 전달
    function maspCheckNumber2(obj,  startLength, endLength, comment, mendentory){

        obj.value       = maspTrim(obj.value);                   //공백제거
        var check_value = maspReplaceString(obj.value, ",", ""); //콤마제거

        data_length = check_value.length; //콤마를 없앤다

        if(check_value.length == 0 && mendentory){
            alert(comment + " 필드가 입력되지 않았습니다.\n" + comment + " 필드는 필수 입력항목입니다.\n\n 예) 1234");
            obj.focus();
            return false;

        }
        else if(check_value.length != 0){
            if(isNaN(check_value)){
                alert(comment + " 필드는 숫자만 입력 가능합니다.\n" + "문자는 사용할 수 없습니다.");
                obj.focus();
                obj.select();
            }
            else if(startLength==0 && endLength ==0){
                return true;
            }
            else if(startLength ==  endLength && startLength !=  data_length){
                alert(comment + "의 입력값은 정수 "+startLength+"자리가 입력되어야 합니다.\n");
                obj.focus();
                obj.select();
            }
            else if(startLength==0 && endLength < data_length){
                alert(comment + "의 입력값은 정수 "+endLength+"자리이하 입력되어야 합니다.\n");
                obj.focus();
                obj.select();
            }
            else if(startLength > data_length  && endLength == 0){
                alert(comment + "의 입력값은 정수 "+startLength+"자리이상  입력되어야 합니다.\n");
                obj.focus();
                obj.select();
            }
            else if((startLength > data_length) || (data_length > endLength)){
                if(startLength !=0 && endLength !=0)        {
                    alert(comment + "의 입력값은 정수 "+startLength+"자리이상 "+endLength+"자리이하가 입력되어야 합니다.\n");
                    obj.focus();
                    obj.select();
                }
                else{
                    return true;
                }
            }
            else{
                return true;
            }

            return false;
        }
        return true;
    }



/*********************************************************************
*************************     날짜체크     ***************************
/********************************************************************/


    //날짜 조건필드의 유효성을 검사하는 함수
    //파라메터는 오브젝트로 전달, 리턴값은 Boolean 형식
    //date_length : 숫자 8or6or10만 가능 (dateObj의 입력받을 자리수
    function maspCheckDate(dateObj, comment, mendentory, date_length){

        dateObj.value = maspTrim(dateObj.value); //공백제거

        var month     = new Array("31", "29", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31");
        var dateMonth = '';
        var dateDay   = '';

        var dateLen   = dateObj.value.length;

        var maspDate  = maspReplaceString(dateObj.value, "-", "");

        if(date_length == 4){
            dateMonth = '01';
            dateDay   = '01';
        }
        else if(date_length == 6) {
            dateMonth = maspDate.substring(4, 6);
            dateDay   = '01';

        }
        else{
            dateMonth = maspDate.substring(4, 6);
            dateDay   = maspDate.substring(6, 8);
        }

        var ex = "";
        if(date_length == 4)      ex = "2000";
        else if(date_length == 6) ex = "2001-01";
        else                      ex = "2001-12-31";

        //년월일이 입력되었는지 Check
        //필수 입력항목일 경우
        if((maspDate.length == 0)  && mendentory){
            alert(comment + " 필드가 입력되지 않았습니다.\n"        +
                  comment   + " 는(은) 필수 입력항목입니다.\n\n 예) " + ex);
            dateObj.focus();
        }

        //필수입력항목이 아닌 경우에 입력한경우
        else if(maspDate.length != 0){
            if(date_length != dateLen){
                alert(comment + " 날짜가 입력되지 않았거나\n날짜길이("+date_length+"자리)가 잘못 입력되었습니다.\n\n 예) "+ex);
                dateObj.focus();
                dateObj.select();
            }
            //날짜 형식 Check
            else if(isNaN(maspDate)){

                alert(comment + " 의 날짜 형식은 숫자만 가능합니다.\n날짜형식을 확인바랍니다.\n\n 예) "+ex);
                dateObj.focus();
                dateObj.select();
            }
            //날짜형식중 '월'의 범위 Check
            else if((dateMonth < '01') || (dateMonth > '12')){

                alert(comment + "의 날짜형식(월)이 잘못 입력되었습니다.\n월은 1월부터 12월까지 입력가능합니다.\n\n 예) "+ex);
                dateObj.focus();
                dateObj.select();
            }
            //날짜형식중 '일'의 범위 Check
            else if( date_length == 8 && (dateDay < '01') || (dateDay > month[dateMonth - 1])){
                alert(comment + "의 날짜형식(일)이 잘못 입력되었습니다.\n" + dateMonth + " 월은 1일부터 " + month[dateMonth - 1] + "일까지 입력가능합니다.\n\n 예) "+ex);
                dateObj.focus();
                dateObj.select();
            }
            else{
                return true;
            }
        }
        else{
            return true;
        }

        return false;

    }
    
    function checkDate(obj){
		var len = obj.value.length;
		var returnValue = true;
		if(len == 4){
			obj.value = obj.value + '-';
		}
		if(len == 7){
			obj.value = obj.value + '-';
		}
		
		//숫자만 입력 받는다.
		for (var i=0;i<obj.value.length;i++)
		{
			if(i != 4 && i != 7){
				if(isNaN(obj.value.charAt(i)))
					returnValue = false;
			
				if (!returnValue){
					if(i == len-1){
						obj.value=obj.value.substring(0,len-1);
						returnValue = true;
					}else{
						pre_str = obj.value.substring(0, i);
			            post_str = obj.value.substring(i+1, len);
			            obj.value = pre_str + post_str;
			            returnValue = true;
			        }
				}
			}
		}
	}


	//날짜범위를 입력받아 체크한다
	//시작일자, 종료일자, 컬럼명, 필수입력여부, 날짜길이(8로 고정해서 사용함)
	//파라메터는 오브젝트로 전달, 리턴값은 Boolean 형식
    function maspCheckDate2(startDate, endDate, comment, mendentory, datalength){

	    startDate.value = maspTrim(startDate.value); //공백제거
	    endDate.value   = maspTrim(endDate.value);   //공백제거

        var month = new Array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31");

        var startDateLen = startDate.value.length;
        var endDateLen  = endDate.value.length;

        var maspStartDate = maspReplaceString(startDate.value, "-", "");
        var maspEndDate   = maspReplaceString(endDate.value,   "-", "");

        var startMonth = maspStartDate.substring(4, 6);
        var endMonth   = maspEndDate.substring(4, 6);

        var startDay = '';
        var endDay   = '';
        var startEx  = '';
        var endEx    = '';

        if(datalength  == null) datalength=8;

        if(datalength == 6)     {
            startDay = '01';
            startEx  = '2000-11';
            endDay   = '01';
            endEx    = '2000-12';
        }
        else{
            startDay = maspStartDate.substring(6, 8);
            startEx = '2001-01-01';
            endDay  = maspEndDate.substring(6, 8);
            endEx   = '2001-12-31';
        }

        //시작일과 종료일이 입력되었는지 Check
        //필수 입력항목일 경우
        if(((maspStartDate.length == 0) && (maspEndDate.length == 0)) && mendentory){
            alert(comment + " 필드가 입력되지 않았습니다.\n" +  comment + " 범위는 필수 입력항목입니다.\n\n 예) "+startEx+" ~ " +endEx);
            startDate.focus();
        }

        //필수입력항목이 아닌 경우에 조회범위를 입력한 경우
        else if((maspStartDate.length != 0) || (maspEndDate.length != 0)){
            if(datalength != startDateLen){
                alert(comment + " 범위의 시작일이 입력되지 않았거나\n날짜길이("+datalength+"자리)가 잘못 입력되었습니다.\n\n 예) "+startEx+" ~ " +endEx);
                startDate.focus();
                startDate.select();
            }
            else if(datalength != endDateLen){
                alert(comment + " 범위의 종료일이 입력되지 않았거나\n날짜길이("+datalength+"자리)가 잘못 입력되었습니다.\n\n 예) "+startEx+" ~ " +endEx);
                endDate.focus();
                endDate.select();
            }

            //날짜 형식 Check
            else if(isNaN(maspStartDate)){
                alert(comment + " 범위의 시작일 형식은 숫자만 가능합니다.\n시작일 날짜형식을 확인바랍니다.\n\n 예) "+startEx+" ~ " +endEx);
                startDate.focus();
                startDate.select();
            }
            else if(isNaN(maspEndDate)){
                alert(comment + " 범위의 종료일 형식은 숫자만 가능합니다.\n종료일 날짜형식을 확인바랍니다.\n\n 예) "+startEx+" ~ " +endEx);
                endDate.focus();
                endDate.select();
            }
            //날짜형식중 '월'의 범위 Check
            else if((startMonth < '01') || (startMonth > '12')){
                alert("시작 " + comment + "의 날짜형식(월)이 잘못 입력되었습니다.\n월은 1월부터 12월까지 입력가능합니다.\n\n 예) "+startEx+" ~ " +endEx);
                startDate.focus();
                startDate.select();
            }
            else if((endMonth < '01') || (endMonth > '12')){
                alert("종료 " + comment + "의 날짜형식(월)이 잘못 입력되었습니다.\n월은 1월부터 12월까지 입력가능합니다.\n\n 예) "+startEx+" ~ " +endEx);
                endDate.focus();
                endDate.select();
            }
            //날짜형식중 '일'의 범위 Check
            else if((startDay < '01') || (startDay > month[startMonth - 1])){
                alert("시작 " + comment + "의 날짜형식(일)이 잘못 입력되었습니다.\n" + startMonth + " 월은 1일부터 " + month[startMonth - 1] + "일까지 입력가능합니다.\n\n 예) "+startEx+" ~ " +endEx);
                startDate.focus();
                startDate.select();
            }
            else if((endDay < '01') || (endDay > month[endMonth - 1])){
                alert("종료 " + comment + "의 날짜형식(일)이 잘못 입력되었습니다.\n" + endMonth + " 월은 1일부터 " + month[endMonth - 1] + "일까지 입력가능합니다.\n\n 예) "+startEx+" ~ " +endEx);
                endDate.focus();
                endDate.select();
            }
            //시작일과 종료일보다 값이 큰 경우
            else if (maspStartDate > maspEndDate){
                alert(comment + " 범위가 잘못되었습니다.\n날짜 범위를 확인바랍니다.\n\n 예) "+startEx+" ~ " +endEx);
                endDate.focus();
                endDate.select();
            }
            else{
                return true;
            }
        }
        else{
            return true;
        }
        return false;
    }

    function maspCheckDate3(startDate, endDate, startComment, endComment, mendentory, datalength){

	    startDate.value = maspTrim(startDate.value); //공백제거
	    endDate.value   = maspTrim(endDate.value);   //공백제거

        var month = new Array("31", "28", "31", "30", "31", "30", "31", "31", "30", "31", "30", "31");

        var startDateLen = startDate.value.length;
        var endDateLen  = endDate.value.length;

        var maspStartDate = maspReplaceString(startDate.value, "-", "");
        var maspEndDate   = maspReplaceString(endDate.value,   "-", "");

        var startMonth = maspStartDate.substring(4, 6);
        var endMonth   = maspEndDate.substring(4, 6);

        var startDay = '';
        var endDay   = '';
        var startEx  = '';
        var endEx    = '';

        if(datalength  == null) datalength=8;

        if(datalength == 6)     {
            startDay = '01';
            startEx  = '2000-11';
            endDay   = '01';
            endEx    = '2000-12';
        }
        else{
            startDay = maspStartDate.substring(6, 8);
            startEx = '2001-01-01';
            endDay  = maspEndDate.substring(6, 8);
            endEx   = '2001-12-31';
        }

        //시작일과 종료일이 입력되었는지 Check
        //필수 입력항목일 경우
        if(((startDate.value.length == 0) && (endDate.value.length == 0)) && mendentory){
            alert(startComment + " 필드가 입력되지 않았습니다.\n" + startComment +" 필드는 필수 입력항목입니다.\n\n ");
            startDate.focus();
        }
        //필수입력항목이 아닌 경우에 조회범위를 입력한 경우
        else if((startDate.value.length != 0) || (endDate.value.length != 0)){
            if(startDateLen != datalength){
                alert(startComment + "의 자리수가 잘못 입력되었습니다.\n날짜형식을 확인바랍니다.\n\n 예) "+startEx);
                startDate.focus();
                startDate.select();

            }
            else if(endDateLen != datalength){
                alert(endComment + "의 자리수가 잘못 입력되었습니다.\n날짜형식을 확인바랍니다.\n\n 예) "+endEx);
                endDate.focus();
                endDate.select();
            }
            //날짜 형식 Check
            else if(isNaN(maspStartDate)){
                alert(startComment + "의 형식은 숫자만 가능합니다.\n날짜형식을 확인바랍니다.\n\n 예) "+startEx);
                startDate.focus();
                startDate.select();
            }
            else if(isNaN(maspEndDate)){
                alert(endComment + "의 형식은 숫자만 가능합니다.\n날짜형식을 확인바랍니다.\n\n 예) "+endEx);
                endDate.focus();
                endDate.select()
            }
            //날짜형식중 '월'의 범위 Check
            else if((startMonth < '01') || (startMonth > '12')){
                alert(startComment + "의 날짜형식(월)이 잘못 입력되었습니다.\n월은 1월부터 12월까지 입력가능합니다.\n\n 예) "+startEx+" ~ " +endEx);
                startDate.focus();
                startDate.select();
            }
            else if((endMonth < '01') || (endMonth > '12')){
                alert(endComment + "의 날짜형식(월)이 잘못 입력되었습니다.\n월은 1월부터 12월까지 입력가능합니다.\n\n 예) "+startEx+" ~ " +endEx);
                endDate.focus();
                endDate.select()
            }
            //날짜형식중 '일'의 범위 Check
            else if((startDay < '01') || (startDay > month[startMonth - 1])){
                alert("시작 " + startComment + "의 날짜형식(일)이 잘못 입력되었습니다.\n" + startMonth + " 월은 1일부터 " + month[startMonth - 1] + "일까지 입력가능합니다.\n\n 예) "+startEx+" ~ " +endEx);
                startDate.focus();
                startDate.select();
            }
            else if((endDay < '01') || (endDay > month[endMonth - 1])){
                alert("종료 " + endComment + "의 날짜형식(일)이 잘못 입력되었습니다.\n" + endMonth + " 월은 1일부터 " + month[endMonth - 1] + "일까지 입력가능합니다.\n\n 예) "+startEx+" ~ " +endEx);
                endDate.focus();
                endDate.select()
            }
            //시작일과 종료일보다 값이 큰 경우
            else if (startDate.value > endDate.value){
                alert(endComment + "의 날짜가 " + startComment + "의 날짜보다 이전입니다.\n" + startComment + " 이후로 입력하십시오.\n\n 예) "+startDate.value+" 이후 날짜 " );
                endDate.focus();
                endDate.select();
            }
            else{
                return true;
            }
        }
        else{
            return true;
        }
        return false;

    }

/*********************************************************************
*************************     영문숫자체크     ***********************
/********************************************************************/


	//코드성 컬럼의 입력에서 영문자와 숫자만 사용가능하게 한다
	//한글이 입력된 경우 에러를 리턴한다
    function maspCheckAlphaNum(obj, comment, mendentory){

    	obj.value = maspTrim(obj.value); //공백제거

        if((obj.value.length == 0) && mendentory){
            alert(comment + " 필드가 입력되지 않았습니다.\n" + comment + " 필드는 필수 입력항목입니다.\n\n ");
            obj.focus();
        }else if(obj.value.length != 0){
            check_ahpaNum = true;
            for (i = 0; i < obj.value.length && check_ahpaNum; i++){
                if((obj.value.charAt(i) >= 0   && obj.value.charAt(i) <= 9)   ||
                    (obj.value.charAt(i)  >= 'A' && obj.value.charAt(i) <= 'Z') ||
                    (obj.value.charAt(i)  >= 'a' && obj.value.charAt(i) <= 'z') ||
                    (obj.value.charAt(i)  == '-')){
                    ;
                }else{
                    check_ahpaNum = false;
                }
            }

            if(check_ahpaNum){
                return true;
            }else{
                alert(comment + " 필드는 영문자('-'포함)와 숫자만 입력가능합니다.\n" + "한글과 특수문자는 사용할 수 없습니다.");
                obj.focus();
                obj.select();
            }
        }else{
            return true;
        }

        return false;
    }



    //코드성 컬럼의 입력에서 영문자와 숫자만 사용가능하게 한다
    //한글이 입력된 경우 에러를 리턴한다
    //정상적인 경우 대문자로 바꾸어준다(코드가 대문자를 사용하는 경우)
    function maspCheckAlphaNum2(obj, comment, mendentory){

    obj.value = maspTrim(obj.value); //공백제거

        if((obj.value.length == 0) && mendentory){
            alert(comment + " 필드가 입력되지 않았습니다.\n" + comment + " 필드는 필수 입력항목입니다.\n\n ");
            obj.focus();
        } else if(obj.value.length != 0){
            check_ahpaNum = true;
            for (i = 0; i < obj.value.length && check_ahpaNum; i++){
                if((obj.value.charAt(i) >= 0   && obj.value.charAt(i) <= 9)   ||
                    (obj.value.charAt(i)  >= 'A' && obj.value.charAt(i) <= 'Z') ||
                    (obj.value.charAt(i)  >= 'a' && obj.value.charAt(i) <= 'z') ||
                    (obj.value.charAt(i)  == '-')){
                    ;
                }
                else{
                    check_ahpaNum = false;
                }
            }
            if(check_ahpaNum){
                lCase2Ucase(obj);
                return true;
            }
            else{
                alert(comment + " 필드는 영문자('-'포함)와 숫자만 입력가능합니다.\n" + "한글과 특수문자는 사용할 수 없습니다.");
                obj.focus();
                obj.select();
            }
        } else {
            lCase2Ucase(obj);
            return true;
        }

        return false;
    }

    //코드성 컬럼의 입력에서 영문자만 사용가능하게 한다
    //한글이 입력된 경우 에러를 리턴한다
    //정상적인 경우 대문자로 바꾸어준다(코드가 대문자를 사용하는 경우)
    function maspCheckAlpha(obj, comment, mendentory){

    	obj.value = maspTrim(obj.value); //공백제거

        if((obj.value.length == 0) && mendentory){
            alert(" Please! input data to " + comment + " field");
            obj.focus();
        } else if(obj.value.length != 0){
            check_ahpaNum = true;
            for (i = 0; i < obj.value.length && check_ahpaNum; i++){
                if((obj.value.charAt(i)  >= 'A' && obj.value.charAt(i) <= 'Z') ||
                    (obj.value.charAt(i)  >= 'a' && obj.value.charAt(i) <= 'z')){
                    ;
                }
                else{
                    check_ahpaNum = false;
                }
            }
            if(check_ahpaNum){
                lCase2Ucase(obj);
                return true;
            }else{
                alert(comment + " 필드는 영문자만 입력가능합니다.");
                obj.focus();
                obj.select();
            }
        } else {
            lCase2Ucase(obj);
            return true;
        }

        return false;
    }

	//영문자와 특수문자중 (/,-,*) 을 제외하고 모두 들어가게 함.
    function maspCheckAlpha2(obj, comment){

    	obj.value = maspTrim(obj.value); //공백제거

        if(obj.value.length != 0){
            check_ahpaNum = true;
            for (i = 0; i < obj.value.length && check_ahpaNum; i++){
                if((obj.value.charAt(i)  >= 'A' && obj.value.charAt(i) <= 'Z') ||
                    (obj.value.charAt(i)  >= 'a' && obj.value.charAt(i) <= 'z') ||
                    (obj.value.charAt(i) >= 0   && obj.value.charAt(i) <= 9) ||
					(obj.value.charAt(i)  == '~' ) ||
                    (obj.value.charAt(i)  == '!' ) ||
                    (obj.value.charAt(i)  == '@' ) ||
                    (obj.value.charAt(i)  == '#' ) ||
                    (obj.value.charAt(i)  == '$' ) ||
                    (obj.value.charAt(i)  == '%' ) ||
					(obj.value.charAt(i)  == '^' ) ||
					(obj.value.charAt(i)  == '&' ) ||
					(obj.value.charAt(i)  == '(' ) ||
					(obj.value.charAt(i)  == ')' ) ||
					(obj.value.charAt(i)  == '?' ) ||
					(obj.value.charAt(i)  == '+' ) ||
					(obj.value.charAt(i)  == '=' ) ||
					(obj.value.charAt(i)  == '|' ) ||
					//(obj.value.charAt(i)  == '\' ) ||
					(obj.value.charAt(i)  == ',' ) ||
					(obj.value.charAt(i)  == '.' ) ||
					(obj.value.charAt(i)  == ',' ) ||
					(obj.value.charAt(i)  == '`' )){
                    ;
                }
                else{
                    check_ahpaNum = false;
                }
            }
            if(check_ahpaNum){
                return true;
            }
            else {
            	alert(comment + " 필드에는 영문,숫자 특수문자만 입력가능합니다.\n단 -,/,*,\\ 은 입력할 수 없습니다.");	
            }
        }

        return false;
    }

    //전화번호 -   숫자 , ( ) * # ~ -  허용
    function maspCheckPhone(obj, comment, mendentory){

    	obj.value = maspTrim(obj.value); //공백제거

        if((obj.value.length == 0) && mendentory){
            alert(comment + " 필드가 입력되지 않았습니다.\n" + comment + " 필드는 필수 입력항목입니다.\n\n 예) 012-345-6789");
            obj.focus();
        }
        else if(obj.value.length != 0){
            check_ahpaNum = true;
            for (i = 0; i < obj.value.length && check_ahpaNum; i++){
                if((obj.value.charAt(i) >= 0   && obj.value.charAt(i) <= 9)   ||
                    (obj.value.charAt(i)  == ',' ) ||
                    (obj.value.charAt(i)  == '*' ) ||
                    (obj.value.charAt(i)  == '#' ) ||
                    (obj.value.charAt(i)  == '~' ) ||
                    (obj.value.charAt(i)  == '-')){
                    ;
                }
                else{
                    check_ahpaNum = false;
                }
            }
            if(check_ahpaNum){

                return true;
            }
            else{
                alert(comment + " 필드는 ('-','~','*','#',',' 포함) 영숫자만 입력가능합니다.\n" + "그외의 문자는 사용할 수 없습니다.");
                obj.focus();
                obj.select();
            }
        } else {

            return true;
        }

        return false;
    }

    //이름 -   영문 숫자 , ( ) . - _  허용
    function maspCheckEngName(obj, comment, mendentory){

    	obj.value = maspTrim(obj.value); //공백제거

        if((obj.value.length == 0) && mendentory){
            alert(comment + " 필드가 입력되지 않았습니다.\n" + comment + " 필드는 필수 입력항목입니다.\n\n 예) E.M.Kim");
            obj.focus();
        }else if(obj.value.length != 0){
            check_ahpaNum = true;
            for (i = 0; i < obj.value.length && check_ahpaNum; i++){
                if((obj.value.charAt(i) >= 0   && obj.value.charAt(i) <= 9)   ||
                   (obj.value.charAt(i)  >= 'A' && obj.value.charAt(i) <= 'Z') ||
                   (obj.value.charAt(i)  >= 'a' && obj.value.charAt(i) <= 'z') ||
                   (obj.value.charAt(i)  == ',' ) ||
                   (obj.value.charAt(i)  == '-' ) ||
                   (obj.value.charAt(i)  == '_' ) ||
                   (obj.value.charAt(i)  == '.' )){
                   ;
                }
                else{
                    check_ahpaNum = false;
                }
            }
            if(check_ahpaNum){

                return true;
            }
            else{
                alert(comment + " 필드는 ('-', '_', ',', '.'포함) 영숫자만 입력가능합니다.\n" + "그외의 문자는 사용할 수 없습니다.");
                obj.focus();
                obj.select();
            }
        } else {

            return true;
        }

        return false;
    }
    
    
    //이름 -   영문 숫자  허용
    function maspCheckEngName2(obj, comment){

    	obj.value = maspTrim(obj.value); //공백제거

        if(obj.value.length != 0){
            check_ahpaNum = true;
            for (i = 0; i < obj.value.length && check_ahpaNum; i++){
                if((obj.value.charAt(i) >= 0   && obj.value.charAt(i) <= 9)   ||
                   (obj.value.charAt(i)  >= 'A' && obj.value.charAt(i) <= 'Z') ||
                   (obj.value.charAt(i)  >= 'a' && obj.value.charAt(i) <= 'z')) {
                   ;
                }
                else{
                    check_ahpaNum = false;
                }
            }
            if(check_ahpaNum){

                return true;
            }
            else{
                alert(comment + " 필드는 영문과 숫자만 입력가능합니다.\n" + "그외의 문자는 사용할 수 없습니다.");
                obj.focus();
                obj.select();
            }
        } 

        return false;
    }
    
    
    // 영문만 사용가능
    function maspCheckEng(obj, comment){

    	obj.value = maspTrim(obj.value); //공백제거

        if(obj.value.length != 0){
            check_ahpaNum = true;
            for (i = 0; i < obj.value.length && check_ahpaNum; i++){
                if((obj.value.charAt(i)  >= 'A' && obj.value.charAt(i) <= 'Z') ||
                   (obj.value.charAt(i)  >= 'a' && obj.value.charAt(i) <= 'z')) {
                   ;
                }
                else{
                    check_ahpaNum = false;
                }
            }
            if(check_ahpaNum){

                return true;
            }
            else{
                alert(comment + " 필드는 영문만 입력가능합니다.\n" + "그외의 문자는 사용할 수 없습니다.");
                obj.focus();
                obj.select();
            }
        } 

        return false;
    }
    
    
    // 숫자 만 사용가능
    function maspCheckNum(obj, comment){

    	obj.value = maspTrim(obj.value); //공백제거

        if(obj.value.length != 0){
            check_ahpaNum = true;
            for (i = 0; i < obj.value.length && check_ahpaNum; i++){
                if(obj.value.charAt(i) >= 0  && obj.value.charAt(i) <= 9){
                   ;
                }
                else{
                    check_ahpaNum = false;
                }
            }
            if(check_ahpaNum){

                return true;
            }
            else{
                alert(comment + " 필드는 숫자만 입력가능합니다.\n" + "그외의 문자는 사용할 수 없습니다.");
                obj.focus();
                obj.select();
            }
        } 

        return false;
    }

/*********************************************************************
***************주민번호 check 하는 함수      *************************
/********************************************************************/
	function maspCheckSocialNo(obj){

		var socialno = obj.value;
		var socialno_length =  socialno.length;

		if(socialno_length != 14){
			alert("주민등록번호의 입력크기가 잘못되었습니다.\n14자리를 다시 입력하여 주십시요!");
			obj.focus();
			obj.select();
			return false;
		}
		if(socialno.substring(6,7) != "-"){
			alert("주민등록번호의 구분자는 '-'만 입력가능합니다.\n다시입력하여 주십시요!");
			obj.focus();
			obj.select();
			return false;
		}

		socialno = socialno.substring(0,6) + socialno.substring(7,14);

		if(isNaN(socialno) || socialno.indexOf(".") != -1){
			alert("주민등록번호의 입력값이 잘못되었습니다.\n다시입력하여 주십시요!");
			obj.focus();
			obj.select();
			return false;
		}

		strKeyValue = new String("234567892345");
		strSocialNo = new String(socialno);

		DigitSum = 0;

		for(i=0; i<=11; i++) {
			DigitSum = DigitSum + parseInt(strSocialNo.substring(i, i+1)) * parseInt(strKeyValue.substring(i, i+1));
		}

		i = 1;

		while((i * 11) <= DigitSum){
			i = i + 1;
		}

		CheckDigit =((i * 11) - DigitSum) % 10;

		if(CheckDigit == strSocialNo.substring(12, 13)) {
			return true;
		}
		else {
			alert("주민등록번호의 입력값이 잘못되었습니다.\n다시입력하여 주십시요!");
			obj.focus();
			obj.select();
			return false;
		}
	}
/*********************************************************************
*************************     파일체크     ***************************
/********************************************************************/


	//파일업로드가 여러개일때 체크 로직
	function check_AllFile(obj,filetype){
		//파일업로드가 여러개일때 체크 로직
		var count = 0;
		var length = 0;

		if(obj.length == null){
			length = 1
			if(check_File(obj ,filetype) == false) return false;
		}else{
			length = obj.length

			for (i=0; i< length; i++){
				if(obj[i].value == '') count ++;
			}

			if(count == length){
				var ans = confirm("첨부화일 없이 처리하시겠습니까?")
				if(ans == false){
					obj[0].focus();
					obj[0].select();
					return false;
				}
			}else{
				for (i=0; i< length; i++){
					if(obj[i].value != ''  && check_File(obj[i] ,filetype)== false)  return false;
				}
			}

			for(var i=0;i<length;i++){
				for (var j=i+1;j<length;j++){
					// alert('i번째 : form.filename['+i+']:j+1번째 ['+(j)+']');
					if(obj[i].value == obj[j].value && obj[i].value !=''){
						alert((i+1)+'번째화일과 '+(j+1)+'번째 화일이 동일합니다.\n다른 파일을 선택하세요');
						obj[j].focus();
						obj[j].select();
						return false;
					}
				}
			}
		}

		return true;
	}

    function maspCheckFiles( addfile, ndx, filetype, maxcount,mendentory){

		var count = 0;

		if( maxcount == null) maxcount = 1;

		var obj = new Array(maxcount);
		var filecount = 0;

		for (i=0; i < maxcount; i++){

			obj[i] = eval(addfile + parseInt(i + 1) + ndx );

			if(obj[i] == null ){
				alert("debug: " + addfile + (i + 1) + ndx + " 존재하지 않음. " )
				return false;
			}

			if( obj[i].value != ''){
				if( check_File(obj[i] ,filetype) == false )  return false;
				else filecount++;
			}
		}

		for (i=0; i < maxcount; i++){

			if( obj[i].value == '' ) continue;

			for (var j=i+1 ;j< maxcount; j++){

				if(obj[i].value == obj[j].value && obj[i].value !=''){
					alert((i+1)+'번째화일과 '+(j+1)+'번째 화일이 동일합니다.\n다른 파일을 선택하세요');
					obj[j].focus();
					obj[j].select();

					return false;
				}
			}

		}

		if( filecount == 0 && mendentory){
			var ans = confirm("첨부화일 없이 처리하시겠습니까?")
			if(ans == false){
				obj[0].focus();
				obj[0].select();
				return false;
			}
		}

		return true;
    }


    //file tag check
    function check_File(obj, type){
        var fileName     = obj.value;
        var errFlag      = "true";

        if((fileName == "")){
           var ans = confirm("첨부화일 없이 처리하시겠습니까?");
           if(ans == false){
                obj.focus();
                obj.select();
                return false;
           }
           else{
                return true;
           }
        }
        else{
            /*
            var upload_info = infoObj.value

            if(upload_info == 'P')
                alert('파일업로드 중입니다.\\n완료된후에 진행하세요..');
            else if(upload_info == 'N')
                alert('파일업로드메세지를 확인하시고 다시 확인 버튼을 누르십시오');
            */

            if(fileName == ''){
                alert('파일을 지정하세요 !!!');
                obj.focus();
                obj.select();
                return false;
            }
            else if(fileName.substring(1,2) != ':'){
                alert('전송할 파일을 선택하세요!');
                obj.focus();
                obj.select();
                return false;
            }
            else  if(   fileName.indexOf('&' ) != -1 ||
                        fileName.indexOf('%' ) != -1 ||
                        fileName.indexOf('\'') != -1 ||
                        fileName.indexOf('+' ) != -1
                    ){
                alert('전송할 화일명이 &,%,\',+ 등을 포함하지 않아야 합니다.');
                obj.focus();
                obj.select();
                return false;
            }
            else{

                var  filetype = maspGetFileType(fileName).toLowerCase();

                if(type.toLowerCase() != '*'  && type.toLowerCase() != filetype){
                    alert('전송할 화일명의 확장자는 반드시 .' + type + '이어야 합니다.');
                    obj.focus();
                    obj.select();
                    return false;
                }

            }

            return true
        }//file태그에 값이 있을때
    }

    function maspCheckFile(obj, type, mendentory){
        var fileName     = obj.value;
        var errFlag      = "true";

        if(fileName == "" && mendentory){

            alert('파일을 지정하세요 !!!');
            obj.focus();
            obj.select();
            return false;

        }
        else if(fileName == "" && ! mendentory){
            return true;
        }
        else if(fileName != "" )
        {

            if(fileName.substring(1,2) != ':'){
                alert('전송할 파일을 선택하세요!');
                obj.focus();
                obj.select();
                return false;
            }
            else  if(   fileName.indexOf('&' ) != -1 ||
                        fileName.indexOf('%' ) != -1 ||
                        fileName.indexOf('\'') != -1 ||
                        fileName.indexOf('+' ) != -1
                    ){
                alert('전송할 화일명이 &,%,\',+ 등을 포함하지 않아야 합니다.');
                obj.focus();
                obj.select();
                return false;
            }
            else{

                var  filetype = maspGetFileType(fileName).toLowerCase();

                if(type.toLowerCase() != '*'  && type.toLowerCase() != filetype){
                    alert('전송할 화일명의 확장자는 반드시 .' + type + '이어야 합니다.');
                    obj.focus();
                    obj.select();
                    return false;
                }

            }

            return true
        }//file태그에 값이 있을때
    }

function funcShowMsg(doc)
{

    var msg     = null;
    //Timer=setTimeout("funcNoting()", 1000);

    //최초 frame이 없을 경우 리턴
    if(doc == null)
    {
        //최초 mst_frame이 없을 경우 리턴
        //if(top.content.mst_frame.document != null && top.content.mst_frame.document.all["msg"] != null)

        if(top.content != null )
        //if( top.content.document.all["msg"] != null )
        {
            if( top.content.document.all["msg"] != null )
            {
                msg  =   top.content.document.all["msg"];
                //위¹지정
                msg.style.pixelLeft     =   (830  - 300 ) / 2 ;
                msg.style.pixelTop      =   top.content.document.body.scrollTop + 148 ;
                msg.style.visibility    =   "visible";

                Timer=setTimeout("funcNoting()", 100);
                return;
            }
        }

        if(top.content.mst_frame != null )
        //if( top.content.mst_frame.document.all["msg"] != null )
        {
            if( top.content.mst_frame.document.all["msg"] != null )
            {
                msg  =   top.content.mst_frame.document.all["msg"];
                //위치지정
                msg.style.pixelLeft     =   (830  - 300 ) / 2 ;
                msg.style.pixelTop      =   top.content.mst_frame.document.body.scrollTop + 120 ;
                msg.style.visibility    =   "visible";

                Timer=setTimeout("funcNoting()", 100);
                return;
            }
        }

        if(top.content.chd_frame != null )
        //if( top.content.chd_frame.document.all["msg"] != null )
        {
            if( top.content.chd_frame.document.all["msg"] != null )
            {
                msg  =   top.content.chd_frame.document.all["msg"];
                //위치지정
                msg.style.pixelLeft     =   (660  - 300 ) / 2 ;
                msg.style.pixelTop      =   top.content.chd_frame.document.body.scrollTop + 120 ;
                msg.style.visibility    =   "visible";

                Timer=setTimeout("funcNoting()", 100);
                return;
            }
        }

    }
    else
    {
         //최초 frame이 없을 경우 리턴
        if( doc.all["msg"] == null) return;

        msg                 =   doc.all["msg"];

        //위치지정
        msg.style.pixelLeft     =   (830  - 300 ) / 2 ;
        msg.style.pixelTop      =   doc.body.scrollTop + 120 ;
        msg.style.visibility    =   "visible";
        Timer=setTimeout("funcNoting()", 100);

    }

    return;

}

function funcHideMsg(doc)
{
    if(doc == null)
    {
        if(top.content != null )
        //if( top.content.document.all["msg"] != null )
        {
            if( top.content.document.all["msg"] != null )
            {
                top.content.document.all["msg"].style.visibility    =   "hidden";
                return;
            }
        }
        //최초 mst_frame이 없을 경우 리턴
        if(top.content.mst_frame != null )
        //if( top.content.mst_frame.document.all["msg"] != null )
        {
            if( top.content.mst_frame.document.all["msg"] != null )
            {
                top.content.mst_frame.document.all["msg"].style.visibility    =   "hidden";
                return;
            }
        }


        if(top.content.chd_frame != null )
        //if( top.content.chd_frame.document.all["msg"] != null )
        {
            if( top.content.chd_frame.document.all["msg"] != null )
            {
               top.content.chd_frame.document.all["msg"].style.visibility    =   "hidden";
               return;
            }
        }

    }
    else
    {
         //최초 frame이 없을 경우 리턴
        if(doc != null && doc.all["msg"] == null) return;

        doc.all["msg"].style.visibility    =   "hidden";
    }

    return;

}


//시간지연시 사용하는 빈 평션
function funcNoting()
{

}



// *****************************************************************
// 금액 입력시 세자리마다 콤마(,) 자동생성
// *****************************************************************
function maspReplaceComma(obj)
{
    var temp = "";                              // 소수점 이하부분 임시저장용

    var i = obj.value.indexOf(".");

    if(i > 0)                                   // 소수점을 찾아서 소수점 있을때만
    {
        temp = obj.value.substr(i,20);          // temp 에 소수점이하 저장
        obj.value = obj.value.substr(0,i);      // 정수부분만 저장
    }

    obj.value = maspTrim(obj.value);
    obj.value = maspReplaceString(obj.value, ",", ""); //콤마제거

    if(obj.value.length == 15) obj.value = obj.value.substr(0,3) + "," + obj.value.substr(3,3) + "," + obj.value.substr(6,3) + "," + obj.value.substr(9,3) + "," + obj.value.substr(12,3);
    if(obj.value.length == 14) obj.value = obj.value.substr(0,2) + "," + obj.value.substr(2,3) + "," + obj.value.substr(5,3) + "," + obj.value.substr(8,3) + "," + obj.value.substr(11,3);
    if(obj.value.length == 13) obj.value = obj.value.substr(0,1) + "," + obj.value.substr(1,3) + "," + obj.value.substr(4,3) + "," + obj.value.substr(7,3) + "," + obj.value.substr(10,3);

    if(obj.value.length == 12) obj.value = obj.value.substr(0,3) + "," + obj.value.substr(3,3) + "," + obj.value.substr(6,3) + "," + obj.value.substr(9,3);
    if(obj.value.length == 11) obj.value = obj.value.substr(0,2) + "," + obj.value.substr(2,3) + "," + obj.value.substr(5,3) + "," + obj.value.substr(8,3);
    if(obj.value.length == 10) obj.value = obj.value.substr(0,1) + "," + obj.value.substr(1,3) + "," + obj.value.substr(4,3) + "," + obj.value.substr(7,3);

    if(obj.value.length == 9 ) obj.value = obj.value.substr(0,3) + "," + obj.value.substr(3,3) + "," + obj.value.substr(6,3);
    if(obj.value.length == 8 ) obj.value = obj.value.substr(0,2) + "," + obj.value.substr(2,3) + "," + obj.value.substr(5,3);
    if(obj.value.length == 7 ) obj.value = obj.value.substr(0,1) + "," + obj.value.substr(1,3) + "," + obj.value.substr(4,3);

    if(obj.value.length == 6 ) obj.value = obj.value.substr(0,3) + "," + obj.value.substr(3,3);
    if(obj.value.length == 5 ) obj.value = obj.value.substr(0,2) + "," + obj.value.substr(2,3);
    if(obj.value.length == 4 ) obj.value = obj.value.substr(0,1) + "," + obj.value.substr(1,3);

    obj.value = obj.value + "" + temp;
}

/************************************************************************
2001-02-09 추가
화면의 body부분에 테이블이 존하는 경우에 cursor를 변화시키는 기능.
************************************************************************/
function cursorWait() {
	var sObjFrame, sObjCursor, sCursorName;

	sObjFrame = top.frames["content"];

	if (sObjFrame != null) {
		sObjCursor = top.content.document.getElementById("tblBackGrd");

		if (sObjCursor != null) {
			top.content.document.all.tblBackGrd.style.cursor='wait';
		}
	}
}

function cursorArrow() {
	var sObjFrame, sObjCursor, sCursorName;

	sObjFrame = top.frames["content"];

	if (sObjFrame != null) {
		sObjCursor = top.content.document.getElementById("tblBackGrd");

		if (sObjCursor != null) {
			top.content.document.all.tblBackGrd.style.cursor='';
		}
	}
}

/**********************************************************************
폼객체에 존재하는 Control에 대한 Value를 리턴한다.
**********************************************************************/
function getFindControlValue(objForm, sControl) { 	// 폼객체,'Control명'
	var iEleCnt, sControlValue;

	iEleCnt = objForm.elements.length;

	for (var i=0; i < iEleCnt; i++) {

        if (objForm.elements[i].name == sControl) {
        	sControlValue = objForm.elements[i].value;
        	return sControlValue;
        }
	}
    return '';
}


/**************************************************************
데이터 체크
***************************************************************/
//null 체크
function isNull(val) {
	var esc = val.match(/\S/);

	if (esc == '' || esc == null) {
		return true ;
	}
	else {
		return false;
	}
}

function checkNull(val) {
	var esc = val.match(/\S/);

	if (esc == '' || esc == null) {
		return ' 값을 입력하십시오!' ;
	}
	else {
		return '';
	}
}
/****************************************
메세지처리
****************************************/
function putMsg(pMsg, pAtt){
	msg = msg + repMsg(pMsg,pAtt);
}

function repMsg(pStr, pAtt){
	if (pStr == '') {
		return '';
	}

	cnt = cnt + 1;

	if (pAtt != '') {
		return  cnt + '. ' + pAtt + ' ==> ' + pStr + '\n';
	}
	else {
		return pStr + '\n';
	}
}

function getMsg() {
	return msg;
}

function initMsg() {
	msg 	= '';
	cnt 	= 0;
}

function isMsg() {
	if ((msg == '')||(msg == null)) {
		return false;
	}
	else {
		return true;
	}
}

	function chkStrVal(arg1, arg2, arg3){
		var tmpStr1;
		var tmpStr2;
		var idx;
		var idx1;
		var idx2;
		result = new Array(arg1.length);

		for(idx = 0; idx < arg1.length ; idx++){
			idx1 = arg1[idx].indexOf(arg2);
			tmpStr1 = arg1[idx].substring(idx1+arg2.length);
			idx2 = tmpStr1.indexOf(arg3);
			tmpStr2 = tmpStr1.substring(0, idx2-1);

			result[idx] = tmpStr2;
		}

		return result;
	}

	function setStrVal(arg1, arg2, arg3, arg4){
		var tmpStr1;
		var tmpStr2;
		var tmpReturn;
		var idx1;
		var idx2;

		idx1 = arg1.indexOf(arg2);
		tmpStr1 = arg1.substring(idx1+arg2.length);
		idx2 = arg1.indexOf(arg3);
		tmpStr2 = tmpStr1.substring(0, idx2-1);

		tmpReturn = arg1.substring(0, idx1+arg2.length) + arg4 + " " + arg1.substring(idx2);

		return tmpReturn;
	}

	function onRowAdd(arg1, arg2, val)
	{
		var CELLS = 0;
		var table;
		var row;
		var cell;
		var idx;
		table	= arg1;
		row		= table.insertRow();
		CELLS	= table.rows[0].cells.length;
		cell	= new Array(CELLS);

		for(idx = 0; idx < CELLS; idx++) cell[idx] = row.insertCell();

		cell[0].innerHTML = table.rows[0].cells[0].innerHTML;
		for(idx = 1; idx < CELLS; idx++)
			if(arg2 == 0)
				cell[idx].innerHTML = setStrVal(table.rows[0].cells[idx].innerHTML,  'value=', 'name=', val[idx-1]);
			else
				cell[idx].innerHTML = setStrVal(table.rows[0].cells[idx].innerHTML,  'value=', 'name=', "&nbsp;");

	}

	function onRowDel(arg1, arg2)
	{
		var idx;

		if(arg2.length){
			for(idx = arg1.rows.length - 1; idx >= 0; idx--){
				if(arg2[idx].checked)
					onRowRemove(arg1, idx, arg2);
			}
		}else{
			if(arg2.checked){
				onRowRemove(arg1, 0, arg2);
			}
		}
	}

	function onRowRemove(arg, idx, arg1)
	{
		var index = arg.rows.length;
		var celIdx;

		if(arg.rows.length){
			if(index > 1){
				arg.deleteRow(idx);
			}else{
				strArr	= new Array(arg.rows[0].cells.length - 1);
				for(celIdx = 1; celIdx < arg.rows[0].cells.length; celIdx++){
					strArr[celIdx-1] = arg.rows[idx].cells[celIdx].innerHTML;
				}

				onRowAdd(arg, 1, chkStrVal(strArr, 'value=', 'name='));

				arg.deleteRow(0);
			}
		}else{
			strArr	= new Array(arg.rows[0].cells.length - 1);
			for(celIdx = 1; celIdx < arg.rows[0].cells.length; celIdx++){
				strArr[celIdx-1] = arg.rows[idx].cells[celIdx].innerHTML;
			}

			onRowAdd(arg, 1, chkStrVal(strArr, 'value=', 'name='));

			arg.deleteRow(0);
		}
	}

	function onKeyUpReformat(obj, chr, maxlen, gap)
	{
		var chk	= obj.value.substring(obj.value.length -1, obj.value.length);
		var str = maspReplaceString(obj.value,chr,"");
		var len	= str.length;
		if(len < maxlen){
		    if(len != 0 && chk != chr && len%gap == 0){
		      obj.value = obj.value + chr;
		    }
		}else if(len > maxlen){
			obj.value = obj.value.substring(0, obj.value.length -1);
		}
	}

	//-----------------------------------------
	// 사용예 JSP --> onKeyUp="addComma(this)"
	// 12345.22 --> 12,345.22형태로  변경
	// 숫자만 입력 가능합니다..
	//-----------------------------------------
	function onKeyUpAddComma(obj)
	{
		var txtNumber;
		if (obj == '[object]')
		{
			txtNumber  = removeComma(obj.value);
		}
		else
		{
			txtNumber  = removeComma(obj);
		}

		var rxSplit = new RegExp('([0-9])([0-9][0-9][0-9][,.])');
		var arrNumber = txtNumber.split('.');

		//숫자인지 check
		if( !checkDigit(arrNumber.join('')) )
		{
			alert("숫자만 입력 가능합니다.");

			if(obj == '[object]')
			{
				obj.focus();
				obj.select();
				return obj.value;
			}

			return obj;
		}

		arrNumber[0] += '.';

		do
		{
			arrNumber[0] = arrNumber[0].replace(rxSplit, '$1,$2');
		}
		while (rxSplit.test(arrNumber[0]));

		if (arrNumber.length > 1)
		{
			if(obj == '[object]')
			{
				obj.value = arrNumber.join('');
			}
			return arrNumber.join('');
		}
		else
		{
			if(obj == '[object]')
			{
				obj.value = arrNumber[0].split('.')[0];
			}
			return arrNumber[0].split('.')[0];
	    }
	}

	//-----------------------------
	// 12,345.22 --> 12345.22  변경
	//-----------------------------
	function removeComma(obj)
	{

	    var want_val = '';

	    var resultVal = '';

	    if(obj == '[object]')      // obj가 Object면
	    {
	    	resultVal = obj.value;
	    }
	    else
	    {
	    	resultVal = obj;
	    }


	    if (resultVal.length < 1)
	    {
	    	if(obj == '[object]')      // obj가 Object면
	    	obj.value = want_val;

	    	return want_val;
	    }

	    //값이 존재하여야만 연산을 수행함

	    if (resultVal.length != 0)
	    {
	         for(var i=0; i < resultVal.length; i++)    //<,>단위의 표기법을 연산 형식으로 변환
	         {
	             var digit = resultVal.charAt(i);   //i 이전의 문자를 반영한다

	             if(digit != ",")                   //<,>가 아닌 문자는 누적
	                want_val = want_val + digit;
	         }
	    }

	    if(obj == '[object]')      // obj가 Object면
	    	obj.value = want_val;

	    return want_val;
	}

	 //----------------------------------
	 // 숫자 검사
	 //--------------------------------
	function checkDigit(obj)
	{
		var tValue = '';

		if (obj == '[object]')
		{
			tValue = obj.value;
		}
		else
		{
			tValue = obj;
		}

		var cLastIdx = tValue.lastIndexOf(",");
		var cFirstIdx = tValue.indexOf(",");
		var dIdx = tValue.indexOf(".");


		if(cFirstIdx == 0 || (dIdx > -1 && cLastIdx > dIdx)|| cLastIdx == (dIdx - 1))
		{
			return false;
		}

		var txtNumber = removeComma(tValue);
		var arrNumber = txtNumber.split('.');

		if (arrNumber.length > 2)  // 소숫점(.)이 2개 이상
		{
			return false;
		}

		var checkValue = arrNumber.join('');

		return !isNaN(checkValue);
	}
	
	//----------------------------------
	 // 숫자 검사
	 //--------------------------------
	function checkCapawt(obj)
	{
		var tValue = '';

		if (obj == '[object]')
		{
			tValue = obj.value;
		}
		else
		{
			tValue = obj;
		}

		var txtNumber = removeComma(tValue);
		var arrNumber = txtNumber.split('.');

		if (arrNumber.length > 2)  // 소숫점(.)이 2개 이상
		{
			alert("콤마는 한개만 입력가능합니다.");
			obj.focus();
			return false;
		}
		
		if(isNaN(tValue)){
            alert(" 숫자만 입력 가능합니다.\n" + "문자는 사용할 수 없습니다.(단 콤마는 사용가능)");
            obj.focus();
            
            return false;
        }

		return true;
	}
	
	// Pad 함수 - csh
	function StrPad(data, fixlength, addchar)
	{
		var data=data.toString();	
		
		var Pad = "";
		var iLen = data.length;
		var iLen2 = eval(fixlength-eval(iLen));
		
		for(var k=0; k<iLen2; k++)
		{
			var Pad = Pad+addchar;
		}
		
		Pad = Pad+data
		
		return Pad;
	}	
	
	function calendar_open(m1,m2,n){
	    murl = "/kor/common/Calender.jsp?ob1="+m1+"&ob2="+m2+"&viewType="+n;
	    window.open(murl,"","width=270, height=350, toolbar=no, resizable=no, scrolling=auto,status=no, scrollbars=no, top=100, left=100");
	}
	
	function centerPopup(url, name,width,height) {
	  var str = "height=" + height + ",innerHeight=" + height;
	  str += ",width=" + width + ",innerWidth=" + width;
	  if (window.screen) {
	    var ah = screen.availHeight - 30;
	    var aw = screen.availWidth - 10;
	
	    var xc = (aw - width) / 2;
	    var yc = (ah - height) / 2;
	
	    str += ",menubar=no,resizable=no,scrollbars=yes,alwaysRaised=no";
	    str += ",left=" + xc + ",screenX=" + xc;
	    str += ",top=" + yc + ",screenY=" + yc;
	  }
	  return window.open(url, name, str);
	}	

	//----------------------------------
	// 대리점별 화주 검색
	//--------------------------------
	function funcFindFWDRCust( fwdrCd, custTp, custNm, param1, param2, param3, param4, param5, param6, param7)
	{
	   var  form  = document.myform;

	    var url = "/ecus/cts/servlet/FWDRCustomerServlet?pid=0";
        	url += "&fwdrCode=" + fwdrCd  ;
        	url += "&custType=" + custTp  ;
        	url += "&srchWord=" + custNm  ;

        if(param1 != null)
        	url += "&param1=" + param1  ;

        if(param2 != null)
        	url +=  "&param2=" + param2  ;

        if(param3 != null)
        	url += "&param3=" + param3  ;

        if(param4 != null)
        	url +=  "&param4=" + param4  ;

        if(param5 != null)
        	url += "&param5=" + param5  ;

        if(param6 != null)
        	url += "&param6=" + param6  ;

        if(param7 != null)
        	url += "&param7=" + param7  ;

	   winname	= "custPopup";
	   option			= "toolbar=no, width=550, height=400, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, screenX=400, screenY=900" ;

	   UserWinCal = window.open(url, winname, option);

	   if (UserWinCal != null) {
		  UserWinCal.opener=self;
	   }
	}
	
	
	//----------------------------------
	// FHL, FWB 전송
	//--------------------------------
	function inputOnlyLimit(obj, limit){
    	var num ="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ,-_. ";
    	if(limit == "INT_NUM")
    		num ="0123456789";
    	else if(limit == "POINT_NUM")
    		num ="0123456789.";
    	else if(limit == "ALPHA")
    		num ="ABCDEFGHIJKLMNOPQRSTUVWXYZ";	
    	else if(limit == "ALPHA_NUM")
    		num ="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    	
		var returnValue = true;
		var point_cnt = 0;
		var len = obj.value.length;
		for (var i=0;i<obj.value.length;i++)
		{
			if(-1 == num.indexOf(obj.value.charAt(i).toUpperCase())){
				if(limit == "INT_NUM"){
					alert("숫자만 입력하세요.");
					obj.focus();
					return false;
				}else if(limit == "POINT_NUM"){
					alert("숫자( . 포함)만 입력하세요.");
					obj.focus();
					return false;
				}else if(limit == "ALPHA"){
					alert("영문자만 입력하세요.");
					obj.focus();
					return false;
				}else if(limit == "ALPHA_NUM"){
					alert("영문자와 숫자만 입력하세요.");
					obj.focus();
					return false;
				}else{
					alert("영문자( , - _ . 포함)와 숫자만 입력하세요.");
					obj.focus();
					return false;
				}
				return false;
			}
			if(limit == "POINT_NUM"){
				if(obj.value.charAt(i) == '.')
					point_cnt++;
				if(i > 2 && obj.value.charAt(i-2) == '.'){
					alert("소수점 이하 1자리 까지만 입력하세요.");
					return false;
				}else if(point_cnt > 1 && obj.value.charAt(i) == '.'){
					alert("숫자 형식이 잘못 되었습니다.");
					return false;
				}else if(obj.value.charAt(0) == '.' || obj.value.charAt(len-1) == '.'){
					alert("숫자 형식이 잘못 되었습니다.");
					return false;
				}
			}
			
			if (returnValue){
				obj.value=obj.value.toUpperCase();
			}else{
				obj.value="";
				obj.focus();
				return false;
	            returnValue = true;
		    }
		}
	}
	
	
	function showObject(url,wd,ht,wmode)
{
	document.write("<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='https://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='"+wd+"' height='"+ht+"'>");
	document.write("<param name='movie' value='"+url+"'>");
	document.write("<param name='menu' value='false'>");
	document.write("<param name='quality' value='high'>");					
	if(wmode == "yes")
	{
		document.write("<param name='wmode' value='transparent'>");
		document.write("<embed src='"+url+"' menu='false' quality='high' pluginspage='https://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='"+wd+"' height='"+ht+"'></embed>");
	}
	else
	{
		document.write("<embed src='"+url+"' menu='false' quality='high' pluginspage='https://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='"+wd+"' height='"+ht+"'></embed>");
	}
	document.write("</object>");														
}


function inputOnlyLimitEng(obj, limit){
		
    	var num ="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ,-_. ";
    	if(limit == "INT_NUM")
    		num ="0123456789,";
    	else if(limit == "POINT_NUM")
    		num ="0123456789.,";
    	else if(limit == "ALPHA")
    		num ="ABCDEFGHIJKLMNOPQRSTUVWXYZ -";	
    	else if(limit == "ALPHA_NUM")
    		num ="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ- ";
    	else if(limit == "ALPHA_NUM_SPECIAL")
    		num ="0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-  /~!@#$%^&*()-_+=|\`,;':.";

		var returnValue = true;
		var point_cnt = 0;
		var len = obj.value.length;
		for (var i=0;i<obj.value.replace(/(\r\n| )/g,"").length;i++)
		{
			if(-1 == num.indexOf(obj.value.replace(/(\r\n| )/g,"").charAt(i).toUpperCase())){
				if(limit == "INT_NUM"){
					alert("Please input only numeric.");
					obj.focus();
					return false;
				}else if(limit == "POINT_NUM"){
					alert("Please input only numreic(include .).");
					obj.focus();
					return false;
				}else if(limit == "ALPHA"){
					alert("Please input only alphabet.");
					obj.focus();
					return false;
				}else if(limit == "ALPHA_NUM"){
					alert("Please input only alphabet and numeric.");
					obj.focus();
					return false;
				}else if(limit == "ALPHA_NUM_SPECIAL"){
					alert("Please input only alphabet and numeric.");
					obj.focus();
					return false;
				}else{
					alert("Please input only alphabetic characters(include , - _ .).");
					obj.focus();
					return false;
				}
					return false;
			}
			if(limit == "POINT_NUM"){
				if(obj.value.charAt(i) == '.')
					point_cnt++;
				if(i > 2 && obj.value.charAt(i-2) == '.'){
					alert("Input down to 1 decimal places.");
					obj.focus();
					return false;
				}else if(point_cnt > 1 && obj.value.charAt(i) == '.'){
					alert("Invalid numeric foramt.");
					obj.focus();
					return false;
				}else if(obj.value.charAt(0) == '.' || obj.value.charAt(len-1) == '.'){
					alert("Invalid numeric foramt.");
					obj.focus();
					return false;
				}
			}
			
			if (returnValue){
				if(limit == "ALPHA_NUM_SPECIAL"){
					obj.value=obj.value;
				}else{
					obj.value=obj.value.toUpperCase();
				}
			}else{
				obj.value="";
				obj.focus();
				return false;
	            returnValue = true;
		    }
		}
	}


function change_info(gbn){
	if (gbn == "1"){
		var win_open = window.open("/ecus/main/servlet/MainServlet?pid=11","email_popup","width=880, height=650, scrollbars=yes");
		win_open.focus();
	}else{
		var win_open = window.open("/ecus/main/servlet/MainServlet?pid=51","email_popup","width=460, height=300");
		win_open.focus();
	}

}


function LockReroad(){ 

		if (event.keyCode == 116) {  //F5 방지
			alert("F5 Key 사용할 수 없습니다.");
			event.keyCode = 0; 
			return false; 
		} 
		if ((event.keyCode == 78) && (event.ctrlKey == true))  //ctrl + n 방지
		{
			alert("Ctrl+N 사용할 수 없습니다.");
			event.keyCode = 0;
			return false;
		}
		
		if ((event.keyCode == 82) && (event.ctrlKey == true))  //ctrl + r 방지
		{
			alert("Ctrl+ R 사용할 수 없습니다.");
			event.keyCode = 0;
			return false;
		} 
	} 
	
	
	
	
	
	function hideControl (tagName, popupObj,oDocument){ 
		var x = cmGetX (popupObj); 
		var y = cmGetY (popupObj); 
		var w = popupObj.offsetWidth; 
		var h = popupObj.offsetHeight; 
		var i; 
		for (i = 0; i < document.all.tags(tagName).length; ++i) { 
			var obj = document.all.tags(tagName)[i]; 
			if (!obj || !obj.offsetParent) continue; 
			var ox = cmGetX (obj); 
			var oy = cmGetY (obj); 
			var ow = obj.offsetWidth; 
			var oh = obj.offsetHeight; 
			if (ox > (x + w) || (ox + ow) < x) continue; 
			if (oy > (y + h) || (oy + oh) < y) continue; 
			if(obj.style.visibility == "hidden") continue; 
			if(!popupObj.overFlag) 
			popupObj.overFlag = new Array (); 
			popupObj.overFlag[popupObj.overFlag.length] = obj; 
			obj.style.visibility = "hidden"; 
		} 
	} 

function showControl(popupObj){
	for (i = 0; i < document.all.tags("select").length; ++i) {
	var obj = document.all.tags("select")[i]; 
		obj.style.visibility = ""; 
	} 
} 

function cmGetX (obj){ 
	var x = 0; 
	do{ 
	x += obj.offsetLeft; 
	obj = obj.offsetParent; 
	}while (obj); 
	return x; 
} 
	
function cmGetY (obj){ 
	var y = 0; 
	do{ 
	y += obj.offsetTop; 
	obj = obj.offsetParent; 
	}while (obj); 
	return y; 
} 

function selectboxHide(viewboolean,overObj,oDocument) {
	if (viewboolean) {
		hideControl ("select", overObj,oDocument); 
	} else { 
		showControl (overObj); 
	} 
} 


function bt(id,after)
{ 
	eval(id+'.filters.blendTrans.stop();');
	eval(id+'.filters.blendTrans.Apply();');
	eval(id+'.src="'+after+'";');
	eval(id+'.filters.blendTrans.Play();'); 
}

	
function hideCargoMenu(menu_gbn){
		
		document.all.frame_menu1.style.visibility="hidden";
		document.all.frame_menu2.style.visibility="hidden";
		document.all.frame_menu3.style.visibility="hidden";
		document.all.frame_menu4.style.visibility="hidden";
		document.all.frame_menu5.style.visibility="hidden";
		document.all.frame_menu6.style.visibility="hidden";
		document.all.frame_menu7.style.visibility="hidden";
		document.all.frame_menu8.style.visibility="hidden";
		
}
	
function showCargoMenu1(menu_gbn){
		
		document.all.frame_menu1.style.visibility="hidden";
		document.all.frame_menu2.style.visibility="hidden";
		document.all.frame_menu3.style.visibility="hidden";
		document.all.frame_menu4.style.visibility="hidden";
		document.all.frame_menu5.style.visibility="hidden";
		document.all.frame_menu6.style.visibility="hidden";
		document.all.frame_menu7.style.visibility="hidden";
		document.all.frame_menu8.style.visibility="hidden";
		
		document.all.frame_menu1.style.visibility="visible";
}

function showCargoMenu2(menu_gbn){
		
		document.all.frame_menu1.style.visibility="hidden";
		document.all.frame_menu2.style.visibility="hidden";
		document.all.frame_menu3.style.visibility="hidden";
		document.all.frame_menu4.style.visibility="hidden";
		document.all.frame_menu5.style.visibility="hidden";
		document.all.frame_menu6.style.visibility="hidden";
		document.all.frame_menu7.style.visibility="hidden";
		document.all.frame_menu8.style.visibility="hidden";
		
		document.all.frame_menu2.style.visibility="visible";
}

function showCargoMenu3(menu_gbn){
		
		document.all.frame_menu1.style.visibility="hidden";
		document.all.frame_menu2.style.visibility="hidden";
		document.all.frame_menu3.style.visibility="hidden";
		document.all.frame_menu4.style.visibility="hidden";
		document.all.frame_menu5.style.visibility="hidden";
		document.all.frame_menu6.style.visibility="hidden";
		document.all.frame_menu7.style.visibility="hidden";
		document.all.frame_menu8.style.visibility="hidden";
		
		document.all.frame_menu3.style.visibility="visible";
}

function showCargoMenu4(menu_gbn){
		
		document.all.frame_menu1.style.visibility="hidden";
		document.all.frame_menu2.style.visibility="hidden";
		document.all.frame_menu3.style.visibility="hidden";
		document.all.frame_menu4.style.visibility="hidden";
		document.all.frame_menu5.style.visibility="hidden";
		document.all.frame_menu6.style.visibility="hidden";
		document.all.frame_menu7.style.visibility="hidden";
		document.all.frame_menu8.style.visibility="hidden";
		
		document.all.frame_menu4.style.visibility="visible";
}

function showCargoMenu5(menu_gbn){
		
		document.all.frame_menu1.style.visibility="hidden";
		document.all.frame_menu2.style.visibility="hidden";
		document.all.frame_menu3.style.visibility="hidden";
		document.all.frame_menu4.style.visibility="hidden";
		document.all.frame_menu5.style.visibility="hidden";
		document.all.frame_menu6.style.visibility="hidden";
		document.all.frame_menu7.style.visibility="hidden";
		document.all.frame_menu8.style.visibility="hidden";
		
		document.all.frame_menu5.style.visibility="visible";
}

function showCargoMenu6(menu_gbn){
		
		document.all.frame_menu1.style.visibility="hidden";
		document.all.frame_menu2.style.visibility="hidden";
		document.all.frame_menu3.style.visibility="hidden";
		document.all.frame_menu4.style.visibility="hidden";
		document.all.frame_menu5.style.visibility="hidden";
		document.all.frame_menu6.style.visibility="hidden";
		document.all.frame_menu7.style.visibility="hidden";
		document.all.frame_menu8.style.visibility="hidden";
		
		document.all.frame_menu6.style.visibility="visible";
}

function showCargoMenu7(menu_gbn){
		
		document.all.frame_menu1.style.visibility="hidden";
		document.all.frame_menu2.style.visibility="hidden";
		document.all.frame_menu3.style.visibility="hidden";
		document.all.frame_menu4.style.visibility="hidden";
		document.all.frame_menu5.style.visibility="hidden";
		document.all.frame_menu6.style.visibility="hidden";
		document.all.frame_menu7.style.visibility="hidden";
		document.all.frame_menu8.style.visibility="hidden";
		
		document.all.frame_menu7.style.visibility="visible";
}

function showCargoMenu8(menu_gbn){
		
		document.all.frame_menu1.style.visibility="hidden";
		document.all.frame_menu2.style.visibility="hidden";
		document.all.frame_menu3.style.visibility="hidden";
		document.all.frame_menu4.style.visibility="hidden";
		document.all.frame_menu5.style.visibility="hidden";
		document.all.frame_menu6.style.visibility="hidden";
		document.all.frame_menu7.style.visibility="hidden";
		document.all.frame_menu8.style.visibility="hidden";
		
		document.all.frame_menu8.style.visibility="visible";
}

//들어온 자리수 체크
    /*인자
      Obj           : 객체
      startLength   : 자리수부터(0이면 endLength까지만
      endLength     : 자리수까지(0이면 startLength부터 무한대
      comment       : head명
      mendentory    : 필수여부
    */
    function maspCheckMinLength(Obj, startLength, endLength, comment, mendentory){
        //var data_length =  Obj.value.length;

        data_length = maspGetByteLength(Obj.value);
        //년월일이 입력되었는지 Check
        //필수 입력항목일 경우
        if( (data_length == 0   && mendentory )|| data_length < startLength ) {
            var mesg = "";
            alert("Please input "+ comment +" (length: Min "+ startLength +"). ");
            Obj.focus();

        }else{
            return true;
        }
        return false;

    }
	