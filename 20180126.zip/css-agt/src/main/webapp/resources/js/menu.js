
function menu_slide(sub_menu){
	  var obj = document.getElementById("left_menu");

   if(obj.className == "side-navigator")

  {
      obj.className = "side-navigator active";
  }

  else

  {
        obj.className = "side-navigator";

  }
}


//메뉴 클릭시마다 클릭한 1단 메뉴 활성화 또는 비활성화, 활성화 할경우 서브 메뉴(2단)활성화, 비활성화 할경우 서브 메뉴 접기 
//2단 메뉴 영역 열기/닫기 
function big_menu_click(big_menu_name, sub_menu_name, div_menu_name, menu_seq, menu_text){

	var obj = document.getElementById(sub_menu_name);
	var obj_name = document.getElementsByName(big_menu_name);
	var obj_div_name = document.getElementsByName(div_menu_name);
	var obj_slide = document.getElementById("left_menu");
	

	var sub_menu_text = document.getElementById("sub_menu_text");
	
	for (var i=0; i<obj_name.length; i++){
		obj_name[i].className = "menuList-2";
		obj_div_name[i].style.visibility='hidden';
	}
	
	obj_div_name[menu_seq-1].style.visibility='visible';
	
	if (obj != ""){
		
		if (obj.className.match('active') == "active"){
			obj.className = sub_menu_name;
			obj_slide.className = "side-navigator";
		}else{
			obj.className = sub_menu_name + " active";
			obj_slide.className = "side-navigator active";
		}
		
	}
	


	sub_menu_text.innerHTML = menu_text;
	
   
}


//load 될때 첫번째 메뉴 활설화 시킴 
function init_menu(sub_menu_name, menu_seq){

	var obj = document.getElementById(sub_menu_name);
	var obj_slide = document.getElementById("left_menu");
	var obj_2d_menu_1 = document.getElementById("2d_menu_1");
	
	var sub_menu_text = document.getElementById("sub_menu_text");
	
	obj.className = sub_menu_name + " active";
	obj_slide.className = "side-navigator active";
	
	sub_menu_text.innerHTML = "한국 세관";
	
	
	obj_2d_menu_1.style.visibility='visible';
	
	
   
}

//3단 메뉴 열기/닫기 
function sub_menu_open(sub_menu_name, sub_menu_id, menu_seq, menu_url){
	var obj_name = document.getElementsByName(sub_menu_name);
	var obj_id  = document.getElementById(sub_menu_id);
	
	

	for (var i=0; i<obj_name.length; i++){
		obj_name[i].className = "sub-list";
	}
	
	if (obj_id != ""){
		if (obj_id.className.match('active') == "active"){
			obj_id.className = "sub-list";
		}else{
			obj_id.className = "sub-list active";
		}
		
	}
	
	if (menu_url != "#" && menu_url != "" && menu_url != " "){
		location.href = menu_url;
	}
	
}
